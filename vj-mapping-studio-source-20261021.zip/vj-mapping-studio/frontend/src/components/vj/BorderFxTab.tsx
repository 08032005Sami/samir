// Border FX panel: searchable/categorized effect library with live thumbnails,
// favorites, presets, copy/paste, reset, randomize, and full parameter controls.

import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import type { EffectInstance, Shape } from "@/lib/types";
import { EFFECT_CATALOG, FX_CATEGORIES, makeEffect, effectById } from "@/lib/effects";
import { addShape, patchEffect, store, useEditor } from "@/lib/store";
import { getFxFavorites, setFxFavorites, mkShape } from "@/lib/project";
import { drawShape } from "@/lib/engine";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ColorField } from "./ColorField";
import { Search, Star, Copy, ClipboardPaste, RotateCcw, Shuffle, Save, Wand2, Sparkles, Trash2 } from "lucide-react";

const PRESETS_KEY = "vjmap.fx_presets.v1";
interface FxPreset {
  name: string;
  fx: EffectInstance;
}
function getPresets(): FxPreset[] {
  try {
    return JSON.parse(localStorage.getItem(PRESETS_KEY) ?? "[]") as FxPreset[];
  } catch {
    return [];
  }
}

let fxClipboard: EffectInstance | null = null;

// shared thumbnail ticker — one rAF drives all visible thumbnails
const thumbs = new Set<() => void>();
let thumbRaf = 0;
function tickThumbs() {
  thumbs.forEach((f) => f());
  thumbRaf = requestAnimationFrame(tickThumbs);
}

function FxThumb({ type }: { type: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const shape: Shape = mkShape("rrect", 8, 8, 104, 44, type, effectById(type).defaults.color ?? "#00F0FF", { strokeWidth: 3, corner: 8 });
    shape.fx.glow = Math.min(10, shape.fx.glow);
    const draw = () => {
      const c = ref.current;
      if (!c) return;
      const ctx = c.getContext("2d");
      if (!ctx) return;
      ctx.clearRect(0, 0, 120, 60);
      ctx.fillStyle = "#080A0E";
      ctx.fillRect(0, 0, 120, 60);
      drawShape(ctx, shape, 1, performance.now() / 1000, false);
    };
    thumbs.add(draw);
    if (!thumbRaf) thumbRaf = requestAnimationFrame(tickThumbs);
    return () => {
      thumbs.delete(draw);
      if (!thumbs.size) {
        cancelAnimationFrame(thumbRaf);
        thumbRaf = 0;
      }
    };
  }, [type]);
  return <canvas ref={ref} width={120} height={60} className="h-[46px] w-full rounded" />;
}

function Param({ label, value, min, max, step, onChange, testId, fmt }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; testId: string; fmt?: (v: number) => string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-[74px] shrink-0 text-[10px] uppercase tracking-wider text-[#8292AD]">{label}</span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="vj-range flex-1" data-testid={testId} />
      <span className="w-12 text-right font-mono text-[10px] text-[#00F0FF]">{fmt ? fmt(value) : value.toFixed(2)}</span>
    </div>
  );
}

export default function BorderFxTab() {
  const doc = useEditor((s) => s.doc);
  const selection = useEditor((s) => s.selection);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("All");
  const [favs, setFavs] = useState<string[]>(getFxFavorites());
  const [presets, setPresets] = useState<FxPreset[]>(getPresets());
  const [presetName, setPresetName] = useState("");
  const [genText, setGenText] = useState("4 LED screens around a central stage");

  const shapes = doc.shapes.filter((s) => selection.includes(s.id));
  const shape = shapes[0] ?? null;

  const list = EFFECT_CATALOG.filter(
    (e) =>
      (cat === "All" || (cat === "★" ? favs.includes(e.id) : e.category === cat)) &&
      (q === "" || e.name.toLowerCase().includes(q.toLowerCase()) || e.category.toLowerCase().includes(q.toLowerCase())),
  );

  const applyType = (type: string) => {
    if (!shapes.length) {
      // no shape selected → create a border around the canvas with this effect
      const w = doc.canvas.width;
      const h = doc.canvas.height;
      const s = mkShape("rrect", Math.round(w * 0.05), Math.round(h * 0.05), Math.round(w * 0.9), Math.round(h * 0.9), type, effectById(type).defaults.color ?? "#00F0FF", { name: effectById(type).name });
      addShape(s);
      toast.success(`Added "${effectById(type).name}" border to canvas`);
      return;
    }
    store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] }));
    for (const sh of shapes) {
      const next = makeEffect(type);
      next.color = sh.fx.color;
      next.color2 = sh.fx.color2;
      patchEffect(sh.id, next, false);
    }
  };

  const set = (patch: Partial<EffectInstance>) => {
    for (const sh of shapes) patchEffect(sh.id, patch, false);
    store.set({ dirty: true });
  };
  const setParam = (k: string, v: number) => {
    for (const sh of shapes) patchEffect(sh.id, { params: { ...sh.fx.params, [k]: v } }, false);
  };

  const toggleFav = (id: string) => {
    const next = favs.includes(id) ? favs.filter((x) => x !== id) : [...favs, id];
    setFavs(next);
    setFxFavorites(next);
  };

  const randomize = () => {
    if (!shape) return;
    const pick = EFFECT_CATALOG[Math.floor(Math.random() * EFFECT_CATALOG.length)];
    const hue = () => ["#00F0FF", "#FF007F", "#00FFA3", "#FFB800", "#7C4DFF", "#FF3366", "#FFFFFF"][Math.floor(Math.random() * 7)];
    store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] }));
    for (const sh of shapes) {
      patchEffect(
        sh.id,
        {
          ...makeEffect(pick.id),
          speed: Number((0.15 + Math.random() * 1.2).toFixed(2)),
          length: Number((0.08 + Math.random() * 0.5).toFixed(2)),
          glow: Math.round(6 + Math.random() * 30),
          color: hue(),
          color2: hue(),
          direction: Math.random() > 0.5 ? 1 : -1,
          phase: Number(Math.random().toFixed(2)),
        },
        false,
      );
    }
    toast.success(`Randomized → ${pick.name}`);
  };

  const generate = () => {
    // Border FX Generator: parse "N screens" + layout words into a ring of bordered screens
    const n = Math.max(1, Math.min(12, Number(genText.match(/(\d+)/)?.[1] ?? 4)));
    const W = doc.canvas.width;
    const H = doc.canvas.height;
    const around = /around|surround|ring|circle/i.test(genText);
    const fxType = /neon/i.test(genText) ? "neon_glow_pulse" : /rainbow/i.test(genText) ? "rainbow_cycle" : /strobe/i.test(genText) ? "strobe_flash" : "traveling_light";
    store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] }));
    const made: Shape[] = [];
    if (around) {
      const cx = W / 2;
      const cy = H / 2;
      const rx = W * 0.36;
      const ry = H * 0.34;
      const bw = Math.min(W, H) * 0.22;
      const bh = bw * 0.6;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2 - Math.PI / 2;
        made.push(mkShape("rrect", Math.round(cx + Math.cos(a) * rx - bw / 2), Math.round(cy + Math.sin(a) * ry - bh / 2), Math.round(bw), Math.round(bh), fxType, ["#00F0FF", "#FF007F", "#00FFA3", "#FFB800"][i % 4], { name: `Gen Border ${i + 1}`, fx: { ...makeEffect(fxType), phase: i / n, color: ["#00F0FF", "#FF007F", "#00FFA3", "#FFB800"][i % 4] } }));
      }
      made.push(mkShape("hexagon", Math.round(cx - bw * 0.6), Math.round(cy - bw * 0.6), Math.round(bw * 1.2), Math.round(bw * 1.2), "rainbow_cycle", "#7C4DFF", { name: "Gen Center Stage" }));
    } else {
      const gap = W * 0.02;
      const bw = (W - gap * (n + 1)) / n;
      const bh = Math.min(H * 0.6, bw * 0.75);
      for (let i = 0; i < n; i++) {
        made.push(mkShape("rrect", Math.round(gap + i * (bw + gap)), Math.round(H / 2 - bh / 2), Math.round(bw), Math.round(bh), fxType, "#00F0FF", { name: `Gen Border ${i + 1}`, fx: { ...makeEffect(fxType), phase: i / n } }));
      }
    }
    store.set((s) => ({ doc: { ...s.doc, shapes: [...s.doc.shapes, ...made] }, selection: made.map((m) => m.id), dirty: true }));
    toast.success(`Generated ${made.length} synced borders`);
  };

  const pattern = (kind: "concentric" | "tunnel" | "radial" | "frames") => {
    const W = doc.canvas.width;
    const H = doc.canvas.height;
    const made: Shape[] = [];
    store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] }));
    if (kind === "concentric" || kind === "tunnel") {
      const n = kind === "tunnel" ? 7 : 5;
      for (let i = 0; i < n; i++) {
        const k = 1 - i / (n + 1);
        const w = W * 0.92 * k;
        const h = H * 0.9 * k;
        made.push(mkShape(kind === "tunnel" ? "rect" : "rrect", Math.round(W / 2 - w / 2), Math.round(H / 2 - h / 2), Math.round(w), Math.round(h), kind === "tunnel" ? "traveling_light" : "neon_glow_pulse", i % 2 ? "#FF007F" : "#00F0FF", { name: `${kind} ${i + 1}`, fx: { ...makeEffect(kind === "tunnel" ? "traveling_light" : "neon_glow_pulse"), phase: i * 0.12, color: i % 2 ? "#FF007F" : "#00F0FF" } }));
      }
    } else if (kind === "radial") {
      const n = 8;
      const r = Math.min(W, H) * 0.38;
      const s0 = Math.min(W, H) * 0.12;
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        made.push(mkShape("diamond", Math.round(W / 2 + Math.cos(a) * r - s0 / 2), Math.round(H / 2 + Math.sin(a) * r - s0 / 2), Math.round(s0), Math.round(s0), "comet_tail", "#00FFA3", { name: `radial ${i + 1}`, fx: { ...makeEffect("comet_tail"), phase: i / n } }));
      }
    } else {
      const cols = 4;
      const rows = 2;
      const gw = W / cols;
      const gh = H / rows;
      for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) made.push(mkShape("rrect", Math.round(c * gw + gw * 0.08), Math.round(r * gh + gh * 0.1), Math.round(gw * 0.84), Math.round(gh * 0.8), "chase_segmented", "#FFB800", { name: `frame ${r * cols + c + 1}`, fx: { ...makeEffect("chase_segmented"), phase: (r * cols + c) / 8 } }));
    }
    store.set((s) => ({ doc: { ...s.doc, shapes: [...s.doc.shapes, ...made] }, selection: made.map((m) => m.id), dirty: true }));
    toast.success(`Pattern generated: ${made.length} shapes`);
  };

  const fx = shape?.fx;
  const def = fx ? effectById(fx.type) : null;
  const extraParams = fx ? Object.keys({ ...(def?.defaults.params ?? {}), ...fx.params }) : [];

  return (
    <div className="space-y-3 p-3" data-testid="border-fx-tab">
      <div>
        <h3 className="font-heading text-sm font-bold text-[#F0F4FC]">Border FX Engine</h3>
        <p className="text-[10px] text-[#8292AD]">{shape ? `${shapes.length} shape${shapes.length > 1 ? "s" : ""} selected — click an effect to apply` : "No shape selected — click an effect to add a canvas border"}</p>
      </div>

      {/* library */}
      <div className="relative">
        <Search className="absolute left-2 top-2 size-3.5 text-[#5C6B84]" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search effects…" className="h-8 border-[#212A3D] bg-[#0B0D13] pl-7 text-xs" data-testid="fx-search-input" />
      </div>
      <div className="flex flex-wrap gap-1">
        {["All", "★", ...FX_CATEGORIES].map((c) => (
          <button key={c} onClick={() => setCat(c)} className={`rounded px-1.5 py-0.5 text-[10px] ${cat === c ? "bg-[#00F0FF] text-[#05090F]" : "bg-[#1D2536] text-[#8A99B5] hover:text-[#F0F4FC]"}`} data-testid={`fx-cat-${c === "★" ? "favorites" : c.toLowerCase()}`}>
            {c}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-1.5" data-testid="fx-library">
        {list.map((e) => (
          <div
            key={e.id}
            className={`group relative cursor-pointer rounded border p-1 transition-colors ${fx?.type === e.id ? "border-[#00F0FF] bg-[#00F0FF]/5" : "border-[#212A3D] hover:border-[#00F0FF]/50"}`}
            onClick={() => applyType(e.id)}
            data-testid={`fx-item-${e.id}`}
          >
            <FxThumb type={e.id} />
            <div className="mt-1 flex items-center justify-between">
              <span className="truncate text-[10px] text-[#EBF1FC]">{e.name}</span>
              <button
                onClick={(ev) => {
                  ev.stopPropagation();
                  toggleFav(e.id);
                }}
                aria-label="Toggle favorite"
                data-testid={`fx-fav-${e.id}`}
              >
                <Star className={`size-3 ${favs.includes(e.id) ? "fill-[#FFB800] text-[#FFB800]" : "text-[#5C6B84]"}`} />
              </button>
            </div>
          </div>
        ))}
        {!list.length && <p className="col-span-2 py-4 text-center text-[11px] text-[#5C6B84]">No effects match.</p>}
      </div>

      {/* parameters */}
      {fx && def && (
        <div className="space-y-2 rounded border border-[#212A3D] bg-[#121722] p-2.5" data-testid="fx-params">
          <div className="flex items-center justify-between">
            <span className="font-heading text-[11px] font-bold text-[#00F0FF]">{def.name}</span>
            <label className="flex items-center gap-1 text-[10px] text-[#8A99B5]">
              <Checkbox checked={fx.enabled} onCheckedChange={(c) => set({ enabled: c === true })} data-testid="fx-enabled" /> enabled
            </label>
          </div>
          <Param label="Speed" value={fx.speed} min={0.02} max={4} step={0.01} onChange={(v) => set({ speed: v })} testId="fx-speed" fmt={(v) => `${v.toFixed(2)}c/s`} />
          <Param label="Length" value={fx.length} min={0.02} max={1} step={0.01} onChange={(v) => set({ length: v })} testId="fx-length" fmt={(v) => `${Math.round(v * 100)}%`} />
          <Param label="Start" value={fx.start} min={0} max={1} step={0.01} onChange={(v) => set({ start: v })} testId="fx-start" fmt={(v) => `${Math.round(v * 360)}°`} />
          <Param label="Phase" value={fx.phase} min={0} max={1} step={0.01} onChange={(v) => set({ phase: v })} testId="fx-phase" fmt={(v) => `${Math.round(v * 360)}°`} />
          <Param label="Offset" value={fx.offset} min={0} max={1} step={0.01} onChange={(v) => set({ offset: v })} testId="fx-offset" fmt={(v) => `${Math.round(v * 100)}%`} />
          <Param label="Glow" value={fx.glow} min={0} max={64} step={1} onChange={(v) => set({ glow: v })} testId="fx-glow" fmt={(v) => `${v}px`} />
          <Param label="Intensity" value={fx.intensity} min={0.1} max={1.5} step={0.05} onChange={(v) => set({ intensity: v })} testId="fx-intensity" />
          <Param label="Thickness" value={shape.strokeWidth} min={1} max={48} step={1} onChange={(v) => shapes.forEach((sh) => store.set((s) => ({ doc: { ...s.doc, shapes: s.doc.shapes.map((x) => (x.id === sh.id ? { ...x, strokeWidth: v } : x)) } })))} testId="fx-thickness" fmt={(v) => `${v}px`} />
          {extraParams.map((k) => (
            <Param key={k} label={k} value={fx.params[k] ?? def.defaults.params?.[k] ?? 1} min={1} max={k === "bpm" ? 200 : k === "duty" ? 1 : 64} step={k === "duty" ? 0.05 : 1} onChange={(v) => setParam(k, v)} testId={`fx-param-${k}`} />
          ))}
          <div className="flex items-center gap-2">
            <span className="w-[74px] text-[10px] uppercase tracking-wider text-[#8292AD]">Direction</span>
            <div className="flex gap-1">
              <Button size="xs" variant={fx.direction === 1 ? "secondary" : "outline"} onClick={() => set({ direction: 1 })} data-testid="fx-dir-cw">↻ CW</Button>
              <Button size="xs" variant={fx.direction === -1 ? "secondary" : "outline"} onClick={() => set({ direction: -1 })} data-testid="fx-dir-ccw">↺ CCW</Button>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-[74px] text-[10px] uppercase tracking-wider text-[#8292AD]">Color</span>
            <ColorField value={fx.color} onChange={(c) => set({ color: c })} testId="fx-color" />
          </div>
          <div className="flex items-center gap-2">
            <span className="w-[74px] text-[10px] uppercase tracking-wider text-[#8292AD]">Gradient</span>
            <Checkbox checked={fx.useGradient} onCheckedChange={(c) => set({ useGradient: c === true })} data-testid="fx-gradient-toggle" />
            {fx.useGradient && <ColorField value={fx.color2} onChange={(c) => set({ color2: c })} testId="fx-color2" />}
          </div>
          <div className="flex items-center gap-2">
            <span className="w-[74px] text-[10px] uppercase tracking-wider text-[#8292AD]">Loop</span>
            <Checkbox checked={fx.loop} onCheckedChange={(c) => set({ loop: c === true })} data-testid="fx-loop-toggle" />
          </div>

          <div className="grid grid-cols-2 gap-1 pt-1">
            <Button size="xs" variant="outline" onClick={() => ((fxClipboard = { ...fx, params: { ...fx.params } }), toast.success("Effect copied"))} data-testid="fx-copy-btn"><Copy className="size-3" /> Copy FX</Button>
            <Button size="xs" variant="outline" disabled={!fxClipboard} onClick={() => fxClipboard && (store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] })), shapes.forEach((sh) => patchEffect(sh.id, { ...fxClipboard!, params: { ...fxClipboard!.params } }, false)), toast.success("Effect pasted"))} data-testid="fx-paste-btn"><ClipboardPaste className="size-3" /> Paste FX</Button>
            <Button size="xs" variant="outline" onClick={() => applyType(fx.type)} data-testid="fx-reset-btn"><RotateCcw className="size-3" /> Reset</Button>
            <Button size="xs" variant="outline" onClick={randomize} data-testid="fx-randomize-btn"><Shuffle className="size-3" /> Randomize</Button>
            <Button size="xs" variant="outline" className="col-span-2" onClick={() => {
              store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] }));
              const all = store.get().doc.shapes;
              all.forEach((sh) => patchEffect(sh.id, { speed: fx.speed, phase: 0 }, false));
              store.set({ time: 0 });
              toast.success(`Global sync: ${all.length} shapes locked to ${fx.speed.toFixed(2)} c/s`);
            }} data-testid="fx-global-sync-btn">⇄ Global Sync All Shapes</Button>
          </div>

          {/* presets */}
          <div className="border-t border-[#212A3D] pt-2">
            <div className="flex gap-1">
              <Input value={presetName} onChange={(e) => setPresetName(e.target.value)} placeholder="Preset name" className="h-7 border-[#212A3D] bg-[#0B0D13] text-xs" data-testid="fx-preset-name" />
              <Button size="xs" variant="secondary" onClick={() => {
                const name = presetName.trim() || `${def.name} ${presets.length + 1}`;
                const next = [{ name, fx: { ...fx, params: { ...fx.params } } }, ...presets].slice(0, 30);
                setPresets(next);
                localStorage.setItem(PRESETS_KEY, JSON.stringify(next));
                setPresetName("");
                toast.success(`Preset saved: ${name}`);
              }} data-testid="fx-preset-save"><Save className="size-3" /></Button>
            </div>
            <div className="mt-1.5 space-y-1">
              {presets.map((p, i) => (
                <div key={`${p.name}-${i}`} className="flex items-center gap-1">
                  <button className="flex-1 truncate rounded bg-[#1D2536] px-2 py-1 text-left text-[10px] text-[#EBF1FC] hover:text-[#00F0FF]" onClick={() => { store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] })); shapes.forEach((sh) => patchEffect(sh.id, { ...p.fx, params: { ...p.fx.params } }, false)); }} data-testid={`fx-preset-${i}`}>
                    {p.name} <span className="text-[#5C6B84]">· {effectById(p.fx.type).name}</span>
                  </button>
                  <button onClick={() => { const next = presets.filter((_, j) => j !== i); setPresets(next); localStorage.setItem(PRESETS_KEY, JSON.stringify(next)); }} data-testid={`fx-preset-delete-${i}`} aria-label="Delete preset"><Trash2 className="size-3 text-[#5C6B84] hover:text-[#FF5C7A]" /></button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* generators */}
      <div className="space-y-2 rounded border border-[#212A3D] bg-[#121722] p-2.5">
        <span className="flex items-center gap-1 font-heading text-[10px] font-bold uppercase tracking-[0.08em] text-[#8292AD]"><Wand2 className="size-3" /> Border FX Generator</span>
        <Input value={genText} onChange={(e) => setGenText(e.target.value)} className="h-8 border-[#212A3D] bg-[#0B0D13] text-xs" data-testid="fx-generator-input" />
        <Button size="sm" className="w-full bg-[#FF007F] text-white hover:bg-[#FF007F]/80" onClick={generate} data-testid="fx-generator-btn">Generate Borders</Button>
        <p className="text-[10px] text-[#5C6B84]">Understands a count, “around/ring” vs row layout, and neon / rainbow / strobe keywords.</p>
        <span className="flex items-center gap-1 pt-1 font-heading text-[10px] font-bold uppercase tracking-[0.08em] text-[#8292AD]"><Sparkles className="size-3" /> Pattern Generator</span>
        <div className="grid grid-cols-2 gap-1">
          <Button size="xs" variant="outline" onClick={() => pattern("concentric")} data-testid="pattern-concentric">Concentric</Button>
          <Button size="xs" variant="outline" onClick={() => pattern("tunnel")} data-testid="pattern-tunnel">Tunnel</Button>
          <Button size="xs" variant="outline" onClick={() => pattern("radial")} data-testid="pattern-radial">Radial</Button>
          <Button size="xs" variant="outline" onClick={() => pattern("frames")} data-testid="pattern-frames">Repeating Frames</Button>
        </div>
      </div>
    </div>
  );
}
