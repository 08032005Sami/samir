// Top menu bar: brand, File/Edit/View/Project/Tools/Export menus, project title,
// canvas pill, quick actions.

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { store, useEditor, setDoc, loadDoc, markSaved, undo, redo, selectAll, invertSelection, copySelection, pasteClipboard, duplicateSelection, deleteSelection, setZoomPreset, fitAll, groupSelection, ungroupSelection } from "@/lib/store";
import { apiGet, apiPost, apiDelete } from "@/lib/api";
import type { ProjectListResponse, ProjectLoadResponse } from "@/lib/types";
import { downloadProject, getRecents, parseProject, pushRecent } from "@/lib/project";
import { exportPng, exportSvg, downloadCsv } from "@/lib/exporters";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ChevronDown,
  Download,
  FilePlus2,
  FolderOpen,
  Save,
  CloudUpload,
  FileCode2,
  FileDown,
  Image,
  Images,
  Film,
  FileSpreadsheet,
  FileText,
  Map as MapIcon,
  Undo2,
  Redo2,
  Copy,
  Clipboard,
  SquareDashed,
  Trash2,
  Group,
  Ungroup,
  ZoomIn,
  ZoomOut,
  Maximize,
  Grid3X3,
  Ruler,
  Magnet,
  Crosshair,
  Scan,
  Tags,
  Route,
  Layers,
  Calculator,
  Presentation,
  Network,
  Keyboard,
  CircleHelp,
  MonitorPlay,
} from "lucide-react";

function MenuBtn({ label, children, testId }: { label: string; children: React.ReactNode; testId: string }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        render={
          <button
            className="rounded px-2.5 py-1 text-xs text-[#E1E7F5] hover:bg-[#1D2536] data-[pressed]:bg-[#1D2536]"
            data-testid={`menu-${testId}`}
          >
            {label}
          </button>
        }
      />
      <DropdownMenuContent className="bg-[#131926] border-[#263249] font-sans">{children}</DropdownMenuContent>
    </DropdownMenu>
  );
}

function Item({
  icon: Icon,
  label,
  onClick,
  shortcut,
  testId,
  disabled,
}: {
  icon?: typeof Save;
  label: string;
  onClick: () => void;
  shortcut?: string;
  testId: string;
  disabled?: boolean;
}) {
  return (
    <DropdownMenuItem
      disabled={disabled}
      className="gap-2 rounded px-2 py-1.5 text-xs text-[#EBF1FC] data-[highlighted]:bg-[#1D2536]"
      onClick={onClick}
      data-testid={testId}
    >
      {Icon ? <Icon className="size-3.5 text-[#8A99B5]" /> : <span className="size-3.5" />}
      <span className="flex-1">{label}</span>
      {shortcut && <span className="font-mono text-[10px] text-[#5C6B84]">{shortcut}</span>}
    </DropdownMenuItem>
  );
}

export default function TopMenuBar() {
  const doc = useEditor((s) => s.doc);
  const dirty = useEditor((s) => s.dirty);
  const showGrid = useEditor((s) => s.showGrid);
  const showRulers = useEditor((s) => s.showRulers);
  const snapGrid = useEditor((s) => s.snapGrid);
  const checkerboard = useEditor((s) => s.checkerboard);
  const showSafe = useEditor((s) => s.showSafe);
  const showBadges = useEditor((s) => s.showBadges);
  const showCable = useEditor((s) => s.showCable);
  const stageMode = useEditor((s) => s.doc.stageMode);
  const qc = useQueryClient();
  const [recentTick, setRecentTick] = useState(0);

  const cloudProjects = useQuery({
    queryKey: ["projects"],
    queryFn: () => apiGet<ProjectListResponse>("/projects"),
    retry: false,
    staleTime: 30_000,
  });

  const saveCloud = useMutation({
    mutationFn: async () => {
      const st = store.get();
      const res = await apiPost<{ id: string; name: string }>("/projects", { id: st.doc.id, name: st.doc.name, doc: st.doc });
      return res;
    },
    onSuccess: (res) => {
      pushRecent(res.id, res.name);
      markSaved();
      toast.success(`Saved to cloud: ${res.name}`);
      qc.invalidateQueries({ queryKey: ["projects"] });
    },
    onError: () => toast.error("Cloud save failed — your local .vjmap download still works offline."),
  });

  const openCloud = useMutation({
    mutationFn: async (id: string) => apiGet<ProjectLoadResponse>(`/projects/${id}`),
    onSuccess: (res) => {
      const d = parseProject(JSON.stringify(res.doc));
      loadDoc(d);
      pushRecent(res.id, d.name);
      toast.success(`Opened project: ${d.name}`);
    },
    onError: () => toast.error("Could not open cloud project."),
  });

  const deleteCloud = useMutation({
    mutationFn: async (id: string) => apiDelete(`/projects/${id}`),
    onSuccess: () => {
      toast.success("Cloud project deleted");
      qc.invalidateQueries({ queryKey: ["projects"] });
      setRecentTick((t) => t + 1);
    },
  });

  const recents: { id: string; name: string; at: string; cloud?: boolean }[] = [...getRecents(), ...(cloudProjects.data?.projects ?? []).map((p) => ({ id: p.id, name: p.name, at: p.updated_at, cloud: true }))];
  void recentTick;

  const quickPng = () => exportPng(doc, "map", doc.canvas.width, doc.canvas.height).then(() => toast.success("Canvas PNG exported"));

  return (
    <div className="flex h-[38px] shrink-0 items-center gap-1 border-b border-[#212A3D] bg-[#10141D] px-2" data-testid="top-menu-bar">
      {/* brand */}
      <div className="mr-2 flex items-center gap-2">
        <div className="flex size-5 items-center justify-center rounded bg-gradient-to-br from-[#00F0FF] to-[#FF007F] font-mono text-[10px] font-bold text-[#05090F]">VJ</div>
        <span className="font-heading text-xs font-bold tracking-wide text-[#F0F4FC]">VJ MAPPING STUDIO</span>
        <span className="rounded bg-[#1D2536] px-1 py-px font-mono text-[9px] text-[#8A99B5]">v1.0 PRO</span>
      </div>

      {/* menus */}
      <MenuBtn label="File" testId="file">
        <Item icon={FilePlus2} label="New Project…" shortcut="Ctrl+N" testId="file-new" onClick={() => store.set({ presetsOpen: true })} />
        <Item icon={FolderOpen} label="Open .vjmap…" shortcut="Ctrl+O" testId="file-open" onClick={() => store.set((s) => ({ openRequest: s.openRequest + 1 }))} />
        <DropdownMenuSub>
          <DropdownMenuSubTrigger className="text-xs">
            <span className="flex items-center gap-2">
              <FolderOpen className="size-3.5 text-[#8A99B5]" /> Open Recent
            </span>
          </DropdownMenuSubTrigger>
          <DropdownMenuSubContent className="bg-[#131926] border-[#263249]">
            {recents.length === 0 && <DropdownMenuItem className="text-xs text-[#5C6B84]">No recent projects</DropdownMenuItem>}
            {recents.map((r, i) => (
              <DropdownMenuItem key={`${r.id}-${i}`} className="flex items-center justify-between gap-3 rounded px-2 py-1.5 text-xs data-[highlighted]:bg-[#1D2536]" onClick={() => openCloud.mutate(r.id)} data-testid={`file-recent-${i}`}>
                <span className="truncate">{r.name}</span>
                <span className="text-[10px] text-[#5C6B84]">{r.cloud ? "cloud" : ""}</span>
              </DropdownMenuItem>
            ))}
            {cloudProjects.data?.projects.length ? (
              <>
                <DropdownMenuSeparator />
                {cloudProjects.data.projects.map((p) => (
                  <DropdownMenuItem key={p.id} className="rounded px-2 py-1.5 text-xs text-[#FF5C7A] data-[highlighted]:bg-[#2B0B14]" onClick={() => deleteCloud.mutate(p.id)} data-testid={`file-recent-delete-${p.id}`}>
                    <span className="truncate">Delete {p.name}</span>
                  </DropdownMenuItem>
                ))}
              </>
            ) : null}
          </DropdownMenuSubContent>
        </DropdownMenuSub>
        <DropdownMenuSeparator />
        <Item icon={Save} label="Save .vjmap (download)" shortcut="Ctrl+S" testId="file-save" onClick={() => (downloadProject(doc), toast.success("Project downloaded"))} />
        <Item icon={CloudUpload} label="Save to Cloud" testId="file-save-cloud" onClick={() => saveCloud.mutate()} />
        <DropdownMenuSeparator />
        <Item icon={FileCode2} label="Import SVG…" testId="file-import-svg" onClick={() => store.set((s) => ({ importSvgRequest: s.importSvgRequest + 1 }))} />
        <Item icon={Image} label="Import Template PNG/JPG…" testId="file-import-template" onClick={() => store.set((s) => ({ importTemplateRequest: s.importTemplateRequest + 1 }))} />
        <Item icon={FileSpreadsheet} label="Import CSV Coordinates…" testId="file-import-csv" onClick={() => store.set((s) => ({ importCsvRequest: s.importCsvRequest + 1 }))} />
        <Item icon={FileDown} label="Export…" shortcut="Ctrl+E" testId="file-export" onClick={() => store.set({ exportOpen: true })} />
      </MenuBtn>

      <MenuBtn label="Edit" testId="edit">
        <Item icon={Undo2} label="Undo" shortcut="Ctrl+Z" testId="edit-undo" onClick={() => undo()} />
        <Item icon={Redo2} label="Redo" shortcut="Ctrl+Shift+Z" testId="edit-redo" onClick={() => redo()} />
        <DropdownMenuSeparator />
        <Item icon={Copy} label="Copy" shortcut="Ctrl+C" testId="edit-copy" onClick={() => copySelection()} />
        <Item icon={Clipboard} label="Paste" shortcut="Ctrl+V" testId="edit-paste" onClick={() => pasteClipboard()} />
        <Item label="Duplicate" shortcut="Ctrl+D" testId="edit-duplicate" onClick={() => duplicateSelection()} />
        <Item icon={Trash2} label="Delete" testId="edit-delete" onClick={() => deleteSelection()} />
        <DropdownMenuSeparator />
        <Item icon={SquareDashed} label="Select All" shortcut="Ctrl+A" testId="edit-select-all" onClick={() => selectAll()} />
        <Item label="Invert Selection" testId="edit-invert" onClick={() => invertSelection()} />
        <Item icon={Group} label="Group Selection" testId="edit-group" onClick={() => groupSelection()} />
        <Item icon={Ungroup} label="Ungroup" testId="edit-ungroup" onClick={() => ungroupSelection()} />
      </MenuBtn>

      <MenuBtn label="View" testId="view">
        <Item icon={ZoomIn} label="Zoom In" shortcut="+" testId="view-zoom-in" onClick={() => setZoomPreset(Math.min(8, (store.get().view.zoom || 1) * 1.25))} />
        <Item icon={ZoomOut} label="Zoom Out" shortcut="-" testId="view-zoom-out" onClick={() => setZoomPreset(Math.max(0.02, (store.get().view.zoom || 1) * 0.8))} />
        <Item icon={Maximize} label="Fit to View" shortcut="F" testId="view-fit" onClick={() => fitAll()} />
        <Item label="Zoom 100%" shortcut="Ctrl+1" testId="view-zoom-100" onClick={() => setZoomPreset("100")} />
        <DropdownMenuSeparator />
        <Item icon={Grid3X3} label={`${showGrid ? "✓ " : ""}Show Grid`} shortcut="G" testId="view-grid" onClick={() => store.set((s) => ({ showGrid: !s.showGrid }))} />
        <Item icon={Ruler} label={`${showRulers ? "✓ " : ""}Show Rulers`} testId="view-rulers" onClick={() => store.set((s) => ({ showRulers: !s.showRulers }))} />
        <Item icon={Magnet} label={`${snapGrid ? "✓ " : ""}Snap to Grid`} testId="view-snap" onClick={() => store.set((s) => ({ snapGrid: !s.snapGrid }))} />
        <Item icon={Scan} label={`${showBadges ? "✓ " : ""}Cabinet Number Badges`} testId="view-badges" onClick={() => store.set((s) => ({ showBadges: !s.showBadges }))} />
        <Item icon={Route} label={`${showCable ? "✓ " : ""}Cable Run Path`} testId="view-cable" onClick={() => store.set((s) => ({ showCable: !s.showCable }))} />
        <Item icon={Layers} label={`${stageMode ? "✓ " : ""}Stage Design Layer`} testId="view-stage" onClick={() => store.set((s) => ({ doc: { ...s.doc, stageMode: !s.doc.stageMode }, dirty: true }))} />
        <DropdownMenuSeparator />
        <Item icon={Crosshair} label={`${showSafe ? "✓ " : ""}Content Safe Area (5%)`} testId="view-safe" onClick={() => store.set((s) => ({ showSafe: !s.showSafe }))} />
        <Item label={`${checkerboard ? "✓ " : ""}Transparency Checkerboard`} testId="view-checker" onClick={() => store.set((s) => ({ checkerboard: !s.checkerboard }))} />
        <DropdownMenuSeparator />
        <Item icon={MonitorPlay} label="Fullscreen Preview" testId="view-preview" onClick={() => store.set({ previewOpen: true })} />
      </MenuBtn>

      <MenuBtn label="Project" testId="project">
        <Item icon={Calculator} label="Wall Calculator" testId="project-calc" onClick={() => store.set({ activeInspector: "calc", inspectorOpen: true })} />
        <Item icon={Presentation} label="Screen Templates & Presets" testId="project-templates" onClick={() => store.set({ activeInspector: "templates", inspectorOpen: true, presetsOpen: true })} />
        <Item icon={Network} label="Cabinet Flow & Patch…" shortcut="M" testId="project-cabinet" onClick={() => store.set({ cabinetOpen: true })} />
        <Item icon={MapIcon} label="Resolume Input Map PNG" testId="project-inputmap" onClick={() => exportPng(doc, "inputmap", doc.canvas.width, doc.canvas.height).then(() => toast.success("Resolume input map exported"))} />
        <Item icon={FileText} label="Technical Report / Show Sheet" testId="project-report" onClick={() => store.set({ reportOpen: true })} />
      </MenuBtn>

      <MenuBtn label="Tools" testId="tools">
        <Item icon={Calculator} label="Aspect / Resolution / Pitch Calculators" testId="tools-calculators" onClick={() => store.set({ toolsOpen: true })} />
        <Item icon={FileText} label="Generate Report" testId="tools-report" onClick={() => store.set({ reportOpen: true })} />
        <DropdownMenuSeparator />
        <Item icon={Keyboard} label="Keyboard Shortcuts" shortcut="?" testId="tools-shortcuts" onClick={() => store.set({ shortcutsOpen: true })} />
        <Item icon={CircleHelp} label="Resolume Workflow Guide" testId="tools-guide" onClick={() => store.set({ shortcutsOpen: true })} />
        <DropdownMenuSeparator />
        <Item icon={Download} label="Download Source Code + README (ZIP)" testId="tools-download-source" onClick={() => { window.location.href = "/api/download/source"; toast.success("Preparing source code ZIP…"); }} />
      </MenuBtn>

      <MenuBtn label="Export" testId="export">
        <Item icon={Image} label="Canvas PNG" testId="export-png" onClick={() => quickPng()} />
        <Item icon={Image} label="Transparent Content PNG" testId="export-png-transparent" onClick={() => exportPng(doc, "content", doc.canvas.width, doc.canvas.height).then(() => toast.success("Transparent PNG exported"))} />
        <Item icon={Film} label="PNG Sequence ZIP…" testId="export-seq" onClick={() => store.set({ exportOpen: true })} />
        <Item icon={FileCode2} label="Vector SVG" testId="export-svg" onClick={() => exportSvg(doc, true)} />
        <Item icon={FileSpreadsheet} label="CSV Coordinate Map" testId="export-csv" onClick={() => downloadCsv(doc, true)} />
        <Item icon={FileText} label="Technical Report PDF (print)" testId="export-report" onClick={() => store.set({ reportOpen: true })} />
        <Item icon={Images} label="All Exports…" testId="export-all" onClick={() => store.set({ exportOpen: true })} />
      </MenuBtn>

      {/* center: project title */}
      <div className="mx-auto flex min-w-0 items-center gap-2 px-4">
        <input
          value={doc.name}
          onChange={(e) => store.set((s) => ({ doc: { ...s.doc, name: e.target.value }, dirty: true }))}
          className="w-[280px] rounded border border-transparent bg-transparent px-2 py-0.5 text-center text-xs text-[#F0F4FC] hover:border-[#212A3D] focus:border-[#00F0FF] focus:outline-none"
          data-testid="project-name-input"
          aria-label="Project name"
        />
        <span className={`size-1.5 rounded-full ${dirty ? "bg-[#FFB800]" : "bg-[#00FFA3]"}`} title={dirty ? "Unsaved changes (autosaved locally)" : "Saved"} data-testid="project-dirty-dot" />
      </div>

      {/* right: canvas pill + quick actions */}
      <div className="flex items-center gap-2">
        <span className="hidden rounded bg-[#171D2A] px-2 py-1 font-mono text-[10px] text-[#8A99B5] lg:inline" data-testid="canvas-pill">
          {doc.canvas.width}×{doc.canvas.height} @ {doc.canvas.fps}FPS · {((doc.canvas.width * doc.canvas.height) / 1e6).toFixed(2)} MP
        </span>
        <Button size="sm" variant="secondary" onClick={() => (downloadProject(doc), toast.success("Project downloaded"))} data-testid="quick-save-btn" title="Save .vjmap (Ctrl+S)">
          <Save className="size-3.5" /> Save
        </Button>
        <Button size="sm" onClick={() => store.set({ exportOpen: true })} data-testid="quick-export-btn" title="Export (Ctrl+E)" className="bg-[#00F0FF] text-[#05090F] hover:bg-[#00F0FF]/80">
          <Download className="size-3.5" /> Export
        </Button>
        <Button size="sm" variant="ghost" onClick={() => store.set({ shortcutsOpen: true })} data-testid="quick-shortcuts-btn" title="Shortcuts (?)">
          <Keyboard className="size-3.5" />
        </Button>
      </div>
    </div>
  );
}


