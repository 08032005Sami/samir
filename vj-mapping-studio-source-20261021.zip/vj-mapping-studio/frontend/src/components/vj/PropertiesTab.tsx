// Context-sensitive properties inspector: canvas / screen / shape / multi-selection.

import { useRef, useState } from "react";
import type { LedScreen, Shape, Units } from "@/lib/types";
import {
  store,
  useEditor,
  patchScreen,
  patchShape,
  patchCanvas,
  patchStage,
  alignSelection,
  distributeSelection,
  duplicateSelection,
  deleteSelection,
  groupSelection,
  ungroupSelection,
  reorderSelection,
  smartCenter,
  toggleLock,
  toggleVisible,
} from "@/lib/store";
import { ORDERS } from "@/lib/project";
import { screenPitchMm, screenPhysMm, screenRes, screenPower, screenWeightKg, reduceAspect, pxToUnitStr, docPitchMm } from "@/lib/led";
import { fmtInt, fmtNum } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ColorField } from "./ColorField";
import {
  AlignStartVertical,
  AlignCenterVertical,
  AlignEndVertical,
  AlignStartHorizontal,
  AlignCenterHorizontal,
  AlignEndHorizontal,
  AlignHorizontalSpaceAround,
  AlignVerticalSpaceAround,
  Lock,
  LockOpen,
  Eye,
  EyeOff,
  CopyPlus,
  Trash2,
  Group as GroupIcon,
  Ungroup as UngroupIcon,
  ChevronsUp,
  ChevronUp,
  ChevronDown,
  ChevronsDown,
  Crosshair,
  DraftingCompass,
} from "lucide-react";

function Row({ label, children, testId }: { label: string; children: React.ReactNode; testId?: string }) {
  return (
    <div className="flex items-center justify-between gap-2" data-testid={testId}>
      <span className="shrink-0 text-[10px] uppercase tracking-wider text-[#8292AD]">{label}</span>
      <div className="flex min-w-0 items-center gap-1.5">{children}</div>
    </div>
  );
}

function NumRow({
  label,
  value,
  onChange,
  testId,
  step = 1,
  min,
  max,
  suffix,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  testId: string;
  step?: number;
  min?: number;
  max?: number;
  suffix?: string;
}) {
  const [local, setLocal] = useState<number | null>(null);
  const pushedRef = useRef(false);
  const shown = local ?? value;
  return (
    <Row label={label}>
      <Input
        type="number"
        value={Number.isFinite(shown) ? shown : 0}
        step={step}
        min={min}
        max={max}
        onFocus={() => (pushedRef.current = false)}
        onChange={(e) => {
          const v = Number(e.target.value);
          setLocal(v);
          if (!pushedRef.current) {
            store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] }));
            pushedRef.current = true;
          }
          onChange(v);
        }}
        onBlur={() => {
          setLocal(null);
          store.set({ dirty: true });
        }}
        className="h-7 w-[92px] border-[#212A3D] bg-[#0B0D13] font-mono text-xs text-[#F0F4FC]"
        data-testid={testId}
      />
      {suffix && <span className="font-mono text-[10px] text-[#5C6B84]">{suffix}</span>}
    </Row>
  );
}

function Section({ title, children, right }: { title: string; children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div className="rounded border border-[#212A3D] bg-[#121722] p-2.5">
      <div className="mb-2 flex items-center justify-between">
        <h4 className="font-heading text-[10px] font-bold uppercase tracking-[0.08em] text-[#8292AD]">{title}</h4>
        {right}
      </div>
      <div className="space-y-1.5">{children}</div>
    </div>
  );
}

function CanvasProps() {
  const doc = useEditor((s) => s.doc);
  const showSafe = useEditor((s) => s.showSafe);
  const safePct = useEditor((s) => s.safePct);
  const checkerboard = useEditor((s) => s.checkerboard);
  const gridSize = useEditor((s) => s.gridSize);
  const units = useEditor((s) => s.units);
  const [aw, ah] = reduceAspect(doc.canvas.width, doc.canvas.height);

  return (
    <div className="space-y-2">
      <Section title="Canvas">
        <NumRow label="Width" value={doc.canvas.width} onChange={(v) => patchCanvas({ width: Math.max(1, Math.round(v)) })} testId="canvas-width-input" step={64} />
        <NumRow label="Height" value={doc.canvas.height} onChange={(v) => patchCanvas({ height: Math.max(1, Math.round(v)) })} testId="canvas-height-input" step={64} />
        <Row label="Aspect">
          <span className="font-mono text-xs text-[#00F0FF]" data-testid="canvas-aspect-readout">
            {aw}:{ah} ({(doc.canvas.width / doc.canvas.height).toFixed(3)})
          </span>
        </Row>
        <Row label="Pixels">
          <span className="font-mono text-xs text-[#F0F4FC]" data-testid="canvas-pixels-readout">
            {fmtInt(doc.canvas.width * doc.canvas.height)} ({((doc.canvas.width * doc.canvas.height) / 1e6).toFixed(2)} MP)
          </span>
        </Row>
        <Row label="Background">
          <ColorField value={doc.canvas.background === "transparent" ? "#05070B" : doc.canvas.background} onChange={(c) => patchCanvas({ background: c })} testId="canvas-bg-color" />
          <Button size="xs" variant={doc.canvas.background === "transparent" ? "secondary" : "outline"} onClick={() => patchCanvas({ background: doc.canvas.background === "transparent" ? "#05070B" : "transparent" })} data-testid="canvas-bg-transparent-btn">
            transparent
          </Button>
        </Row>
        <Row label="Checkerboard">
          <Checkbox checked={checkerboard} onCheckedChange={(c) => store.set({ checkerboard: c === true })} data-testid="canvas-checkerboard" />
        </Row>
        <Row label="Safe Area">
          <Checkbox
            checked={showSafe}
            onCheckedChange={(c) => store.set({ showSafe: c === true })}
            data-testid="canvas-safe-toggle"
          />
          <Select value={String(safePct)} onValueChange={(v) => store.set({ safePct: Number(v) })}>
            <SelectTrigger size="sm" className="w-[70px] font-mono text-[11px]" data-testid="canvas-safe-pct">
              <SelectValue>{safePct}%</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {["5", "10", "15"].map((p) => (
                <SelectItem key={p} value={p}>
                  {p}%
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Row>
        <NumRow label="Grid Size" value={gridSize} onChange={(v) => store.set({ gridSize: Math.max(4, v) })} testId="canvas-grid-size" step={8} suffix="px" />
        <Row label="Ruler Units">
          <Select value={units} onValueChange={(v) => store.set({ units: v as Units })}>
            <SelectTrigger size="sm" className="w-[70px] font-mono text-[11px]" data-testid="canvas-units">
              <SelectValue>{units}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {["px", "m", "cm", "mm", "ft"].map((u) => (
                <SelectItem key={u} value={u}>
                  {u}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </Row>
      </Section>

      <Button variant="secondary" className="w-full" onClick={smartCenter} data-testid="canvas-smart-center">
        <Crosshair className="size-3.5" /> Smart Center Composition
      </Button>

      <p className="px-1 text-[10px] leading-relaxed text-[#5C6B84]">
        Select a screen or shape on the canvas to edit its properties. Drag to move · handles to scale · top handle to rotate.
      </p>
    </div>
  );
}

function ScreenProps({ s }: { s: LedScreen }) {
  const res = screenRes(s);
  const phys = screenPhysMm(s);
  const pitch = screenPitchMm(s);
  const power = screenPower(s);
  const [aw, ah] = reduceAspect(res.w, res.h);
  const doc = useEditor((st) => st.doc);
  const units = useEditor((st) => st.units);
  const p = docPitchMm(doc, s.id);
  void p;

  return (
    <div className="space-y-2" data-testid="screen-props">
      <Section title={`LED Screen — ${s.name}`}>
        <Row label="Name">
          <Input
            value={s.name}
            onChange={(e) => patchScreen(s.id, { name: e.target.value }, false)}
            className="h-7 w-[150px] border-[#212A3D] bg-[#0B0D13] text-xs"
            data-testid="screen-name-input"
          />
        </Row>
        <Row label="Position">
          <NumRowInline label="" value={Math.round(s.x)} onChange={(v) => patchScreen(s.id, { x: v })} testId="screen-x-input" suffix="X" />
          <NumRowInline label="" value={Math.round(s.y)} onChange={(v) => patchScreen(s.id, { y: v })} testId="screen-y-input" suffix="Y" />
        </Row>
        <Row label="Rotation">
          <input
            type="range"
            min={-180}
            max={180}
            step={1}
            value={s.rotation}
            onChange={(e) => patchScreen(s.id, { rotation: Number(e.target.value) }, false)}
            className="vj-range w-[110px]"
            data-testid="screen-rotation-slider"
          />
          <NumRowInline label="" value={s.rotation} onChange={(v) => patchScreen(s.id, { rotation: v })} testId="screen-rotation-input" suffix="°" />
        </Row>
        <Row label="Ident Color">
          <ColorField value={s.color} onChange={(c) => patchScreen(s.id, { color: c })} testId="screen-color" />
        </Row>
      </Section>

      <Section title="Cabinet Configuration">
        <NumRow label="Cabinets X" value={s.cabsX} onChange={(v) => patchScreen(s.id, { cabsX: Math.max(1, Math.round(v)) })} testId="screen-cabs-x" min={1} />
        <NumRow label="Cabinets Y" value={s.cabsY} onChange={(v) => patchScreen(s.id, { cabsY: Math.max(1, Math.round(v)) })} testId="screen-cabs-y" min={1} />
        <NumRow label="Cab Res X" value={s.cabResX} onChange={(v) => patchScreen(s.id, { cabResX: Math.max(1, Math.round(v)) })} testId="screen-cab-res-x" min={1} />
        <NumRow label="Cab Res Y" value={s.cabResY} onChange={(v) => patchScreen(s.id, { cabResY: Math.max(1, Math.round(v)) })} testId="screen-cab-res-y" min={1} />
        <NumRow label="Cab W" value={s.cabW} onChange={(v) => patchScreen(s.id, { cabW: Math.max(1, v) })} testId="screen-cab-w" step={10} suffix="mm" />
        <NumRow label="Cab H" value={s.cabH} onChange={(v) => patchScreen(s.id, { cabH: Math.max(1, v) })} testId="screen-cab-h" step={10} suffix="mm" />
      </Section>

      <Section title="Derived">
        <Row label="Resolution">
          <span className="font-mono text-xs text-[#00F0FF]" data-testid="screen-res-readout">{res.w} × {res.h} px</span>
        </Row>
        <Row label="Physical">
          <span className="font-mono text-xs text-[#F0F4FC]">{fmtNum(phys.w / 1000, 2)} × {fmtNum(phys.h / 1000, 2)} m</span>
        </Row>
        <Row label="In feet">
          <span className="font-mono text-xs text-[#F0F4FC]">{pxToUnitStr(res.w, "ft", pitch)} × {pxToUnitStr(res.h, "ft", pitch)}</span>
        </Row>
        <Row label="Pitch / Aspect">
          <span className="font-mono text-xs text-[#F0F4FC]">{fmtNum(pitch, 2)} mm · {aw}:{ah}</span>
        </Row>
        <Row label="Cabinets / Power">
          <span className="font-mono text-xs text-[#F0F4FC]">{s.cabsX * s.cabsY} · ~{fmtInt(power.typical)}W (est)</span>
        </Row>
        <Row label="Weight (est)">
          <span className="font-mono text-xs text-[#F0F4FC]">{fmtInt(screenWeightKg(s))} kg</span>
        </Row>
      </Section>

      <Section title="Mapping Order">
        <Select value={s.order} onValueChange={(v) => patchScreen(s.id, { order: v as LedScreen["order"] })}>
          <SelectTrigger size="sm" className="w-full text-xs" data-testid="screen-order-select">
            <SelectValue>{ORDERS.find((o) => o.id === s.order)?.name ?? s.order}</SelectValue>
          </SelectTrigger>
          <SelectContent className="bg-[#131926] border-[#263249]">
            {ORDERS.map((o) => (
              <SelectItem key={o.id} value={o.id} className="text-xs">
                {o.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="secondary" className="w-full" onClick={() => store.set({ cabinetOpen: true })} data-testid="screen-open-cabinet-flow">
          <DraftingCompass className="size-3.5" /> Cabinet Flow & Pixel Ranges
        </Button>
      </Section>

      <ItemActions
        locked={s.locked}
        visible={s.visible}
        id={s.id}
        onLock={() => toggleLock(s.id)}
        onVisible={() => toggleVisible(s.id)}
      />
    </div>
  );
}

function NumRowInline({ value, onChange, testId, suffix, step = 1 }: { label: string; value: number; onChange: (v: number) => void; testId: string; suffix?: string; step?: number }) {
  const [local, setLocal] = useState<number | null>(null);
  const pushedRef = useRef(false);
  const shown = local ?? value;
  return (
    <span className="flex items-center gap-1">
      {suffix && <span className="font-mono text-[10px] text-[#5C6B84]">{suffix}</span>}
      <Input
        type="number"
        value={Number.isFinite(shown) ? shown : 0}
        step={step}
        onFocus={() => (pushedRef.current = false)}
        onChange={(e) => {
          const v = Number(e.target.value);
          setLocal(v);
          if (!pushedRef.current) {
            store.set((s) => ({ past: [...s.past.slice(-79), JSON.stringify(s.doc)], future: [] }));
            pushedRef.current = true;
          }
          onChange(v);
        }}
        onBlur={() => setLocal(null)}
        className="h-7 w-[70px] border-[#212A3D] bg-[#0B0D13] font-mono text-xs text-[#F0F4FC]"
        data-testid={testId}
      />
    </span>
  );
}

function ShapeProps({ s }: { s: Shape }) {
  const canEditPoints = !!s.points;
  return (
    <div className="space-y-2" data-testid="shape-props">
      <Section title={`Border FX Shape — ${s.name}`}>
        <Row label="Name">
          <Input value={s.name} onChange={(e) => patchShape(s.id, { name: e.target.value }, false)} className="h-7 w-[150px] border-[#212A3D] bg-[#0B0D13] text-xs" data-testid="shape-name-input" />
        </Row>
        <Row label="Position">
          <NumRowInline label="" value={Math.round(s.x)} onChange={(v) => patchShape(s.id, { x: v })} testId="shape-x-input" suffix="X" />
          <NumRowInline label="" value={Math.round(s.y)} onChange={(v) => patchShape(s.id, { y: v })} testId="shape-y-input" suffix="Y" />
        </Row>
        <Row label="Size">
          <NumRowInline label="" value={Math.round(s.w)} onChange={(v) => patchShape(s.id, { w: Math.max(1, v) })} testId="shape-w-input" suffix="W" />
          <NumRowInline label="" value={Math.round(s.h)} onChange={(v) => patchShape(s.id, { h: Math.max(1, v) })} testId="shape-h-input" suffix="H" />
        </Row>
        <Row label="Rotation">
          <input type="range" min={-180} max={180} value={s.rotation} onChange={(e) => patchShape(s.id, { rotation: Number(e.target.value) }, false)} className="vj-range w-[110px]" data-testid="shape-rotation-slider" />
          <NumRowInline label="" value={s.rotation} onChange={(v) => patchShape(s.id, { rotation: v })} testId="shape-rotation-input" suffix="°" />
        </Row>
        {canEditPoints && (
          <PointEditor shape={s} />
        )}
      </Section>

      <Section title="Stroke & Fill">
        <Row label="Color">
          <ColorField value={s.fx.enabled ? s.fx.color : s.stroke} onChange={(c) => (s.fx.enabled ? patchShape(s.id, { fx: { ...s.fx, color: c } }) : patchShape(s.id, { stroke: c }))} testId="shape-color" />
          <Button size="xs" variant={s.fx.enabled ? "secondary" : "outline"} onClick={() => patchShape(s.id, { fx: { ...s.fx, enabled: !s.fx.enabled } })} data-testid="shape-fx-toggle">
            FX {s.fx.enabled ? "ON" : "OFF"}
          </Button>
        </Row>
        <NumRow label="Thickness" value={s.strokeWidth} onChange={(v) => patchShape(s.id, { strokeWidth: Math.max(1, v) })} testId="shape-stroke-width" suffix="px" />
        <NumRow label="Glow" value={s.fx.enabled ? s.fx.glow : s.glow} onChange={(v) => (s.fx.enabled ? patchShape(s.id, { fx: { ...s.fx, glow: Math.max(0, v) } }) : patchShape(s.id, { glow: Math.max(0, v) }))} testId="shape-glow" suffix="px" />
        <NumRow label="Blur" value={s.blur} onChange={(v) => patchShape(s.id, { blur: Math.max(0, v) })} testId="shape-blur" suffix="px" />
        <Row label="Opacity">
          <input
            type="range"
            min={0.05}
            max={1}
            step={0.05}
            value={s.opacity}
            onChange={(e) => patchShape(s.id, { opacity: Number(e.target.value) }, false)}
            className="vj-range w-[130px]"
            data-testid="shape-opacity-slider"
          />
          <span className="w-10 font-mono text-[10px] text-[#F0F4FC]">{Math.round(s.opacity * 100)}%</span>
        </Row>
        <Row label="Fill">
          <Checkbox
            checked={s.fill !== null}
            onCheckedChange={(c) => patchShape(s.id, { fill: c === true ? s.fx.color : null })}
            data-testid="shape-fill-toggle"
          />
          {s.fill !== null && (
            <>
              <ColorField value={s.fill} onChange={(c) => patchShape(s.id, { fill: c })} testId="shape-fill-color" />
              <NumRowInline label="" value={Math.round(s.fillOpacity * 100)} onChange={(v) => patchShape(s.id, { fillOpacity: Math.min(1, Math.max(0, v / 100)) })} testId="shape-fill-opacity" suffix="%" />
            </>
          )}
        </Row>
        <Row label="Dash">
          <Input
            value={s.dash}
            placeholder='e.g. "8 6" (blank = solid)'
            onChange={(e) => patchShape(s.id, { dash: e.target.value }, false)}
            className="h-7 w-[150px] border-[#212A3D] bg-[#0B0D13] font-mono text-xs"
            data-testid="shape-dash-input"
          />
        </Row>
        {s.kind === "rrect" && <NumRow label="Corner Radius" value={s.corner} onChange={(v) => patchShape(s.id, { corner: Math.max(0, v) })} testId="shape-corner" suffix="px" />}
        {s.kind === "star" && <NumRow label="Star Points" value={s.sides} onChange={(v) => patchShape(s.id, { sides: Math.max(5, Math.round(v)) })} testId="shape-star-points" />}
      </Section>

      <div className="flex gap-1.5">
        <Button variant="secondary" className="flex-1" onClick={() => store.set({ activeInspector: "fx" })} data-testid="shape-edit-fx-btn">
          Edit FX →
        </Button>
      </div>

      <ItemActions locked={s.locked} visible={s.visible} id={s.id} onLock={() => toggleLock(s.id)} onVisible={() => toggleVisible(s.id)} />
    </div>
  );
}

function PointEditor({ shape }: { shape: Shape }) {
  const pts = shape.points ?? [];
  return (
    <Row label="Points">
      <span className="font-mono text-[10px] text-[#8A99B5]">{pts.length} vertices</span>
      <Button
        size="xs"
        variant={store.get().editPoints ? "secondary" : "outline"}
        onClick={() => store.set((s) => ({ editPoints: !s.editPoints }))}
        data-testid="shape-point-edit-toggle"
      >
        {store.get().editPoints ? "Done editing" : "Edit points"}
      </Button>
    </Row>
  );
}

function StageProps({ o }: { o: { id: string; label: string; x: number; y: number; w: number; h: number; rotation: number; color: string; locked: boolean; visible: boolean } }) {
  return (
    <div className="space-y-2" data-testid="stage-props">
      <Section title={`Stage Object — ${o.label}`}>
        <Row label="Label">
          <Input value={o.label} onChange={(e) => patchStage(o.id, { label: e.target.value }, false)} className="h-7 w-[150px] border-[#212A3D] bg-[#0B0D13] text-xs" data-testid="stage-label-input" />
        </Row>
        <Row label="Position">
          <NumRowInline label="" value={Math.round(o.x)} onChange={(v) => patchStage(o.id, { x: v })} testId="stage-x-input" suffix="X" />
          <NumRowInline label="" value={Math.round(o.y)} onChange={(v) => patchStage(o.id, { y: v })} testId="stage-y-input" suffix="Y" />
        </Row>
        <Row label="Size">
          <NumRowInline label="" value={Math.round(o.w)} onChange={(v) => patchStage(o.id, { w: Math.max(4, v) })} testId="stage-w-input" suffix="W" />
          <NumRowInline label="" value={Math.round(o.h)} onChange={(v) => patchStage(o.id, { h: Math.max(4, v) })} testId="stage-h-input" suffix="H" />
        </Row>
        <Row label="Color">
          <ColorField value={o.color} onChange={(c) => patchStage(o.id, { color: c })} testId="stage-color" />
        </Row>
      </Section>
      <ItemActions locked={o.locked} visible={o.visible} id={o.id} onLock={() => toggleLock(o.id)} onVisible={() => toggleVisible(o.id)} />
    </div>
  );
}

function ItemActions({ locked, visible, id, onLock, onVisible }: { locked: boolean; visible: boolean; id: string; onLock: () => void; onVisible: () => void }) {
  void id;
  return (
    <Section title="Item">
      <div className="flex flex-wrap gap-1">
        <Button size="xs" variant="outline" onClick={onLock} data-testid="item-lock-btn">
          {locked ? <Lock className="size-3" /> : <LockOpen className="size-3" />} {locked ? "Locked" : "Lock"}
        </Button>
        <Button size="xs" variant="outline" onClick={onVisible} data-testid="item-visible-btn">
          {visible ? <Eye className="size-3" /> : <EyeOff className="size-3" />} {visible ? "Visible" : "Hidden"}
        </Button>
        <Button size="xs" variant="outline" onClick={() => duplicateSelection()} data-testid="item-duplicate-btn">
          <CopyPlus className="size-3" /> Duplicate
        </Button>
        <Button size="xs" variant="outline" onClick={() => deleteSelection()} data-testid="item-delete-btn" className="text-[#FF5C7A]">
          <Trash2 className="size-3" /> Delete
        </Button>
      </div>
      <Row label="Z-Order">
        <Button size="icon-xs" variant="outline" onClick={() => reorderSelection("back")} title="Send to back" data-testid="z-back-btn"><ChevronsDown className="size-3" /></Button>
        <Button size="icon-xs" variant="outline" onClick={() => reorderSelection("down")} title="Send backward" data-testid="z-down-btn"><ChevronDown className="size-3" /></Button>
        <Button size="icon-xs" variant="outline" onClick={() => reorderSelection("up")} title="Bring forward" data-testid="z-up-btn"><ChevronUp className="size-3" /></Button>
        <Button size="icon-xs" variant="outline" onClick={() => reorderSelection("front")} title="Bring to front" data-testid="z-front-btn"><ChevronsUp className="size-3" /></Button>
      </Row>
    </Section>
  );
}

function MultiProps({ ids }: { ids: string[] }) {
  return (
    <div className="space-y-2" data-testid="multi-props">
      <Section title={`${ids.length} items selected`}>
        <div className="grid grid-cols-3 gap-1">
          <Button size="xs" variant="outline" onClick={() => alignSelection("left")} data-testid="align-left"><AlignStartVertical className="size-3" /> L</Button>
          <Button size="xs" variant="outline" onClick={() => alignSelection("hcenter")} data-testid="align-hcenter"><AlignCenterVertical className="size-3" /> C</Button>
          <Button size="xs" variant="outline" onClick={() => alignSelection("right")} data-testid="align-right"><AlignEndVertical className="size-3" /> R</Button>
          <Button size="xs" variant="outline" onClick={() => alignSelection("top")} data-testid="align-top"><AlignStartHorizontal className="size-3" /> T</Button>
          <Button size="xs" variant="outline" onClick={() => alignSelection("vcenter")} data-testid="align-vcenter"><AlignCenterHorizontal className="size-3" /> M</Button>
          <Button size="xs" variant="outline" onClick={() => alignSelection("bottom")} data-testid="align-bottom"><AlignEndHorizontal className="size-3" /> B</Button>
          <Button size="xs" variant="outline" onClick={() => distributeSelection("h")} data-testid="distribute-h" className="col-span-3">
            <AlignHorizontalSpaceAround className="size-3" /> Distribute Horizontally
          </Button>
          <Button size="xs" variant="outline" onClick={() => distributeSelection("v")} data-testid="distribute-v" className="col-span-3">
            <AlignVerticalSpaceAround className="size-3" /> Distribute Vertically
          </Button>
        </div>
      </Section>
      <Section title="Group">
        <div className="flex gap-1.5">
          <Button size="xs" variant="secondary" className="flex-1" onClick={() => groupSelection()} data-testid="group-btn"><GroupIcon className="size-3" /> Group</Button>
          <Button size="xs" variant="outline" className="flex-1" onClick={() => ungroupSelection()} data-testid="ungroup-btn"><UngroupIcon className="size-3" /> Ungroup</Button>
        </div>
        <p className="text-[10px] text-[#5C6B84]">Grouped items move and resize together on canvas.</p>
      </Section>
      <ItemActions locked={false} visible={true} id={ids[0]} onLock={() => ids.forEach((id) => toggleLock(id))} onVisible={() => ids.forEach((id) => toggleVisible(id))} />
    </div>
  );
}

export default function PropertiesTab() {
  const doc = useEditor((s) => s.doc);
  const selection = useEditor((s) => s.selection);
  const editPoints = useEditor((s) => s.editPoints);

  void editPoints;
  if (selection.length > 1) return <MultiProps ids={selection} />;
  if (selection.length === 1) {
    const id = selection[0];
    const sc = doc.screens.find((x) => x.id === id);
    if (sc) return <ScreenProps s={sc} key={id} />;
    const sh = doc.shapes.find((x) => x.id === id);
    if (sh) return <ShapeProps s={sh} key={id} />;
    const so = doc.stage.find((x) => x.id === id);
    if (so) return <StageProps o={so} key={id} />;
  }
  return <CanvasProps />;
}

export { Label };
