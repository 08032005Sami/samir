// Status bar: coordinate readout (global/screen/cabinet modes), selection info,
// hardware totals, engine status, zoom + unit controls.

import { store, useEditor, setZoomPreset, fitAll } from "@/lib/store";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { docTotals, docPitchMm, pxToUnitStr, screenPower, screenRes } from "@/lib/led";
import { fmtInt, fmtNum } from "@/lib/format";

export default function StatusBar() {
  const cursorInfo = useEditor((s) => s.cursorInfo);
  const units = useEditor((s) => s.units);
  const doc = useEditor((s) => s.doc);
  const selection = useEditor((s) => s.selection);
  const zoom = useEditor((s) => s.view.zoom);
  const fpsMeter = useEditor((s) => s.fpsMeter);
  const tool = useEditor((s) => s.tool);

  const pitch = docPitchMm(doc, cursorInfo?.screenId ?? selection[0] ?? null);
  const totals = docTotals(doc);

  const selScreen = selection.length === 1 ? doc.screens.find((s) => s.id === selection[0]) : null;
  const selRes = selScreen ? screenRes(selScreen) : null;

  return (
    <div
      className="flex h-[26px] shrink-0 items-center gap-4 border-t border-[#212A3D] bg-[#090C12] px-3 font-mono text-[11px] text-[#A5B4CD]"
      data-testid="status-bar"
    >
      {/* coordinates */}
      <div className="flex items-center gap-3" data-testid="status-coords">
        <span className="text-[#5C6B84]">X</span>
        <span className="text-[#F0F4FC]">{cursorInfo ? cursorInfo.gx : "—"}</span>
        <span className="text-[#5C6B84]">Y</span>
        <span className="text-[#F0F4FC]">{cursorInfo ? cursorInfo.gy : "—"}</span>
        <span className="text-[#5C6B84]">| {pxToUnitStr(cursorInfo?.gx ?? 0, units, pitch)}</span>
        {cursorInfo?.screenName && (
          <span className="text-[#00F0FF]">
            {cursorInfo.screenName} · C{cursorInfo.cabinet ?? "—"} · local {cursorInfo.lx},{cursorInfo.ly}
          </span>
        )}
      </div>

      {/* selection */}
      <div className="min-w-0 flex-1 truncate" data-testid="status-selection">
        {selScreen && selRes ? (
          <span>
            Selected: <span className="text-[#00F0FF]">{selScreen.name}</span> — {selRes.w}×{selRes.h}px · {selScreen.cabsX * selScreen.cabsY} cab ·{" "}
            {pxToUnitStr(selRes.w, "ft", docPitchMm(doc, selScreen.id))} × {pxToUnitStr(selRes.h, "ft", docPitchMm(doc, selScreen.id))} · ~
            {fmtInt(screenPower(selScreen).typical)} W typ
          </span>
        ) : selection.length > 1 ? (
          <span>{selection.length} items selected</span>
        ) : (
          <span className="text-[#5C6B84]">{tool !== "select" ? `Tool: ${tool} — drag on canvas` : "Ready"}</span>
        )}
      </div>

      {/* hardware totals */}
      <div className="flex items-center gap-3" data-testid="status-totals">
        <span title="Total canvas resolution">{doc.canvas.width}×{doc.canvas.height}</span>
        <span title="Megapixels" className="text-[#00F0FF]">{fmtNum(totals.mp, 2)} MP</span>
        <span title="Total cabinets">{fmtInt(totals.cabinets)} cab</span>
        <span title="Sending-card ports @650k px/port (estimate)">{totals.ports} port{totals.ports > 1 ? "s" : ""}</span>
        <span title="Typical power (estimate)">{fmtInt(totals.powerTypical)} W</span>
      </div>

      {/* engine + zoom + units */}
      <div className="flex items-center gap-2">
        <span className="flex items-center gap-1 text-[#00FFA3]" data-testid="status-engine" title="2D canvas renderer active">
          <span className="inline-block size-1.5 animate-pulse rounded-full bg-[#00FFA3]" />
          READY · {fpsMeter} FPS UI
        </span>
        <Select value={units} onValueChange={(v) => store.set({ units: v as typeof units })}>
          <SelectTrigger size="sm" className="h-5 w-[64px] font-mono text-[11px]" data-testid="status-units-select">
            <SelectValue>{units}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {["px", "m", "cm", "mm", "ft"].map((u) => (
              <SelectItem key={u} value={u}>
                {u}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <button
          className="rounded border border-[#212A3D] px-1.5 py-0.5 hover:bg-[#1D2536]"
          onClick={() => setZoomPreset("fit")}
          data-testid="status-zoom-btn"
          title="Fit to view (F / Ctrl+0)"
        >
          {Math.round(zoom * 100)}%
        </button>
        <button className="rounded border border-[#212A3D] px-1.5 py-0.5 hover:bg-[#1D2536]" onClick={() => fitAll()} data-testid="status-fit-btn">
          FIT
        </button>
      </div>
    </div>
  );
}
