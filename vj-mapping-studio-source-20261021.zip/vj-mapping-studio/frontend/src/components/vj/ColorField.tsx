// Color field with HEX / RGB / HSL entry, native picker, eyedropper,
// recent colors and favorites — used across inspector + FX tabs.

import { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Pipette, Star, StarOff } from "lucide-react";
import { hexToRgb, rgbToHex, hslToRgb } from "@/lib/effects";
import { getRecentColors, pushRecentColor } from "@/lib/project";

interface FavColors {
  get: () => string[];
  toggle: (c: string) => void;
}

const favStore: FavColors = {
  get: () => {
    try {
      return JSON.parse(localStorage.getItem("vjmap.color_favs.v1") ?? '["#00F0FF","#FF007F","#00FFA3","#FFB800","#7C4DFF"]') as string[];
    } catch {
      return [];
    }
  },
  toggle: (c) => {
    const list = favStore.get();
    const at = list.indexOf(c);
    if (at >= 0) list.splice(at, 1);
    else list.unshift(c);
    localStorage.setItem("vjmap.color_favs.v1", JSON.stringify(list.slice(0, 16)));
  },
};

interface ColorFieldProps {
  value: string;
  onChange: (hex: string) => void;
  testId?: string;
  label?: string;
}

export function ColorField({ value, onChange, testId, label }: ColorFieldProps) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"hex" | "rgb" | "hsl">("hex");
  const [rgbText, setRgbText] = useState("");
  const [hslText, setHslText] = useState("");
  const rgb = hexToRgb(value);

  const commit = (hex: string) => {
    onChange(hex);
    pushRecentColor(hex);
  };

  const pickEyedropper = async () => {
    const ed = (window as unknown as { EyeDropper?: new () => { open: () => Promise<{ sRGBHex: string }> } }).EyeDropper;
    if (!ed) return;
    try {
      const res = new ed();
      const { sRGBHex } = await res.open();
      commit(sRGBHex);
    } catch {
      /* user cancelled */
    }
  };

  const parseRgb = (t: string) => {
    const m = t.match(/(\d+)[,\s]+(\d+)[,\s]+(\d+)/);
    if (m) commit(rgbToHex(Number(m[1]), Number(m[2]), Number(m[3])));
  };
  const parseHsl = (t: string) => {
    const m = t.match(/(\d+)[,\s]+(\d+)%?[,\s]+(\d+)%?/);
    if (m) {
      const [r, g, b] = hslToRgb(Number(m[1]), Number(m[2]) / 100, Number(m[3]) / 100);
      commit(rgbToHex(r, g, b));
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger
        render={
          <button
            className="flex items-center gap-2 rounded border border-[#212A3D] bg-[#0B0D13] px-2 py-1 hover:border-[#00F0FF]/50"
            data-testid={testId ? `${testId}-trigger` : "color-field-trigger"}
            aria-label={label ?? "Color picker"}
          >
            <span className="size-4 shrink-0 rounded-sm border border-[#212A3D]" style={{ background: value }} />
            <span className="font-mono text-[11px] uppercase text-[#F0F4FC]">{value}</span>
          </button>
        }
      />
      <PopoverContent className="w-[248px] bg-[#131926] border-[#263249]" align="end">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={value}
              onChange={(e) => commit(e.target.value)}
              className="h-8 w-10 cursor-pointer rounded border border-[#212A3D] bg-transparent"
              data-testid={testId ? `${testId}-native` : "color-native"}
              aria-label="Native color picker"
            />
            <Input
              value={value}
              onChange={(e) => {
                const v = e.target.value;
                if (/^#[0-9a-fA-F]{6}$/.test(v)) commit(v);
              }}
              className="h-8 flex-1 font-mono text-xs"
              data-testid={testId ? `${testId}-hex` : "color-hex"}
              placeholder="#00F0FF"
            />
            <Button variant="ghost" size="icon-sm" onClick={pickEyedropper} title="Eyedropper (Chrome/Edge)" data-testid={testId ? `${testId}-eyedropper` : "color-eyedropper"}>
              <Pipette className="size-3.5" />
            </Button>
          </div>

          <div className="flex gap-1 text-[10px] font-mono">
            {(["hex", "rgb", "hsl"] as const).map((t) => (
              <button
                key={t}
                className={`rounded px-2 py-0.5 uppercase ${tab === t ? "bg-[#1D2536] text-[#00F0FF]" : "text-[#8A99B5] hover:bg-[#1D2536]"}`}
                onClick={() => setTab(t)}
                data-testid={`color-tab-${t}`}
              >
                {t}
              </button>
            ))}
          </div>

          {tab === "hex" && (
            <p className="text-[10px] text-[#8A99B5]">Type a 6-digit hex above, e.g. #FF007F.</p>
          )}
          {tab === "rgb" && (
            <div className="flex gap-1">
              <Input
                value={rgbText}
                onChange={(e) => setRgbText(e.target.value)}
                placeholder={`rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`}
                className="h-7 flex-1 font-mono text-[11px]"
                data-testid="color-rgb-input"
              />
              <Button size="xs" variant="secondary" onClick={() => parseRgb(rgbText)}>
                Set
              </Button>
            </div>
          )}
          {tab === "hsl" && (
            <div className="flex gap-1">
              <Input
                value={hslText}
                onChange={(e) => setHslText(e.target.value)}
                placeholder="hsl(190, 100%, 50%)"
                className="h-7 flex-1 font-mono text-[11px]"
                data-testid="color-hsl-input"
              />
              <Button size="xs" variant="secondary" onClick={() => parseHsl(hslText)}>
                Set
              </Button>
            </div>
          )}

          <div>
            <p className="mb-1 text-[10px] uppercase tracking-wider text-[#5C6B84]">Recent</p>
            <div className="flex flex-wrap gap-1">
              {getRecentColors().map((c) => (
                <button key={c} className="size-5 rounded-sm border border-[#212A3D]" style={{ background: c }} onClick={() => commit(c)} data-testid={`recent-color-${c.slice(1)}`} aria-label={`Use ${c}`} />
              ))}
            </div>
          </div>

          <div>
            <p className="mb-1 flex items-center gap-1 text-[10px] uppercase tracking-wider text-[#5C6B84]">
              Favorites
              <button onClick={() => favStore.toggle(value)} data-testid="color-fav-toggle" aria-label="Toggle favorite color">
                {favStore.get().includes(value) ? <StarOff className="size-3" /> : <Star className="size-3" />}
              </button>
            </p>
            <div className="flex flex-wrap gap-1">
              {favStore.get().map((c) => (
                <button key={c} className="size-5 rounded-sm border border-[#FFB800]/50" style={{ background: c }} onClick={() => commit(c)} data-testid={`fav-color-${c.slice(1)}`} aria-label={`Use ${c}`} />
              ))}
            </div>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

export { favStore };
