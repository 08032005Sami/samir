// Central canvas workspace: rAF render loop, pan/zoom, draw tools, move/resize/rotate,
// marquee selection, vertex editing, cabinet patching, snapping with smart guides.

import { useEffect, useRef } from "react";
import type { Vec2 } from "@/lib/types";
import type { EditorState } from "@/lib/store";
import { store, useEditor } from "@/lib/store";
import {
  computeHandles,
  drawRulerH,
  drawRulerV,
  hitHandle,
  renderScene,
  screenToWorld,
  worldToScreen,
} from "@/lib/engine";
import { ptInScreen, rotatePt } from "@/lib/geometry";
import { buildCabinets, screenRes } from "@/lib/led";
import { clamp } from "@/lib/format";
import { createScreenTool, createShapeTool, patchScreen, patchShape, patchStage, pushHistory, select, selectAll, setTool, undo, zoomAt, fitAll } from "@/lib/store";

type Rect = { x: number; y: number; w: number; h: number };

type DragState =
  | { mode: "pan"; startScreen: Vec2; startView: { x: number; y: number } }
  | { mode: "marquee"; startScreen: Vec2 }
  | { mode: "move"; startWorld: Vec2; orig: Map<string, Vec2>; pushed: boolean }
  | { mode: "resize"; handle: string; startWorld: Vec2; bbox: Rect; orig: Map<string, Rect>; pushed: boolean }
  | { mode: "rotate"; center: Vec2; startAngle: number; orig: Map<string, number>; pushed: boolean }
  | { mode: "draw"; kind: "shape" | "screen"; startWorld: Vec2; cur: Vec2 }
  | { mode: "vertex"; shapeId: string; idx: number };

const SHAPE_TOOLS = new Set(["rect", "rrect", "circle", "triangle", "diamond", "hexagon", "star", "pen", "freehand", "line"]);

export default function CanvasViewport() {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rulerTopRef = useRef<HTMLCanvasElement | null>(null);
  const rulerLeftRef = useRef<HTMLCanvasElement | null>(null);
  const dirtyRef = useRef(true);
  const dragRef = useRef<DragState | null>(null);
  const spaceRef = useRef(false);
  const pannedRef = useRef(false);

  const tool = useEditor((s) => s.tool);
  const showRulers = useEditor((s) => s.showRulers);
  const customPatch = useEditor((s) => s.customPatch);

  // subscribe to everything → mark dirty
  useEffect(() => store.subscribe(() => (dirtyRef.current = true)), []);

  // first layout: fit
  useEffect(() => {
    const t = setTimeout(() => fitAll(), 60);
    return () => clearTimeout(t);
  }, []);

  // render loop
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let fpsFrames = 0;
    let fpsT = 0;
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const st = store.get();
      if (st.playing) {
        const dur = Math.max(0.5, st.doc.exportSettings.duration);
        let t = st.time + dt * st.speed;
        if (st.loop) t = t % dur;
        else if (t >= dur) {
          t = dur;
          store.set({ playing: false });
        }
        store.set({ time: t });
        dirtyRef.current = true;
      }
      fpsFrames++;
      fpsT += dt;
      if (fpsT >= 0.5) {
        store.set({ fpsMeter: Math.round(fpsFrames / fpsT) });
        fpsFrames = 0;
        fpsT = 0;
      }
      if (dirtyRef.current) {
        dirtyRef.current = false;
        render();
      }
    };
    const render = () => {
      const canvas = canvasRef.current;
      const wrap = wrapRef.current;
      if (!canvas || !wrap) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const vw = wrap.clientWidth;
      const vh = wrap.clientHeight;
      if (canvas.width !== Math.round(vw * dpr) || canvas.height !== Math.round(vh * dpr)) {
        canvas.width = Math.round(vw * dpr);
        canvas.height = Math.round(vh * dpr);
        canvas.style.width = `${vw}px`;
        canvas.style.height = `${vh}px`;
      }
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const st = store.get();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const drag = dragRef.current;
      renderScene(ctx, vw, vh, st, {
        drawOverlay: (c) => {
          if (drag?.mode === "draw") {
            const a = worldToScreen(st.view, drag.startWorld);
            const b = worldToScreen(st.view, drag.cur);
            const x = Math.min(a.x, b.x);
            const y = Math.min(a.y, b.y);
            const w = Math.abs(b.x - a.x);
            const h = Math.abs(b.y - a.y);
            c.strokeStyle = "#00F0FF";
            c.setLineDash([5, 4]);
            c.strokeRect(x, y, w, h);
            c.setLineDash([]);
            c.fillStyle = "rgba(0,240,255,0.9)";
            c.font = '11px "JetBrains Mono Variable", monospace';
            const wx = Math.abs(drag.cur.x - drag.startWorld.x);
            const wy = Math.abs(drag.cur.y - drag.startWorld.y);
            c.fillText(`${wx.toFixed(0)} × ${wy.toFixed(0)} px`, x, y - 6);
          }
        },
      });
      // rulers
      const rt = rulerTopRef.current;
      const rl = rulerLeftRef.current;
      if (rt) {
        if (rt.width !== Math.round(vw * dpr)) {
          rt.width = Math.round(vw * dpr);
          rt.height = Math.round(22 * dpr);
          rt.style.width = `${vw}px`;
        }
        const rc = rt.getContext("2d");
        if (rc) {
          rc.setTransform(dpr, 0, 0, dpr, 0, 0);
          drawRulerH(rc, vw, 22, st);
        }
      }
      if (rl) {
        if (rl.height !== Math.round(vh * dpr)) {
          rl.width = Math.round(22 * dpr);
          rl.height = Math.round(vh * dpr);
          rl.style.height = `${vh}px`;
        }
        const rc = rl.getContext("2d");
        if (rc) {
          rc.setTransform(dpr, 0, 0, dpr, 0, 0);
          drawRulerV(rc, 22, vh, st);
        }
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  // non-passive wheel zoom
  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = wrap.getBoundingClientRect();
      zoomAt(e.clientX - rect.left, e.clientY - rect.top, Math.exp(-e.deltaY * 0.0012));
    };
    wrap.addEventListener("wheel", onWheel, { passive: false });
    return () => wrap.removeEventListener("wheel", onWheel);
  }, []);

  // space hold = pan; tap = play/pause (handled here, not in global shortcuts)
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
      if (e.code === "Space" && !e.repeat) {
        spaceRef.current = true;
        pannedRef.current = false;
      }
    };
    const up = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        if (spaceRef.current && !pannedRef.current) {
          store.set((s) => ({ playing: !s.playing }));
        }
        spaceRef.current = false;
      }
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  // ------------------------------------------------------------ helpers

  const itemRect = (id: string): Rect | null => {
    const st = store.get();
    const sc = st.doc.screens.find((x) => x.id === id);
    if (sc) {
      const r = screenRes(sc);
      return { x: sc.x, y: sc.y, w: r.w, h: r.h };
    }
    const sh = st.doc.shapes.find((x) => x.id === id);
    if (sh) return { x: sh.x, y: sh.y, w: sh.w, h: sh.h };
    const so = st.doc.stage.find((x) => x.id === id);
    if (so) return { x: so.x, y: so.y, w: so.w, h: so.h };
    return null;
  };

  const hitTest = (world: Vec2): { type: "screen" | "shape" | "stage"; id: string } | null => {
    const st = store.get();
    for (let i = st.doc.shapes.length - 1; i >= 0; i--) {
      const sh = st.doc.shapes[i];
      if (!sh.visible || sh.locked) continue;
      // cheap bbox pre-test then precise stroke test
      const pad = sh.strokeWidth + 12;
      if (world.x >= sh.x - pad && world.x <= sh.x + sh.w + pad && world.y >= sh.y - pad && world.y <= sh.y + sh.h + pad) {
        return { type: "shape", id: sh.id };
      }
    }
    for (let i = st.doc.screens.length - 1; i >= 0; i--) {
      const sc = st.doc.screens[i];
      if (!sc.visible || sc.locked) continue;
      if (ptInScreen(sc, world)) return { type: "screen", id: sc.id };
    }
    if (st.doc.stageMode) {
      for (let i = st.doc.stage.length - 1; i >= 0; i--) {
        const so = st.doc.stage[i];
        if (!so.visible || so.locked) continue;
        if (world.x >= so.x && world.x <= so.x + so.w && world.y >= so.y && world.y <= so.y + so.h) {
          return { type: "stage", id: so.id };
        }
      }
    }
    return null;
  };

  const snapMove = (bbox: Rect, exclude: Set<string>): { dx: number; dy: number; guides: { v: number[]; h: number[] } } => {
    const st = store.get();
    const tol = 8 / st.view.zoom;
    let bestX: { delta: number; line: number } | null = null;
    let bestY: { delta: number; line: number } | null = null;
    const tryLine = (val: number, target: number, axis: "x" | "y") => {
      const delta = target - val;
      const cur = axis === "x" ? bestX : bestY;
      if (Math.abs(delta) <= tol && (!cur || Math.abs(delta) < Math.abs(cur.delta))) {
        if (axis === "x") bestX = { delta, line: target };
        else bestY = { delta, line: target };
      }
    };
    if (st.snapGrid) {
      const g = st.gridSize;
      for (const edge of [bbox.x, bbox.x + bbox.w / 2, bbox.x + bbox.w]) {
        const snapped = Math.round(edge / g) * g;
        tryLine(edge, snapped, "x");
      }
      for (const edge of [bbox.y, bbox.y + bbox.h / 2, bbox.y + bbox.h]) {
        const snapped = Math.round(edge / g) * g;
        tryLine(edge, snapped, "y");
      }
    }
    if (st.snapScreens) {
      const lines = { v: [0, st.doc.canvas.width / 2, st.doc.canvas.width], h: [0, st.doc.canvas.height / 2, st.doc.canvas.height] };
      for (const sc of st.doc.screens) {
        if (exclude.has(sc.id)) continue;
        const r = screenRes(sc);
        lines.v.push(sc.x, sc.x + r.w / 2, sc.x + r.w);
        lines.h.push(sc.y, sc.y + r.h / 2, sc.y + r.h);
      }
      for (const v of lines.v) {
        for (const edge of [bbox.x, bbox.x + bbox.w / 2, bbox.x + bbox.w]) tryLine(edge, v, "x");
      }
      for (const h of lines.h) {
        for (const edge of [bbox.y, bbox.y + bbox.h / 2, bbox.y + bbox.h]) tryLine(edge, h, "y");
      }
    }
    const gx = bestX ? (bestX as { delta: number; line: number }).line : null;
    const gy = bestY ? (bestY as { delta: number; line: number }).line : null;
    return {
      dx: bestX ? (bestX as { delta: number; line: number }).delta : 0,
      dy: bestY ? (bestY as { delta: number; line: number }).delta : 0,
      guides: { v: gx !== null ? [gx] : [], h: gy !== null ? [gy] : [] },
    };
  };

  // ------------------------------------------------------------ pointer events

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const screen = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    const st = store.get();
    const world = screenToWorld(st.view, screen);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);

    // custom cabinet patching mode
    if (st.customPatch) {
      const sc = st.doc.screens.find((x) => x.id === st.customPatch);
      if (sc && ptInScreen(sc, world)) {
        const res = screenRes(sc);
        const lx = rotatePt(world, { x: sc.x + res.w / 2, y: sc.y + res.h / 2 }, -sc.rotation);
        const cabW = res.w / sc.cabsX;
        const cabH = res.h / sc.cabsY;
        const col = clamp(Math.floor((lx.x - sc.x) / cabW), 0, sc.cabsX - 1);
        const row = clamp(Math.floor((lx.y - sc.y) / cabH), 0, sc.cabsY - 1);
        const cells: number[] = [];
        for (let r = 0; r < sc.cabsY; r++) for (let c = 0; c < sc.cabsX; c++) cells.push(r * sc.cabsX + c);
        const idx = cells[row * sc.cabsX + col];
        const order = sc.customOrder ? [...sc.customOrder] : [];
        const at = order.indexOf(idx);
        if (at >= 0) order.splice(at, 1);
        order.push(idx);
        if (order.length === sc.cabsX * sc.cabsY) {
          patchScreen(sc.id, { customOrder: order, order: "custom" });
          store.set({ customPatch: null });
        } else {
          patchScreen(sc.id, { customOrder: order, order: "custom" }, false);
        }
      }
      return;
    }

    // pan: middle button, hand tool, or space+drag
    if (e.button === 1 || st.tool === "hand" || spaceRef.current) {
      pannedRef.current = true;
      dragRef.current = { mode: "pan", startScreen: screen, startView: { x: st.view.x, y: st.view.y } };
      return;
    }

    // draw tools
    if (SHAPE_TOOLS.has(st.tool) || st.tool === "screen") {
      dragRef.current = { mode: "draw", kind: st.tool === "screen" ? "screen" : "shape", startWorld: world, cur: world };
      return;
    }

    if (st.tool !== "select") return;

    // handles?
    const handles = computeHandles(st);
    const h = hitHandle(handles, screen);
    if (h && st.selection.length) {
      if (h === "rot") {
        const single = st.selection.length === 1 ? st.selection[0] : null;
        const r = single ? itemRect(single) : null;
        if (single && r) {
          const center = { x: r.x + r.w / 2, y: r.y + r.h / 2 };
          const orig = new Map<string, number>();
          for (const id of st.selection) {
            const sc = st.doc.screens.find((x) => x.id === id);
            if (sc) orig.set(id, sc.rotation);
            const sh = st.doc.shapes.find((x) => x.id === id);
            if (sh) orig.set(id, sh.rotation);
            const so = st.doc.stage.find((x) => x.id === id);
            if (so) orig.set(id, so.rotation);
          }
          dragRef.current = { mode: "rotate", center, startAngle: (Math.atan2(world.y - center.y, world.x - center.x) * 180) / Math.PI, orig, pushed: false };
          return;
        }
      } else {
        const bbox = handles ? selectionBBox(st) : null;
        if (bbox) {
          const orig = new Map<string, Rect>();
          for (const id of st.selection) {
            const r = itemRect(id);
            if (r) orig.set(id, r);
          }
          dragRef.current = { mode: "resize", handle: h, startWorld: world, bbox, orig, pushed: false };
          return;
        }
      }
    }

    // vertex editing
    if (st.editPoints && st.selection.length === 1) {
      const sh = st.doc.shapes.find((x) => x.id === st.selection[0]);
      if (sh?.points) {
        for (let i = 0; i < sh.points.length; i++) {
          const p = worldToScreen(st.view, sh.points[i]);
          if (Math.hypot(p.x - screen.x, p.y - screen.y) < 8) {
            dragRef.current = { mode: "vertex", shapeId: sh.id, idx: i };
            return;
          }
        }
      }
    }

    // item hit
    const hit = hitTest(world);
    if (hit) {
      if (e.shiftKey || e.ctrlKey || e.metaKey) {
        select([hit.id], "toggle");
      } else if (!st.selection.includes(hit.id)) {
        select([hit.id]);
      }
      const movable = !st.doc.screens.find((x) => x.id === hit.id)?.locked && !st.doc.shapes.find((x) => x.id === hit.id)?.locked;
      if (movable) {
        const orig = new Map<string, Vec2>();
        for (const id of store.get().selection) {
          const r = itemRect(id);
          if (r) orig.set(id, { x: r.x, y: r.y });
        }
        dragRef.current = { mode: "move", startWorld: world, orig, pushed: false };
      }
    } else {
      if (!e.shiftKey) select([]);
      dragRef.current = { mode: "marquee", startScreen: screen };
      store.set({ marquee: { x0: screen.x, y0: screen.y, x1: screen.x, y1: screen.y } });
    }
  };

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const screen = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    const st = store.get();
    const world = screenToWorld(st.view, screen);
    store.set({ cursor: { x: world.x, y: world.y }, cursorInfo: computeCursorInfo(world) });

    const drag = dragRef.current;
    if (!drag) return;
    switch (drag.mode) {
      case "pan": {
        store.set({ view: { ...st.view, x: drag.startView.x + (screen.x - drag.startScreen.x), y: drag.startView.y + (screen.y - drag.startScreen.y) } });
        break;
      }
      case "marquee": {
        store.set({ marquee: { x0: drag.startScreen.x, y0: drag.startScreen.y, x1: screen.x, y1: screen.y } });
        break;
      }
      case "move": {
        if (!drag.pushed) {
          pushHistory();
          drag.pushed = true;
        }
        let dx = world.x - drag.startWorld.x;
        let dy = world.y - drag.startWorld.y;
        if (e.shiftKey) {
          if (Math.abs(dx) > Math.abs(dy)) dy = 0;
          else dx = 0;
        }
        // snap based on combined bbox
        let bx0 = Infinity;
        let by0 = Infinity;
        let bx1 = -Infinity;
        let by1 = -Infinity;
        for (const [, o] of drag.orig) {
          bx0 = Math.min(bx0, o.x);
          by0 = Math.min(by0, o.y);
          bx1 = Math.max(bx1, o.x + 1);
          by1 = Math.max(by1, o.y + 1);
        }
        // use actual sizes
        const items: Rect[] = [];
        for (const [id, o] of drag.orig) {
          const r = itemRect(id);
          if (r) items.push({ ...o, w: r.w, h: r.h });
        }
        bx0 = Math.min(...items.map((r) => r.x));
        by0 = Math.min(...items.map((r) => r.y));
        bx1 = Math.max(...items.map((r) => r.x + r.w));
        by1 = Math.max(...items.map((r) => r.y + r.h));
        const bboxNow = { x: bx0 + dx, y: by0 + dy, w: bx1 - bx0, h: by1 - by0 };
        const exclude = new Set(drag.orig.keys());
        const snap = st.snapGrid || st.snapScreens ? snapMove(bboxNow, exclude) : { dx: 0, dy: 0, guides: { v: [], h: [] } };
        dx += snap.dx;
        dy += snap.dy;
        store.set({ snapGuides: snap.guides.v.length || snap.guides.h.length ? snap.guides : null });
        applyMove(dx, dy, drag.orig);
        break;
      }
      case "resize": {
        if (!drag.pushed) {
          pushHistory();
          drag.pushed = true;
        }
        applyResize(drag, world, e.shiftKey);
        break;
      }
      case "rotate": {
        if (!drag.pushed) {
          pushHistory();
          drag.pushed = true;
        }
        const ang = (Math.atan2(world.y - drag.center.y, world.x - drag.center.x) * 180) / Math.PI;
        let delta = ang - drag.startAngle;
        if (e.shiftKey) delta = Math.round(delta / 15) * 15;
        store.set((s) => ({
          doc: {
            ...s.doc,
            screens: s.doc.screens.map((x) => (drag.orig.has(x.id) ? { ...x, rotation: Math.round(((drag.orig.get(x.id) ?? 0) + delta) * 10) / 10 } : x)),
            shapes: s.doc.shapes.map((x) => (drag.orig.has(x.id) ? { ...x, rotation: Math.round(((drag.orig.get(x.id) ?? 0) + delta) * 10) / 10 } : x)),
            stage: s.doc.stage.map((x) => (drag.orig.has(x.id) ? { ...x, rotation: Math.round(((drag.orig.get(x.id) ?? 0) + delta) * 10) / 10 } : x)),
          },
          dirty: true,
        }));
        break;
      }
      case "draw": {
        drag.cur = world;
        break;
      }
      case "vertex": {
        const sh = store.get().doc.shapes.find((x) => x.id === drag.shapeId);
        if (sh?.points) {
          const pts = sh.points.map((p, i) => (i === drag.idx ? { x: Math.round(world.x), y: Math.round(world.y) } : p));
          const xs = pts.map((p) => p.x);
          const ys = pts.map((p) => p.y);
          patchShape(
            sh.id,
            { points: pts, x: Math.min(...xs), y: Math.min(...ys), w: Math.max(1, Math.max(...xs) - Math.min(...xs)), h: Math.max(1, Math.max(...ys) - Math.min(...ys)) },
            false,
          );
        }
        break;
      }
    }
  };

  const onPointerUp = () => {
    const st = store.get();
    const drag = dragRef.current;
    if (drag?.mode === "marquee" && st.marquee) {
      const m = st.marquee;
      const x0 = Math.min(m.x0, m.x1);
      const y0 = Math.min(m.y0, m.y1);
      const x1 = Math.max(m.x0, m.x1);
      const y1 = Math.max(m.y0, m.y1);
      if (x1 - x0 > 4 && y1 - y0 > 4) {
        const w0 = screenToWorld(st.view, { x: x0, y: y0 });
        const w1 = screenToWorld(st.view, { x: x1, y: y1 });
        const ids: string[] = [];
        for (const sc of st.doc.screens) {
          if (!sc.visible) continue;
          const r = screenRes(sc);
          if (sc.x < w1.x && sc.x + r.w > w0.x && sc.y < w1.y && sc.y + r.h > w0.y) ids.push(sc.id);
        }
        for (const sh of st.doc.shapes) {
          if (!sh.visible) continue;
          if (sh.x < w1.x && sh.x + sh.w > w0.x && sh.y < w1.y && sh.y + sh.h > w0.y) ids.push(sh.id);
        }
        if (st.doc.stageMode) {
          for (const so of st.doc.stage) {
            if (!so.visible) continue;
            if (so.x < w1.x && so.x + so.w > w0.x && so.y < w1.y && so.y + so.h > w0.y) ids.push(so.id);
          }
        }
        select(ids, e_shift() ? "add" : "replace");
      }
      store.set({ marquee: null });
    }
    if (drag?.mode === "draw") {
      const a = drag.startWorld;
      const b = drag.cur;
      let x = Math.min(a.x, b.x);
      let y = Math.min(a.y, b.y);
      let w = Math.abs(b.x - a.x);
      let h = Math.abs(b.y - a.y);
      if (w < 6 || h < 6) {
        w = Math.max(60, w);
        h = Math.max(60, h);
      }
      if (drag.kind === "screen") {
        const sc = createScreenTool(Math.round(x), Math.round(y), w, h, st.lastCalcCab);
        store.set((s0) => ({ doc: { ...s0.doc, screens: [...s0.doc.screens, { ...sc, z: s0.doc.screens.length }] }, selection: [sc.id], dirty: true, activeInspector: "inspect" }));
      } else {
        const shape = createShapeTool(st.tool === "select" ? "rect" : (st.tool as never), Math.round(x), Math.round(y), Math.round(w), Math.round(h));
        store.set((s0) => ({ doc: { ...s0.doc, shapes: [...s0.doc.shapes, { ...shape, z: s0.doc.shapes.length }] }, selection: [shape.id], dirty: true, activeInspector: "fx" }));
      }
    }
    if (drag?.mode === "move") {
      store.set({ snapGuides: null });
    }
    dragRef.current = null;
  };

  const e_shift = () => false;

  const onDoubleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const world = screenToWorld(store.get().view, { x: e.clientX - rect.left, y: e.clientY - rect.top });
    const hit = hitTest(world);
    if (hit?.type === "shape") {
      const sh = store.get().doc.shapes.find((x) => x.id === hit.id);
      if (sh && sh.points) {
        select([sh.id]);
        store.set({ editPoints: true, activeInspector: "inspect" });
        return;
      }
    }
    if (hit?.type === "screen") {
      select([hit.id]);
      store.set({ cabinetOpen: true, activeInspector: "inspect" });
    }
  };

  // ------------------------------------------------------------ apply helpers

  function applyMove(dx: number, dy: number, orig: Map<string, Vec2>): void {
    const apply = <T extends { id: string; x: number; y: number }>(arr: T[]): T[] =>
      arr.map((x) => {
        const o = orig.get(x.id);
        return o ? { ...x, x: Math.round(o.x + dx), y: Math.round(o.y + dy) } : x;
      });
    store.set((s) => ({
      doc: { ...s.doc, screens: apply(s.doc.screens) as typeof s.doc.screens, shapes: apply(s.doc.shapes) as typeof s.doc.shapes, stage: apply(s.doc.stage) as typeof s.doc.stage },
      dirty: true,
    }));
  }

  function applyResize(drag: { handle: string; bbox: Rect; orig: Map<string, Rect> }, world: Vec2, shift: boolean): void {
    const st = store.get();
    let { x: bx, y: by, w: bw, h: bh } = drag.bbox;
    let nx = bx;
    let ny = by;
    let nw = bw;
    let nh = bh;
    const hnd = drag.handle;
    if (hnd.includes("e")) nw = Math.max(8, world.x - bx);
    if (hnd.includes("s")) nh = Math.max(8, world.y - by);
    if (hnd.includes("w")) {
      nw = Math.max(8, bx + bw - world.x);
      nx = bx + bw - nw;
    }
    if (hnd.includes("n")) {
      nh = Math.max(8, by + bh - world.y);
      ny = by + bh - nh;
    }
    if (shift) {
      const ar = bw / bh;
      if (nw / nh > ar) nw = nh * ar;
      else nh = nw / ar;
      if (hnd.includes("w")) nx = bx + bw - nw;
      if (hnd.includes("n")) ny = by + bh - nh;
    }
    const sx = nw / bw;
    const sy = nh / bh;
    const apply = <T extends { id: string; x: number; y: number; w: number; h: number }>(arr: T[]): T[] =>
      arr.map((x) => {
        const o = drag.orig.get(x.id);
        if (!o) return x;
        const rx = (o.x - bx) * sx + nx;
        const ry = (o.y - by) * sy + ny;
        return { ...x, x: Math.round(rx), y: Math.round(ry), w: Math.max(1, Math.round(o.w * sx)), h: Math.max(1, Math.round(o.h * sy)) };
      });
    // screens: w/h derive from cabinets — adjust cabinet counts instead
    const screens = st.doc.screens.map((x) => {
      const o = drag.orig.get(x.id);
      if (!o) return x;
      const r = screenRes(x);
      const rx = (o.x - bx) * sx + nx;
      const ry = (o.y - by) * sy + ny;
      void r;
      return { ...x, x: Math.round(rx), y: Math.round(ry) };
    });
    // shapes scale w/h; stage scales too; screens only move (cabinet-locked sizes)
    store.set({
      doc: {
        ...st.doc,
        screens,
        shapes: apply(st.doc.shapes) as typeof st.doc.shapes,
        stage: apply(st.doc.stage) as typeof st.doc.stage,
      },
      dirty: true,
    });
  }

  function selectionBBox(st: EditorState): Rect | null {
    const handles = computeHandles(st);
    if (!handles) return null;
    const xs = Object.values(handles.pts).map((p) => p.x);
    const ys = Object.values(handles.pts).map((p) => p.y);
    const s0 = screenToWorld(st.view, { x: Math.min(...xs), y: Math.min(...ys) });
    const s1 = screenToWorld(st.view, { x: Math.max(...xs), y: Math.max(...ys) });
    return { x: s0.x, y: s0.y, w: s1.x - s0.x, h: s1.y - s0.y };
  }

  function computeCursorInfo(world: Vec2): EditorState["cursorInfo"] {
    const st = store.get();
    let topScreen: (typeof st.doc.screens)[number] | null = null;
    for (let i = st.doc.screens.length - 1; i >= 0; i--) {
      if (ptInScreen(st.doc.screens[i], world)) {
        topScreen = st.doc.screens[i];
        break;
      }
    }
    if (!topScreen) return { gx: Math.round(world.x), gy: Math.round(world.y), screenName: null, screenId: null, cabinet: null, lx: Math.round(world.x), ly: Math.round(world.y) };
    const res = screenRes(topScreen);
    const local = rotatePt(world, { x: topScreen.x + res.w / 2, y: topScreen.y + res.h / 2 }, -topScreen.rotation);
    const cabW = res.w / topScreen.cabsX;
    const cabH = res.h / topScreen.cabsY;
    const col = clamp(Math.floor((local.x - topScreen.x) / cabW), 0, topScreen.cabsX - 1);
    const row = clamp(Math.floor((local.y - topScreen.y) / cabH), 0, topScreen.cabsY - 1);
    let cabNumber: number | null = null;
    if (topScreen.cabsX * topScreen.cabsY <= 400) {
      const cab = buildCabinets(topScreen).find((c) => c.col === col && c.row === row);
      cabNumber = cab?.number ?? null;
    }
    return {
      gx: Math.round(world.x),
      gy: Math.round(world.y),
      screenName: topScreen.name,
      screenId: topScreen.id,
      cabinet: cabNumber,
      lx: Math.round(local.x - topScreen.x),
      ly: Math.round(local.y - topScreen.y),
    };
  }

  // cursor style
  const cursorStyle = (() => {
    if (spaceRef.current) return "grabbing";
    if (tool === "hand") return "grab";
    if (tool === "select") return "default";
    return "crosshair";
  })();

  return (
    <div className="relative flex flex-1 overflow-hidden" data-testid="canvas-viewport">
      {showRulers && <canvas ref={rulerLeftRef} style={{ width: 22, height: "100%" }} className="z-10 shrink-0" />}
      <div className="relative flex-1">
        {showRulers && <canvas ref={rulerTopRef} style={{ width: "100%", height: 22 }} className="absolute inset-x-0 top-0 z-10" />}
        <div id="canvas-surface" ref={wrapRef} className="absolute inset-0 top-0" style={{ top: showRulers ? 22 : 0 }}>
          <canvas
            ref={canvasRef}
            className="block h-full w-full touch-none select-none"
            style={{ cursor: cursorStyle }}
            data-testid="canvas-main"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={() => store.set({ cursor: null, cursorInfo: null })}
            onDoubleClick={onDoubleClick}
            onContextMenu={(e) => e.preventDefault()}
          />
        </div>
        {customPatch && (
          <div className="pointer-events-none absolute left-1/2 top-14 z-20 -translate-x-1/2 rounded border border-[#00FFA3] bg-[#06261A] px-3 py-1.5 text-xs font-mono text-[#00FFA3]">
            CUSTOM PATCH MODE — click cabinets in chain order · {customPatch ? "active" : ""} · Esc to exit
          </div>
        )}
        {tool === "screen" && !customPatch && (
          <div className="pointer-events-none absolute left-1/2 top-14 z-20 -translate-x-1/2 rounded border border-[#212A3D] bg-[#121722] px-3 py-1.5 text-xs font-mono text-[#8A99B5]">
            DRAG to place an LED wall — size snaps to whole cabinets
          </div>
        )}
      </div>
    </div>
  );
}

// re-exports used elsewhere
export { setTool, undo, selectAll, patchScreen, patchShape, patchStage };
