// Templates & presets: stage templates, quick grid layouts, auto layout,
// symmetry, user templates.

import { useState } from "react";
import { toast } from "sonner";
import { GRID_TEMPLATES, STAGE_TEMPLATES, applyGridTemplate, getUserTemplates, saveUserTemplate, deleteUserTemplate, validateDoc } from "@/lib/project";
import { loadDoc, setDoc, store, useEditor, smartCenter } from "@/lib/store";
import { screenRes } from "@/lib/led";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2 } from "lucide-react";

export default function TemplatesTab() {
  const doc = useEditor((s) => s.doc);
  const [tplName, setTplName] = useState("");
  const [userTpls, setUserTpls] = useState(getUserTemplates());
  const [spacing, setSpacing] = useState(32);

  const autoLayout = (mode: "horizontal" | "vertical" | "grid" | "stage") => {
    const screens = [...doc.screens];
    if (!screens.length) {
      toast.error("No screens to arrange");
      return;
    }
    let x = 0;
    let y = 0;
    let rowH = 0;
    const cols = Math.ceil(Math.sqrt(screens.length));
    const laid = screens.map((s, i) => {
      const r = screenRes(s);
      let nx = 0;
      let ny = 0;
      if (mode === "horizontal") {
        nx = x;
        ny = 0;
        x += r.w + spacing;
      } else if (mode === "vertical") {
        nx = 0;
        ny = y;
        y += r.h + spacing;
      } else if (mode === "grid") {
        if (i > 0 && i % cols === 0) {
          x = 0;
          y += rowH + spacing;
          rowH = 0;
        }
        nx = x;
        ny = y;
        x += r.w + spacing;
        rowH = Math.max(rowH, r.h);
      } else {
        // stage: biggest center, rest alternate left/right wings
        return s;
      }
      return { ...s, x: nx, y: ny, rotation: 0 };
    });
    let out = laid;
    if (mode === "stage") {
      const sorted = [...screens].sort((a, b) => screenRes(b).w * screenRes(b).h - screenRes(a).w * screenRes(a).h);
      const main = sorted[0];
      const mr = screenRes(main);
      const cx = doc.canvas.width / 2;
      let left = cx - mr.w / 2 - spacing;
      let right = cx + mr.w / 2 + spacing;
      out = screens.map((s) => {
        const r = screenRes(s);
        if (s.id === main.id) return { ...s, x: Math.round(cx - r.w / 2), y: 0, rotation: 0 };
        const idx = sorted.indexOf(s);
        if (idx % 2 === 1) {
          const nx = left - r.w;
          left = nx - spacing;
          return { ...s, x: Math.round(nx), y: 0, rotation: 0 };
        }
        const nx = right;
        right = nx + r.w + spacing;
        return { ...s, x: Math.round(nx), y: 0, rotation: 0 };
      });
    }
    setDoc({ ...doc, screens: out });
    requestAnimationFrame(() => smartCenter());
    toast.success(`Auto layout: ${mode}`);
  };

  const mirror = (axis: "h" | "v" | "both") => {
    const W = doc.canvas.width;
    const H = doc.canvas.height;
    const sel = store.get().selection;
    const targets = doc.shapes.filter((s) => !sel.length || sel.includes(s.id));
    const mirrored = targets.flatMap((s) => {
      const outs = [];
      if (axis === "h" || axis === "both") outs.push({ ...s, id: crypto.randomUUID(), name: `${s.name} ⇋`, x: W - s.x - s.w, rotation: -s.rotation, points: s.points?.map((p) => ({ x: W - p.x, y: p.y })) ?? null });
      if (axis === "v" || axis === "both") outs.push({ ...s, id: crypto.randomUUID(), name: `${s.name} ⇵`, y: H - s.y - s.h, rotation: -s.rotation, points: s.points?.map((p) => ({ x: p.x, y: H - p.y })) ?? null });
      if (axis === "both") outs.push({ ...s, id: crypto.randomUUID(), name: `${s.name} ⤧`, x: W - s.x - s.w, y: H - s.y - s.h, rotation: s.rotation, points: s.points?.map((p) => ({ x: W - p.x, y: H - p.y })) ?? null });
      return outs;
    });
    if (!mirrored.length) {
      toast.error("No shapes to mirror");
      return;
    }
    setDoc({ ...doc, shapes: [...doc.shapes, ...mirrored] });
    toast.success(`Mirrored ${targets.length} shape(s)`);
  };

  return (
    <div className="space-y-3 p-3" data-testid="templates-tab">
      <h3 className="font-heading text-sm font-bold text-[#F0F4FC]">Templates & Presets</h3>

      <div>
        <p className="mb-1.5 text-[10px] uppercase tracking-wider text-[#8292AD]">Stage Templates</p>
        <div className="space-y-1">
          {STAGE_TEMPLATES.map((t) => (
            <button
              key={t.id}
              className="w-full rounded border border-[#212A3D] bg-[#121722] p-2 text-left hover:border-[#00F0FF]/50"
              onClick={() => {
                loadDoc(t.build());
                toast.success(`Loaded template: ${t.name}`);
              }}
              data-testid={`template-${t.id}`}
            >
              <div className="text-xs font-semibold text-[#EBF1FC]">{t.name}</div>
              <div className="text-[10px] text-[#8292AD]">{t.desc}</div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-1.5 text-[10px] uppercase tracking-wider text-[#8292AD]">Quick LED Layouts (replaces screens)</p>
        <div className="grid grid-cols-3 gap-1">
          {GRID_TEMPLATES.map((g) => (
            <button
              key={g.id}
              className="rounded border border-[#212A3D] px-1.5 py-1.5 text-[10px] text-[#8A99B5] hover:border-[#00F0FF]/50 hover:text-[#F0F4FC]"
              onClick={() => {
                const next = applyGridTemplate(structuredClone(doc), g);
                setDoc(next);
                requestAnimationFrame(() => store.get() && import("@/lib/store").then((m) => m.fitAll()));
                toast.success(`Layout: ${g.name}`);
              }}
              data-testid={`grid-template-${g.id}`}
            >
              {g.name}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded border border-[#212A3D] bg-[#121722] p-2.5">
        <p className="mb-1.5 text-[10px] uppercase tracking-wider text-[#8292AD]">Auto Layout</p>
        <div className="mb-1.5 flex items-center gap-2">
          <span className="text-[10px] text-[#8292AD]">Spacing</span>
          <Input type="number" value={spacing} onChange={(e) => setSpacing(Math.max(0, Number(e.target.value)))} className="h-7 w-20 border-[#212A3D] bg-[#0B0D13] font-mono text-xs" data-testid="auto-layout-spacing" />
          <span className="text-[10px] text-[#5C6B84]">px</span>
        </div>
        <div className="grid grid-cols-2 gap-1">
          {(["horizontal", "vertical", "grid", "stage"] as const).map((m) => (
            <Button key={m} size="xs" variant="outline" onClick={() => autoLayout(m)} data-testid={`auto-layout-${m}`}>
              {m}
            </Button>
          ))}
          <Button size="xs" variant="secondary" className="col-span-2" onClick={() => smartCenter()} data-testid="auto-layout-center">
            Smart Center in Canvas
          </Button>
        </div>
      </div>

      <div className="rounded border border-[#212A3D] bg-[#121722] p-2.5">
        <p className="mb-1.5 text-[10px] uppercase tracking-wider text-[#8292AD]">Symmetry (selected or all shapes)</p>
        <div className="grid grid-cols-3 gap-1">
          <Button size="xs" variant="outline" onClick={() => mirror("h")} data-testid="mirror-h">Horizontal</Button>
          <Button size="xs" variant="outline" onClick={() => mirror("v")} data-testid="mirror-v">Vertical</Button>
          <Button size="xs" variant="outline" onClick={() => mirror("both")} data-testid="mirror-both">Both</Button>
        </div>
      </div>

      <div className="rounded border border-[#212A3D] bg-[#121722] p-2.5">
        <p className="mb-1.5 text-[10px] uppercase tracking-wider text-[#8292AD]">My Templates</p>
        <div className="flex gap-1">
          <Input value={tplName} onChange={(e) => setTplName(e.target.value)} placeholder="Template name" className="h-7 border-[#212A3D] bg-[#0B0D13] text-xs" data-testid="user-template-name" />
          <Button
            size="xs"
            variant="secondary"
            onClick={() => {
              saveUserTemplate(tplName.trim() || doc.name, doc);
              setUserTpls(getUserTemplates());
              setTplName("");
              toast.success("Template saved");
            }}
            data-testid="user-template-save"
          >
            Save current
          </Button>
        </div>
        <div className="mt-1.5 space-y-1">
          {userTpls.map((t) => (
            <div key={t.id} className="flex items-center gap-1">
              <button className="flex-1 truncate rounded bg-[#1D2536] px-2 py-1 text-left text-[10px] text-[#EBF1FC] hover:text-[#00F0FF]" onClick={() => (loadDoc({ ...validateDoc(t.doc), id: crypto.randomUUID() }), toast.success(`Loaded ${t.name}`))} data-testid={`user-template-${t.id}`}>
                {t.name}
              </button>
              <button onClick={() => (deleteUserTemplate(t.id), setUserTpls(getUserTemplates()))} aria-label="Delete template" data-testid={`user-template-delete-${t.id}`}>
                <Trash2 className="size-3 text-[#5C6B84] hover:text-[#FF5C7A]" />
              </button>
            </div>
          ))}
          {!userTpls.length && <p className="text-[10px] text-[#5C6B84]">Saved templates live in this browser.</p>}
        </div>
      </div>
    </div>
  );
}
