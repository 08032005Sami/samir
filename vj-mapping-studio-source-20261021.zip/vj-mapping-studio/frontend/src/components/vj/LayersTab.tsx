// Layers / hierarchy panel: screens, shapes, stage objects with select, rename,
// lock, visibility, reorder.

import { useState } from "react";
import { select, store, toggleLock, toggleVisible, useEditor, reorderSelection, addStageObject } from "@/lib/store";
import type { StageKind } from "@/lib/types";
import { screenRes } from "@/lib/led";
import { Eye, EyeOff, Lock, LockOpen, Monitor, Spline, Box, ChevronUp, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

const STAGE_KINDS: { kind: StageKind; label: string }[] = [
  { kind: "main-led", label: "Main LED" },
  { kind: "side-led", label: "Side LED" },
  { kind: "floor-led", label: "Floor LED" },
  { kind: "ceiling-led", label: "Ceiling LED" },
  { kind: "dj-booth", label: "DJ Booth" },
  { kind: "speaker", label: "Speaker" },
  { kind: "truss", label: "Truss" },
  { kind: "moving-head", label: "Moving Head" },
  { kind: "projector", label: "Projector" },
  { kind: "custom", label: "Custom" },
];

function LayerRow({ id, name, sub, icon: Icon, color, locked, visible, selected, testPrefix, onRename }: { id: string; name: string; sub: string; icon: typeof Monitor; color: string; locked: boolean; visible: boolean; selected: boolean; testPrefix: string; onRename: (n: string) => void }) {
  const [editing, setEditing] = useState(false);
  return (
    <div
      className={`group flex items-center gap-2 rounded px-2 py-1 ${selected ? "bg-[#00F0FF]/10 ring-1 ring-[#00F0FF]/40" : "hover:bg-[#1D2536]"}`}
      onClick={(e) => select([id], e.shiftKey || e.ctrlKey || e.metaKey ? "toggle" : "replace")}
      data-testid={`${testPrefix}-${id}`}
    >
      <Icon className="size-3.5 shrink-0" style={{ color }} />
      <div className="min-w-0 flex-1" onDoubleClick={() => setEditing(true)}>
        {editing ? (
          <input
            autoFocus
            defaultValue={name}
            onBlur={(e) => {
              onRename(e.target.value || name);
              setEditing(false);
            }}
            onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
            className="w-full rounded border border-[#00F0FF] bg-[#0B0D13] px-1 text-xs text-[#F0F4FC]"
            data-testid={`${testPrefix}-rename-input`}
          />
        ) : (
          <div className={`truncate text-xs ${visible ? "text-[#EBF1FC]" : "text-[#5C6B84] line-through"}`}>{name}</div>
        )}
        <div className="truncate font-mono text-[9px] text-[#5C6B84]">{sub}</div>
      </div>
      <button onClick={(e) => (e.stopPropagation(), toggleVisible(id))} aria-label="Toggle visibility" data-testid={`${testPrefix}-visible-${id}`}>
        {visible ? <Eye className="size-3.5 text-[#8A99B5]" /> : <EyeOff className="size-3.5 text-[#5C6B84]" />}
      </button>
      <button onClick={(e) => (e.stopPropagation(), toggleLock(id))} aria-label="Toggle lock" data-testid={`${testPrefix}-lock-${id}`}>
        {locked ? <Lock className="size-3.5 text-[#FFB800]" /> : <LockOpen className="size-3.5 text-[#5C6B84]" />}
      </button>
    </div>
  );
}

export default function LayersTab() {
  const doc = useEditor((s) => s.doc);
  const selection = useEditor((s) => s.selection);

  const rename = (kind: "screens" | "shapes" | "stage", id: string, name: string) => {
    store.set((s) => ({
      past: [...s.past.slice(-79), JSON.stringify(s.doc)],
      future: [],
      doc: {
        ...s.doc,
        [kind]: (s.doc[kind] as { id: string }[]).map((x) => (x.id === id ? (kind === "stage" ? { ...x, label: name } : { ...x, name }) : x)),
      },
      dirty: true,
    }));
  };

  return (
    <div className="space-y-3 p-3" data-testid="layers-tab">
      <div className="flex items-center justify-between">
        <h3 className="font-heading text-sm font-bold text-[#F0F4FC]">Hierarchy</h3>
        <div className="flex gap-1">
          <Button size="icon-xs" variant="outline" onClick={() => reorderSelection("up")} title="Bring forward" data-testid="layers-up-btn"><ChevronUp className="size-3" /></Button>
          <Button size="icon-xs" variant="outline" onClick={() => reorderSelection("down")} title="Send backward" data-testid="layers-down-btn"><ChevronDown className="size-3" /></Button>
        </div>
      </div>

      <div>
        <p className="mb-1 text-[10px] uppercase tracking-wider text-[#8292AD]">Border FX Shapes ({doc.shapes.length})</p>
        <div className="space-y-0.5">
          {[...doc.shapes].reverse().map((s) => (
            <LayerRow key={s.id} id={s.id} name={s.name} sub={`${s.kind} · ${s.fx.enabled ? s.fx.type : "static"}`} icon={Spline} color={s.fx.color} locked={s.locked} visible={s.visible} selected={selection.includes(s.id)} testPrefix="layer-shape" onRename={(n) => rename("shapes", s.id, n)} />
          ))}
          {!doc.shapes.length && <p className="px-2 text-[10px] text-[#5C6B84]">No shapes — use R / C / T tools.</p>}
        </div>
      </div>

      <div>
        <p className="mb-1 text-[10px] uppercase tracking-wider text-[#8292AD]">LED Screens ({doc.screens.length})</p>
        <div className="space-y-0.5">
          {[...doc.screens].reverse().map((s) => {
            const r = screenRes(s);
            return (
              <LayerRow key={s.id} id={s.id} name={s.name} sub={`${r.w}×${r.h} · ${s.cabsX}×${s.cabsY} cab · @${Math.round(s.x)},${Math.round(s.y)}${s.groupId ? " · grp" : ""}`} icon={Monitor} color={s.color} locked={s.locked} visible={s.visible} selected={selection.includes(s.id)} testPrefix="layer-screen" onRename={(n) => rename("screens", s.id, n)} />
            );
          })}
          {!doc.screens.length && <p className="px-2 text-[10px] text-[#5C6B84]">No screens — use the Wall Calculator or S tool.</p>}
        </div>
      </div>

      <div>
        <div className="mb-1 flex items-center justify-between">
          <p className="text-[10px] uppercase tracking-wider text-[#8292AD]">Stage Design Layer ({doc.stage.length})</p>
          <button
            className={`rounded px-1.5 py-0.5 text-[9px] ${doc.stageMode ? "bg-[#00F0FF]/20 text-[#00F0FF]" : "bg-[#1D2536] text-[#5C6B84]"}`}
            onClick={() => store.set((s) => ({ doc: { ...s.doc, stageMode: !s.doc.stageMode }, dirty: true }))}
            data-testid="stage-mode-toggle"
          >
            {doc.stageMode ? "VISIBLE" : "HIDDEN"}
          </button>
        </div>
        <div className="mb-2 grid grid-cols-2 gap-1">
          {STAGE_KINDS.map((k) => (
            <button
              key={k.kind}
              className="rounded border border-[#212A3D] px-1.5 py-1 text-left text-[10px] text-[#8A99B5] hover:border-[#00F0FF]/50 hover:text-[#F0F4FC]"
              onClick={() => {
                store.set((s) => ({ doc: { ...s.doc, stageMode: true } }));
                addStageObject(k.kind, Math.round(doc.canvas.width / 2 - 80), Math.round(doc.canvas.height + 80));
              }}
              data-testid={`stage-add-${k.kind}`}
            >
              + {k.label}
            </button>
          ))}
        </div>
        <p className="mb-1 text-[10px] text-[#5C6B84]">Planning-only layer: never exported to pixel maps or sequences.</p>
        <div className="space-y-0.5">
          {[...doc.stage].reverse().map((o) => (
            <LayerRow key={o.id} id={o.id} name={o.label} sub={`${o.kind} · ${Math.round(o.w)}×${Math.round(o.h)}`} icon={Box} color={o.color} locked={o.locked} visible={o.visible} selected={selection.includes(o.id)} testPrefix="layer-stage" onRename={(n) => rename("stage", o.id, n)} />
          ))}
        </div>
      </div>
    </div>
  );
}
