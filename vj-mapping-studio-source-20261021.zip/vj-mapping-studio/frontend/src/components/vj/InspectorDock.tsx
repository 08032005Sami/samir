// Right dock: tabbed inspector (Wall Calc, Inspector, Border FX, Hierarchy, Presets).

import { store, useEditor } from "@/lib/store";
import WallCalculatorTab from "./WallCalculatorTab";
import PropertiesTab from "./PropertiesTab";
import BorderFxTab from "./BorderFxTab";
import LayersTab from "./LayersTab";
import TemplatesTab from "./TemplatesTab";
import { Calculator, SlidersHorizontal, Sparkles, Layers, LayoutTemplate, X } from "lucide-react";

const TABS = [
  { id: "calc", label: "Wall Calc", icon: Calculator },
  { id: "inspect", label: "Inspector", icon: SlidersHorizontal },
  { id: "fx", label: "Border FX", icon: Sparkles },
  { id: "layers", label: "Layers", icon: Layers },
  { id: "templates", label: "Presets", icon: LayoutTemplate },
] as const;

export default function InspectorDock() {
  const active = useEditor((s) => s.activeInspector);
  const open = useEditor((s) => s.inspectorOpen);

  return (
    <aside
      className={`flex w-[360px] shrink-0 flex-col border-l border-[#212A3D] bg-[#121722] max-lg:fixed max-lg:inset-y-0 max-lg:right-0 max-lg:z-40 max-lg:w-[min(360px,92vw)] max-lg:shadow-2xl max-lg:transition-transform max-lg:duration-200 ${open ? "max-lg:translate-x-0" : "max-lg:translate-x-full"}`}
      data-testid="inspector-dock"
    >
      <div className="flex shrink-0 border-b border-[#212A3D]" role="tablist">
        {TABS.map((t) => {
          const Icon = t.icon;
          const on = active === t.id;
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={on}
              onClick={() => store.set({ activeInspector: t.id })}
              className={`flex flex-1 flex-col items-center gap-0.5 border-b-2 py-1.5 text-[10px] transition-colors ${on ? "border-[#00F0FF] text-[#00F0FF]" : "border-transparent text-[#8292AD] hover:bg-[#1D2536] hover:text-[#EBF1FC]"}`}
              data-testid={`inspector-tab-${t.id}`}
            >
              <Icon className="size-3.5" />
              {t.label}
            </button>
          );
        })}
        <button className="px-2 text-[#8292AD] lg:hidden" onClick={() => store.set({ inspectorOpen: false })} data-testid="inspector-close-btn" aria-label="Close panel">
          <X className="size-4" />
        </button>
      </div>
      <div className="vj-scroll min-h-0 flex-1 overflow-y-auto" role="tabpanel">
        {active === "calc" && <WallCalculatorTab />}
        {active === "inspect" && (
          <div className="p-3">
            <PropertiesTab />
          </div>
        )}
        {active === "fx" && <BorderFxTab />}
        {active === "layers" && <LayersTab />}
        {active === "templates" && <TemplatesTab />}
      </div>
    </aside>
  );
}
