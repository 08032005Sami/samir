// Bottom timeline: transport, scrubber, frame counter, speed, fps, duration, quick actions.

import { store, useEditor, patchCanvas, stopPlayback, tapTempo, syncFxToBpm } from "@/lib/store";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  SkipBack,
  Play,
  Pause,
  Square,
  Repeat,
  MonitorPlay,
  Film,
} from "lucide-react";
import { fmtInt } from "@/lib/format";

export default function BottomTimeline() {
  const playing = useEditor((s) => s.playing);
  const loop = useEditor((s) => s.loop);
  const time = useEditor((s) => s.time);
  const speed = useEditor((s) => s.speed);
  const fps = useEditor((s) => s.doc.canvas.fps);
  const duration = useEditor((s) => s.doc.exportSettings.duration);
  const exactLoop = useEditor((s) => s.doc.exportSettings.exactLoop);
  const bpm = useEditor((s) => s.bpm);
  const beatsPerCycle = useEditor((s) => s.beatsPerCycle);
  const beatOn = Math.floor(time * (bpm / 60) * 2) % 2 === 0;

  const totalFrames = Math.max(1, Math.round(duration * fps));
  const frame = Math.min(totalFrames, Math.floor(time * fps) + 1);

  const timecode = (t: number) => {
    const s = Math.floor(t);
    const f = Math.floor((t - s) * fps);
    return `${String(s).padStart(2, "0")}:${String(f).padStart(2, "0")}`;
  };

  return (
    <div className="flex h-full items-center gap-2 overflow-hidden border-t border-[#212A3D] bg-[#0E121A] px-2" data-testid="timeline">
      {/* transport */}
      <div className="flex shrink-0 items-center gap-1">
        <Button variant="ghost" size="icon-sm" onClick={() => store.set({ time: 0 })} title="Go to start" data-testid="timeline-start-btn">
          <SkipBack className="size-4" />
        </Button>
        <Button
          variant="default"
          size="icon-sm"
          onClick={() => store.set((s) => ({ playing: !s.playing }))}
          title={playing ? "Pause (Space)" : "Play (Space)"}
          data-testid="timeline-play-btn"
          className="bg-[#00F0FF] text-[#05090F] hover:bg-[#00F0FF]/80"
        >
          {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
        </Button>
        <Button variant="ghost" size="icon-sm" onClick={() => stopPlayback()} title="Stop" data-testid="timeline-stop-btn">
          <Square className="size-3.5" />
        </Button>
        <Button
          variant={loop ? "secondary" : "ghost"}
          size="icon-sm"
          onClick={() => store.set((s) => ({ loop: !s.loop }))}
          title="Loop"
          data-testid="timeline-loop-btn"
          className={loop ? "text-[#00F0FF]" : ""}
        >
          <Repeat className="size-4" />
        </Button>
      </div>

      {/* frame / timecode */}
      <div className="flex shrink-0 flex-col items-center whitespace-nowrap rounded bg-[#171D2A] px-3 py-1 font-mono text-[11px] leading-tight" data-testid="timeline-frame-counter">
        <span className="text-[#00F0FF]">
          F {String(frame).padStart(4, "0")} / {String(totalFrames).padStart(4, "0")}
        </span>
        <span className="text-[#7A8BA6]">{timecode(time)}s / {timecode(duration)}s</span>
      </div>

      {/* scrubber */}
      <div className="flex min-w-[140px] flex-1 items-center gap-2">
        <input
          type="range"
          min={0}
          max={duration}
          step={1 / fps}
          value={Math.min(time, duration)}
          onChange={(e) => store.set({ time: Number(e.target.value) })}
          className="vj-range w-full"
          data-testid="timeline-scrubber"
          aria-label="Timeline scrubber"
        />
      </div>

      {/* fps + speed + duration */}
      <div className="flex shrink-0 items-center gap-2 text-[11px] font-mono text-[#7A8BA6]">
        <label className="flex items-center gap-1">
          FPS
          <Select value={String(fps)} onValueChange={(v) => patchCanvas({ fps: Number(v) })}>
            <SelectTrigger size="sm" className="w-[64px] font-mono text-[11px]" data-testid="timeline-fps-select">
              <SelectValue>{fps}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {[24, 25, 30, 50, 60].map((f) => (
                <SelectItem key={f} value={String(f)}>
                  {f}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </label>
        <label className="flex items-center gap-1">
          DUR
          <input
            type="number"
            min={0.5}
            max={60}
            step={0.5}
            value={duration}
            onChange={(e) =>
              store.set((s) => ({ doc: { ...s.doc, exportSettings: { ...s.doc.exportSettings, duration: Math.max(0.5, Math.min(60, Number(e.target.value) || 1)) } }, dirty: true }))
            }
            className="w-[52px] rounded border border-[#212A3D] bg-[#0B0D13] px-1.5 py-1 font-mono text-[11px] text-[#F0F4FC]"
            data-testid="timeline-duration-input"
          />
        </label>
        <label className="hidden items-center gap-1 2xl:flex">
          SPD
          <input
            type="range"
            min={0.1}
            max={4}
            step={0.05}
            value={speed}
            onChange={(e) => store.set({ speed: Number(e.target.value) })}
            className="vj-range w-[56px]"
            data-testid="timeline-speed-slider"
          />
          <span className="w-8 text-[#00F0FF]">{speed.toFixed(2)}×</span>
        </label>
        <div className="flex items-center gap-1 rounded border border-[#212A3D] px-1.5 py-0.5" data-testid="bpm-controls">
          <span className={`size-1.5 rounded-full ${beatOn ? "bg-[#FF3366]" : "bg-[#2A3550]"}`} />
          <button className="rounded bg-[#1D2536] px-1.5 py-0.5 text-[10px] font-bold text-[#F0F4FC] hover:bg-[#FF3366] active:scale-95" onClick={() => tapTempo()} title="Tap tempo (B)" data-testid="bpm-tap-btn">TAP</button>
          <input type="number" min={40} max={300} step={0.1} value={bpm} onChange={(e) => store.set({ bpm: Math.min(300, Math.max(40, Number(e.target.value) || 120)) })} className="w-[62px] rounded border border-[#212A3D] bg-[#0B0D13] px-1 py-0.5 font-mono text-[11px] text-[#F0F4FC]" data-testid="bpm-input" aria-label="BPM" />
          <span className="hidden 2xl:inline">BPM</span>
          <select value={beatsPerCycle} onChange={(e) => store.set({ beatsPerCycle: Number(e.target.value) })} className="rounded border border-[#212A3D] bg-[#0B0D13] px-0.5 py-0.5 text-[10px] text-[#F0F4FC]" data-testid="bpm-beats-select" title="Beats per contour cycle">
            {[1, 2, 4, 8, 16].map((b) => <option key={b} value={b}>{`${b}b/loop`}</option>)}
          </select>
          <button className="rounded bg-[#FF3366]/20 px-1.5 py-0.5 text-[10px] font-bold text-[#FF3366] hover:bg-[#FF3366]/40" onClick={() => (syncFxToBpm(), toast.success(`All Border FX synced to ${bpm} BPM`))} data-testid="bpm-sync-btn">SYNC FX</button>
        </div>
        {exactLoop && (
          <span className="hidden rounded border border-[#00FFA3]/40 bg-[#06261A] px-1.5 py-0.5 text-[10px] text-[#00FFA3] 2xl:inline" title="Sequence export snaps every effect speed so frame N loops to frame 0">
            EXACT LOOP
          </span>
        )}
      </div>

      {/* right actions */}
      <div className="flex shrink-0 items-center gap-1">
        <Button variant="ghost" size="sm" onClick={() => store.set({ previewOpen: true })} title="Open fullscreen preview" data-testid="timeline-preview-btn">
          <MonitorPlay className="size-4" /> <span className="hidden 2xl:inline">Preview</span>
        </Button>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => store.set({ exportOpen: true })}
          title="Export PNG sequence ZIP"
          data-testid="timeline-zip-btn"
        >
          <Film className="size-4" /> <span className="hidden 2xl:inline">Export</span>
        </Button>
      </div>
    </div>
  );
}

export { fmtInt };
