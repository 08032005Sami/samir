// Technical report / show sheet — rendered into a print window for PDF output,
// with CSV + PNG overview exports.

import { useMemo, useState } from "react";
import { toast } from "sonner";
import { store, useEditor } from "@/lib/store";
import { buildCabinets, docTotals, screenPhysMm, screenPitchMm, screenRes, screenPower } from "@/lib/led";
import { renderFrame } from "@/lib/engine";
import { downloadCsv, exportPng } from "@/lib/exporters";
import { fmtInt, fmtNum } from "@/lib/format";
import { ORDERS } from "@/lib/project";
import type { ProjectDoc } from "@/lib/types";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Printer, FileSpreadsheet, Image } from "lucide-react";

function overviewDataUrl(doc: ProjectDoc): string {
  const W = 1400;
  const H = Math.round((W * doc.canvas.height) / doc.canvas.width);
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  renderFrame(cv.getContext("2d")!, doc, W, H, 0.6, "map");
  return cv.toDataURL("image/png");
}

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c] ?? c);

export function buildReportHtml(doc: ProjectDoc, audience: string, includeCabinets: boolean): string {
  const t = docTotals(doc);
  const img = overviewDataUrl(doc);
  const rows = doc.screens
    .map((s) => {
      const r = screenRes(s);
      const p = screenPhysMm(s);
      return `<tr><td>${esc(s.name)}</td><td>${Math.round(s.x)}, ${Math.round(s.y)}</td><td>${r.w}×${r.h}</td><td>${fmtNum(p.w / 1000, 2)}×${fmtNum(p.h / 1000, 2)} m<br/><small>${fmtNum(p.w / 304.8, 2)}×${fmtNum(p.h / 304.8, 2)} ft</small></td><td>${s.cabW}×${s.cabH} mm</td><td>${s.cabResX}×${s.cabResY}</td><td>${s.cabsX}×${s.cabsY} = ${s.cabsX * s.cabsY}</td><td>${fmtNum(screenPitchMm(s), 2)} mm</td><td>${s.rotation}°</td><td>${ORDERS.find((o) => o.id === s.order)?.name ?? s.order}</td><td>${fmtInt(screenPower(s).max)} W</td></tr>`;
    })
    .join("");
  const cabTables = includeCabinets
    ? doc.screens
        .map((s) => {
          const cabs = buildCabinets(s).slice(0, 400);
          return `<h3>${esc(s.name)} — cabinet coordinates</h3><table class="cab"><tr><th>#</th><th>Col,Row</th><th>Pixel range</th><th>Global X,Y</th><th>Physical mm</th></tr>${cabs
            .map((c) => `<tr><td>C${c.number}</td><td>${c.col},${c.row}</td><td>${c.pxX}-${c.pxX + s.cabResX - 1}, ${c.pxY}-${c.pxY + s.cabResY - 1}</td><td>${c.globX}, ${c.globY}</td><td>${c.physX}, ${c.physY}</td></tr>`)
            .join("")}</table>`;
        })
        .join("")
    : "";
  return `<!doctype html><html><head><meta charset="utf-8"/><title>${esc(doc.name)} — Show Sheet</title>
<style>
*{box-sizing:border-box}body{font-family:Helvetica,Arial,sans-serif;color:#0B0D13;margin:28px;font-size:11px}
h1{font-size:22px;margin:0}h2{font-size:14px;margin:22px 0 6px;border-bottom:2px solid #00B4D8;padding-bottom:3px}h3{font-size:12px;margin:16px 0 4px}
.meta{color:#556;margin-top:4px}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:10px}
.k{border:1px solid #ccd;border-radius:4px;padding:6px 8px}.k b{display:block;font-size:14px;font-family:monospace}.k span{font-size:9px;text-transform:uppercase;color:#667;letter-spacing:.06em}
table{width:100%;border-collapse:collapse;margin-top:6px}th,td{border:1px solid #ccd;padding:3px 5px;text-align:left;font-size:10px}th{background:#eef3f8}
table.cab td,table.cab th{font-family:monospace;font-size:9px}img{width:100%;border:1px solid #ccd;margin-top:8px;background:#000}
.note{font-size:9px;color:#667;margin-top:6px}@media print{body{margin:12mm}h2{break-after:avoid}table{break-inside:auto}tr{break-inside:avoid}}
</style></head><body>
<h1>${esc(doc.name)}</h1>
<div class="meta">Technical Show Sheet · Prepared for: <b>${esc(audience)}</b> · ${esc(doc.meta.event || "")} ${doc.meta.author ? "· by " + esc(doc.meta.author) : ""} · Generated ${new Date().toLocaleString()} · VJ Mapping Studio</div>
<div class="grid">
<div class="k"><span>Canvas resolution</span><b>${doc.canvas.width}×${doc.canvas.height}</b></div>
<div class="k"><span>Total LED pixels</span><b>${fmtInt(t.pixels)} (${fmtNum(t.mp, 2)} MP)</b></div>
<div class="k"><span>Total cabinets</span><b>${fmtInt(t.cabinets)}</b></div>
<div class="k"><span>Screens</span><b>${doc.screens.length}</b></div>
<div class="k"><span>Aspect ratio</span><b>${t.aspectW}:${t.aspectH}</b></div>
<div class="k"><span>Sending ports (est.)</span><b>${t.ports} @ 650k px</b></div>
<div class="k"><span>Power (est.)</span><b>${fmtInt(t.powerMax)} W max / ${fmtInt(t.powerTypical)} W typ</b></div>
<div class="k"><span>Weight (est.)</span><b>${fmtInt(t.weightKg)} kg</b></div>
</div>
<h2>Pixel map overview</h2><img src="${img}"/>
<h2>Screen list</h2>
<table><tr><th>Screen</th><th>Canvas X,Y</th><th>Resolution</th><th>Physical size</th><th>Cabinet</th><th>Cab res</th><th>Cabinets</th><th>Pitch</th><th>Rot</th><th>Mapping order</th><th>Power max</th></tr>${rows}</table>
<h2>Export settings</h2>
<table><tr><th>Sequence frame</th><td>${doc.exportSettings.frameW}×${doc.exportSettings.frameH}</td><th>FPS</th><td>${doc.exportSettings.fps}</td><th>Duration</th><td>${doc.exportSettings.duration}s (${Math.round(doc.exportSettings.duration * doc.exportSettings.fps)} frames)</td><th>Exact loop</th><td>${doc.exportSettings.exactLoop ? "yes" : "no"}</td></tr></table>
${doc.meta.notes ? `<h2>Notes</h2><p>${esc(doc.meta.notes).replace(/\n/g, "<br/>")}</p>` : ""}
${cabTables ? `<h2>Cabinet coordinates</h2>${cabTables}` : ""}
<p class="note">Power, weight, port and bandwidth figures are estimates (690 W/m² max, 35% typical, 35 kg/m², 650,000 px per port). Verify against the cabinet and processor datasheets.</p>
<script>window.onload=()=>setTimeout(()=>window.print(),300)</script>
</body></html>`;
}

export default function TechReportModal() {
  const open = useEditor((s) => s.reportOpen);
  const doc = useEditor((s) => s.doc);
  const [audience, setAudience] = useState("LED Technician");
  const [includeCabs, setIncludeCabs] = useState(true);
  const totals = useMemo(() => docTotals(doc), [doc]);

  const setMeta = (patch: Partial<ProjectDoc["meta"]>) => store.set((s) => ({ doc: { ...s.doc, meta: { ...s.doc.meta, ...patch } }, dirty: true }));

  const printPdf = () => {
    const w = window.open("", "_blank");
    if (!w) {
      toast.error("Pop-up blocked — allow pop-ups to print the PDF report.");
      return;
    }
    w.document.write(buildReportHtml(doc, audience, includeCabs));
    w.document.close();
    toast.success("Report opened — choose “Save as PDF” in the print dialog");
  };

  return (
    <Dialog open={open} onOpenChange={(o) => store.set({ reportOpen: o })}>
      <DialogContent className="max-w-[620px] border-[#263249] bg-[#131926] sm:max-w-[620px]" data-testid="report-modal">
        <DialogHeader>
          <DialogTitle className="font-heading">Professional LED Report & Show Sheet</DialogTitle>
          <DialogDescription className="text-[#8B9BB8]">Printable technical document with diagram, screen list, cabinet coordinates and export settings.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-2">
          <label className="text-[10px] text-[#8B9BB8]">Event<Input value={doc.meta.event} onChange={(e) => setMeta({ event: e.target.value })} className="mt-1 h-8 text-xs" data-testid="report-event-input" /></label>
          <label className="text-[10px] text-[#8B9BB8]">Prepared by<Input value={doc.meta.author} onChange={(e) => setMeta({ author: e.target.value })} className="mt-1 h-8 text-xs" data-testid="report-author-input" /></label>
          <label className="col-span-2 text-[10px] text-[#8B9BB8]">Notes<Textarea value={doc.meta.notes} onChange={(e) => setMeta({ notes: e.target.value })} className="mt-1 min-h-[64px] text-xs" data-testid="report-notes-input" /></label>
        </div>
        <div className="flex flex-wrap gap-1">
          {["LED Technician", "VJ", "Event Production", "Rental Company"].map((a) => (
            <button key={a} onClick={() => setAudience(a)} className={`rounded px-2 py-1 text-[10px] ${audience === a ? "bg-[#00F0FF] text-[#05090F]" : "bg-[#1D2536] text-[#8B9BB8]"}`} data-testid={`report-audience-${a.split(" ")[0].toLowerCase()}`}>{a}</button>
          ))}
        </div>
        <div className="grid grid-cols-4 gap-1.5 font-mono text-[10px]" data-testid="report-summary">
          <div className="rounded bg-[#192131] p-1.5">{doc.canvas.width}×{doc.canvas.height}<br /><span className="text-[#8B9BB8]">canvas</span></div>
          <div className="rounded bg-[#192131] p-1.5">{fmtNum(totals.mp, 2)} MP<br /><span className="text-[#8B9BB8]">pixels</span></div>
          <div className="rounded bg-[#192131] p-1.5">{fmtInt(totals.cabinets)}<br /><span className="text-[#8B9BB8]">cabinets</span></div>
          <div className="rounded bg-[#192131] p-1.5">{doc.screens.length}<br /><span className="text-[#8B9BB8]">screens</span></div>
        </div>
        <label className="flex items-center gap-2 text-[11px] text-[#8B9BB8]"><Checkbox checked={includeCabs} onCheckedChange={(c) => setIncludeCabs(c === true)} data-testid="report-include-cabinets" /> Include cabinet coordinate tables</label>
        <div className="grid grid-cols-3 gap-2">
          <Button className="bg-[#00F0FF] text-[#05090F] hover:bg-[#00F0FF]/80" onClick={printPdf} data-testid="report-print-pdf"><Printer className="size-3.5" /> PDF / Print</Button>
          <Button variant="secondary" onClick={() => downloadCsv(doc, true)} data-testid="report-csv"><FileSpreadsheet className="size-3.5" /> CSV</Button>
          <Button variant="secondary" onClick={() => exportPng(doc, "map", doc.canvas.width, doc.canvas.height)} data-testid="report-png"><Image className="size-3.5" /> PNG overview</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
