// Left vertical tool palette — every tool with its shortcut hint.

import { store, useEditor, setTool } from "@/lib/store";
import type { ToolId } from "@/lib/types";
import {
  MousePointer2,
  Hand,
  Monitor,
  Square,
  Squircle,
  Circle,
  Triangle,
  Diamond,
  Hexagon,
  Sparkles,
  PenTool,
  PencilLine,
  Minus,
  Grid3X3,
  Magnet,
} from "lucide-react";

interface ToolDef {
  id: ToolId;
  icon: typeof MousePointer2;
  label: string;
  key?: string;
}

const TOOLS: ToolDef[] = [
  { id: "select", icon: MousePointer2, label: "Select & Transform", key: "V" },
  { id: "hand", icon: Hand, label: "Hand / Pan", key: "H" },
  { id: "screen", icon: Monitor, label: "Add LED Screen / Wall", key: "S" },
  { id: "rect", icon: Square, label: "Rectangle Contour", key: "R" },
  { id: "rrect", icon: Squircle, label: "Rounded Rectangle", key: "" },
  { id: "circle", icon: Circle, label: "Circle Contour", key: "C" },
  { id: "triangle", icon: Triangle, label: "Triangle Contour", key: "T" },
  { id: "diamond", icon: Diamond, label: "Diamond Contour", key: "D" },
  { id: "hexagon", icon: Hexagon, label: "Hexagon Contour", key: "X" },
  { id: "star", icon: Sparkles, label: "Star Contour", key: "" },
  { id: "pen", icon: PenTool, label: "Pen / Bezier Path", key: "P" },
  { id: "freehand", icon: PencilLine, label: "Freehand Path", key: "" },
  { id: "line", icon: Minus, label: "Line Contour", key: "" },
];

export default function LeftToolbar() {
  const tool = useEditor((s) => s.tool);
  const showGrid = useEditor((s) => s.showGrid);
  const snapGrid = useEditor((s) => s.snapGrid);

  return (
    <div className="flex w-[52px] shrink-0 flex-col items-center gap-1 border-r border-[#212A3D] bg-[#10141D] py-2" data-testid="tool-palette">
      {TOOLS.map((t) => {
        const Icon = t.icon;
        const active = tool === t.id;
        return (
          <button
            key={t.id}
            onClick={() => setTool(t.id)}
            title={t.key ? `${t.label} (${t.key})` : t.label}
            data-testid={`tool-${t.id}`}
            className={`flex h-9 w-9 items-center justify-center rounded-md border transition-colors ${
              active ? "border-[#00F0FF] bg-[#00F0FF]/10 text-[#00F0FF]" : "border-transparent text-[#8A99B5] hover:bg-[#1D2536] hover:text-[#F0F4FC]"
            }`}
          >
            <Icon className="size-4" />
          </button>
        );
      })}

      <div className="mt-2 h-px w-6 bg-[#212A3D]" />
      <button
        onClick={() => store.set((s) => ({ showGrid: !s.showGrid, snapGrid: !s.showGrid }))}
        title="Toggle grid & snapping (G)"
        data-testid="tool-toggle-grid"
        className={`flex h-9 w-9 items-center justify-center rounded-md border transition-colors ${
          showGrid ? "border-[#00F0FF] bg-[#00F0FF]/10 text-[#00F0FF]" : "border-transparent text-[#8A99B5] hover:bg-[#1D2536]"
        }`}
      >
        <Grid3X3 className="size-4" />
      </button>
      <button
        onClick={() => store.set((s) => ({ snapGrid: !s.snapGrid }))}
        title="Toggle snap to grid"
        data-testid="tool-toggle-snap"
        className={`flex h-9 w-9 items-center justify-center rounded-md border transition-colors ${
          snapGrid ? "border-[#00F0FF] bg-[#00F0FF]/10 text-[#00F0FF]" : "border-transparent text-[#8A99B5] hover:bg-[#1D2536]"
        }`}
      >
        <Magnet className="size-4" />
      </button>
    </div>
  );
}
