// LED Wall / Cabinet Pixel Calculator — wall in FEET (switchable to m),
// cabinets in mm/cm/in/ft, live derived metrics, "Add to Canvas".

import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiGet } from "@/lib/api";
import type { CabinetPreset, PresetsResponse } from "@/lib/types";
import { CABINET_PRESETS_FALLBACK } from "@/lib/project";
import { computeWall } from "@/lib/led";
import type { WallCalc } from "@/lib/led";
import { addScreenFromCalc, patchCanvas, store, useEditor } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fmtInt, fmtNum } from "@/lib/format";

function NumField({
  label,
  value,
  onChange,
  testId,
  step = 1,
  min = 0,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  testId: string;
  step?: number;
  min?: number;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10px] uppercase tracking-wider text-[#8292AD]">{label}</span>
      <Input
        type="number"
        value={Number.isFinite(value) ? value : 0}
        step={step}
        min={min}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-8 border-[#212A3D] bg-[#0B0D13] font-mono text-xs text-[#F0F4FC]"
        data-testid={testId}
      />
    </label>
  );
}

function Metric({ label, value, accent, title }: { label: string; value: string; accent?: boolean; title?: string }) {
  return (
    <div className="rounded border border-[#212A3D] bg-[#0E121A] px-2.5 py-1.5" title={title}>
      <div className="text-[9px] uppercase tracking-wider text-[#8292AD]">{label}</div>
      <div className={`font-mono text-sm ${accent ? "text-[#00F0FF]" : "text-[#F0F4FC]"}`}>{value}</div>
    </div>
  );
}

export default function WallCalculatorTab() {
  const canvas = useEditor((s) => s.doc.canvas);

  const presetsQ = useQuery({
    queryKey: ["presets"],
    queryFn: () => apiGet<PresetsResponse>("/presets"),
    retry: false,
    staleTime: Infinity,
  });
  const cabinets: CabinetPreset[] = presetsQ.data?.cabinets ?? CABINET_PRESETS_FALLBACK;

  const [wallW, setWallW] = useState(12);
  const [wallH, setWallH] = useState(8);
  const [wallUnit, setWallUnit] = useState<"ft" | "m">("ft");
  const [cabW, setCabW] = useState(609.6);
  const [cabH, setCabH] = useState(609.6);
  const [cabUnit, setCabUnit] = useState<"mm" | "cm" | "in" | "ft">("mm");
  const [cabResX, setCabResX] = useState(156);
  const [cabResY, setCabResY] = useState(156);
  const [refreshHz, setRefreshHz] = useState(3840);
  const [scan, setScan] = useState(0);
  const [allowPartial, setAllowPartial] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const calc: WallCalc = useMemo(
    () => computeWall({ wallW, wallH, wallUnit, cabW, cabH, cabUnit, cabResX, cabResY, refreshHz, scan, allowPartial }),
    [wallW, wallH, wallUnit, cabW, cabH, cabUnit, cabResX, cabResY, refreshHz, scan, allowPartial],
  );

  const applyCabinetPreset = (name: string) => {
    const p = cabinets.find((c) => c.name === name);
    if (!p) return;
    setCabW(p.width_mm);
    setCabH(p.height_mm);
    setCabResX(p.res_x);
    setCabResY(p.res_y);
    setCabUnit("mm");
  };

  const addToCanvas = () => {
    if (!calc.ok) {
      toast.error(calc.error);
      return;
    }
    const r = calc.result;
    if (r.canvas_w > canvas.width || r.canvas_h > canvas.height) {
      patchCanvas({ width: Math.max(canvas.width, r.canvas_w), height: Math.max(canvas.height, r.canvas_h) });
    }
    addScreenFromCalc(r.cabinets_x, r.cabinets_y, cabResX, cabResY, toMmValue(cabW, cabUnit), toMmValue(cabH, cabUnit));
    toast.success(`Added ${r.cabinets_x}×${r.cabinets_y} wall (${r.canvas_w}×${r.canvas_h}px) to canvas`);
  };

  return (
    <div className="space-y-3 p-3" data-testid="wall-calculator">
      <div>
        <h3 className="font-heading text-sm font-bold text-[#F0F4FC]">LED Wall Calculator</h3>
        <p className="text-[10px] text-[#8292AD]">Wall dimensions in feet · cabinets in mm / cm / in / ft</p>
      </div>

      {/* wall inputs */}
      <div className="grid grid-cols-2 gap-2">
        <NumField label={`Wall Width (${wallUnit})`} value={wallW} onChange={setWallW} testId="wall-calc-width-ft" step={0.5} min={0.5} />
        <NumField label={`Wall Height (${wallUnit})`} value={wallH} onChange={setWallH} testId="wall-calc-height-ft" step={0.5} min={0.5} />
      </div>
      <div className="flex items-center gap-1">
        {(["ft", "m"] as const).map((u) => (
          <button
            key={u}
            onClick={() => setWallUnit(u)}
            className={`rounded px-2 py-0.5 font-mono text-[10px] ${wallUnit === u ? "bg-[#00F0FF] text-[#05090F]" : "bg-[#1D2536] text-[#8A99B5] hover:text-[#F0F4FC]"}`}
            data-testid={`wall-unit-${u}`}
          >
            {u === "ft" ? "FEET" : "METERS"}
          </button>
        ))}
        <span className="ml-auto text-[10px] text-[#8292AD]">
          = {fmtNum(toMmValue(wallW, wallUnit) / 1000, 2)} × {fmtNum(toMmValue(wallH, wallUnit) / 1000, 2)} m
        </span>
      </div>

      {/* cabinet inputs */}
      <div className="rounded border border-[#212A3D] bg-[#0E121A] p-2.5">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-[10px] uppercase tracking-wider text-[#8292AD]">LED Cabinet</span>
          <Select onValueChange={applyCabinetPreset}>
            <SelectTrigger size="sm" className="w-[220px] text-[10px]" data-testid="cabinet-preset-select">
              <SelectValue placeholder="Cabinet presets…" />
            </SelectTrigger>
            <SelectContent className="bg-[#131926] border-[#263249]">
              {cabinets.map((c) => (
                <SelectItem key={c.name} value={c.name} className="text-xs">
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <NumField label="Cabinet W" value={cabW} onChange={setCabW} testId="cabinet-width-input" step={10} />
          <NumField label="Cabinet H" value={cabH} onChange={setCabH} testId="cabinet-height-input" step={10} />
          <NumField label="Res X (px)" value={cabResX} onChange={setCabResX} testId="cabinet-res-x-input" />
          <NumField label="Res Y (px)" value={cabResY} onChange={setCabResY} testId="cabinet-res-y-input" />
        </div>
        <div className="mt-2 flex items-center gap-1">
          {(["mm", "cm", "in", "ft"] as const).map((u) => (
            <button
              key={u}
              onClick={() => setCabUnit(u)}
              className={`rounded px-2 py-0.5 font-mono text-[10px] ${cabUnit === u ? "bg-[#00F0FF] text-[#05090F]" : "bg-[#1D2536] text-[#8A99B5] hover:text-[#F0F4FC]"}`}
              data-testid={`cabinet-unit-${u}`}
            >
              {u}
            </button>
          ))}
        </div>
      </div>

      {/* results */}
      {calc.ok ? (
        <div className="space-y-2" data-testid="wall-calc-results">
          <div className="grid grid-cols-2 gap-2">
            <Metric label="Cabinets" value={`${calc.result.cabinets_x} × ${calc.result.cabinets_y} = ${fmtInt(calc.result.total_cabinets)}`} accent />
            <Metric label="Canvas Resolution" value={`${fmtInt(calc.result.canvas_w)} × ${fmtInt(calc.result.canvas_h)}`} accent />
            <Metric label="Actual Wall" value={`${calc.result.actual_w_mm} × ${calc.result.actual_h_mm} mm`} />
            <Metric label="Wall (feet)" value={`${fmtNum(calc.result.actual_w_mm / 304.8, 2)} × ${fmtNum(calc.result.actual_h_mm / 304.8, 2)} ft`} />
            <Metric label="Total Pixels" value={fmtInt(calc.result.total_pixels)} />
            <Metric label="Megapixels" value={`${calc.result.megapixels} MP`} accent />
            <Metric label="Aspect Ratio" value={`${calc.result.aspect_w}:${calc.result.aspect_h} (${calc.result.aspect_dec})`} />
            <Metric label="Pixel Pitch" value={`${calc.result.pixel_pitch_mm} mm`} />
            <Metric label="Pixel Density" value={`${fmtInt(calc.result.px_per_m2)} px/m²`} title={`${fmtInt(calc.result.px_per_m)} px/m horizontal`} />
            <Metric label="Viewing Distance" value={`${calc.result.min_view_m}–${calc.result.opt_view_m} m`} title="Minimum to optimal viewing distance (estimate)" />
            <Metric label="Power (est.)" value={`${fmtInt(calc.result.power_max_w)} W max / ${fmtInt(calc.result.power_typical_w)} W typ`} title="ESTIMATE — hardware specific" />
            <Metric label="Weight (est.)" value={`${fmtInt(calc.result.weight_kg)} kg`} title="ESTIMATE — 35 kg/m² die-cast average" />
            <Metric label="Sending Ports" value={`${calc.result.sending_ports}`} title="ESTIMATE — 650,000 px/port (NovaStar/Brompton class)" />
            <Metric label="Bandwidth (est.)" value={calc.result.bandwidth_gbps !== null ? `${calc.result.bandwidth_gbps} Gbps` : "—"} title="ESTIMATE — needs refresh rate; 24-bit ×1.25 overhead" />
          </div>

          {calc.result.warnings.map((w, i) => (
            <div key={i} className="rounded border border-[#FFB800]/40 bg-[#2B1E06] px-2.5 py-1.5 text-[11px] text-[#FFB800]" data-testid="wall-calc-warning">
              ⚠ {w}
            </div>
          ))}

          <Button className="w-full bg-[#00F0FF] font-semibold text-[#05090F] hover:bg-[#00F0FF]/80" onClick={addToCanvas} data-testid="wall-calc-add-canvas">
            Add to Canvas — {fmtInt(calc.result.canvas_w)}×{fmtInt(calc.result.canvas_h)}px
          </Button>
        </div>
      ) : (
        <div className="rounded border border-[#FF5C7A]/40 bg-[#2B0B14] px-3 py-2 text-[11px] leading-relaxed text-[#FF5C7A]" data-testid="wall-calc-error">
          {calc.error}
        </div>
      )}

      <label className="flex items-center gap-2 text-xs text-[#8A99B5]" data-testid="wall-calc-partial-label">
        <Checkbox checked={allowPartial} onCheckedChange={(c) => setAllowPartial(c === true)} data-testid="wall-calc-partial" />
        Allow partial / custom layout (nearest whole-cabinet fit)
      </label>

      {/* advanced */}
      <button className="flex w-full items-center justify-between rounded border border-[#212A3D] px-2.5 py-1.5 text-[11px] text-[#8A99B5] hover:bg-[#1D2536]" onClick={() => setShowAdvanced(!showAdvanced)} data-testid="wall-calc-advanced-toggle">
        <span>ADVANCED — scan / refresh / module arrangement</span>
        <span>{showAdvanced ? "−" : "+"}</span>
      </button>
      {showAdvanced && (
        <div className="grid grid-cols-2 gap-2 rounded border border-[#212A3D] bg-[#0E121A] p-2.5">
          <NumField label="Refresh Rate (Hz)" value={refreshHz} onChange={setRefreshHz} testId="wall-calc-refresh" step={120} />
          <NumField label="Scan Type" value={scan} onChange={setScan} testId="wall-calc-scan" />
          <div className="col-span-2 text-[10px] leading-relaxed text-[#8292AD]">
            Refresh + scan feed the bandwidth estimate and the receiving-card region plan (per-port pixel ceiling 650k px). Values are
            hardware-specific estimates — verify against your processor datasheet.
          </div>
        </div>
      )}

      {/* canvas quick presets */}
      <div className="rounded border border-[#212A3D] p-2.5">
        <p className="mb-1.5 text-[10px] uppercase tracking-wider text-[#8292AD]">Canvas quick presets</p>
        <div className="flex flex-wrap gap-1">
          {[
            [1920, 1080],
            [2560, 1440],
            [3840, 2160],
            [1080, 1920],
            [7680, 2160],
          ].map(([w, h]) => (
            <button
              key={`${w}x${h}`}
              onClick={() => patchCanvas({ width: w, height: h })}
              className="rounded bg-[#1D2536] px-2 py-0.5 font-mono text-[10px] text-[#8A99B5] hover:text-[#00F0FF]"
              data-testid={`canvas-preset-${w}x${h}`}
            >
              {w}×{h}
            </button>
          ))}
          <button
            onClick={() => store.set({ activeInspector: "inspect" })}
            className="rounded bg-[#1D2536] px-2 py-0.5 font-mono text-[10px] text-[#00F0FF]"
            data-testid="canvas-custom-link"
          >
            custom →
          </button>
        </div>
      </div>
    </div>
  );
}

function toMmValue(v: number, unit: string): number {
  return v * ({ mm: 1, cm: 10, in: 25.4, ft: 304.8, m: 1000 }[unit] ?? 1);
}
