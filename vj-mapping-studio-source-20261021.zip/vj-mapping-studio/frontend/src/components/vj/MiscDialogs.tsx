// Misc dialogs: keyboard shortcuts + Resolume guide, fullscreen live preview,
// VJ calculators, new-project presets.

import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { store, useEditor, loadDoc } from "@/lib/store";
import { SHORTCUTS, REMAPPABLE, getKeyMap, setKeyBinding, resetKeyMap } from "@/lib/shortcuts";
import { renderFrame } from "@/lib/engine";
import { SCENE_PRESETS, newFromScenePreset, baseDoc } from "@/lib/project";
import { reduceAspect, computeWall } from "@/lib/led";
import { fmtInt, fmtNum } from "@/lib/format";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Play, Pause, Square, Maximize2 } from "lucide-react";

function KeyRemapper() {
  const [map, setMap] = useState(getKeyMap());
  const [listening, setListening] = useState<string | null>(null);
  useEffect(() => {
    if (!listening) return;
    const h = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (e.key === "Escape") return setListening(null);
      if (e.key.length !== 1 || e.ctrlKey || e.metaKey || e.key === " ") {
        toast.error("Use a single letter, number or symbol key (Space and Ctrl combos are reserved).");
        return;
      }
      const clash = setKeyBinding(listening, e.key);
      setMap(getKeyMap());
      setListening(null);
      toast.success(clash ? `Key "${e.key.toUpperCase()}" assigned — swapped with ${REMAPPABLE.find((r) => r.action === clash)?.label}` : `Key "${e.key.toUpperCase()}" assigned`);
    };
    window.addEventListener("keydown", h, { capture: true });
    return () => window.removeEventListener("keydown", h, { capture: true });
  }, [listening]);
  return (
    <div className="space-y-1" data-testid="key-remapper">
      <div className="flex items-center justify-between">
        <p className="text-[10px] uppercase tracking-wider text-[#8B9BB8]">Customize single-key shortcuts</p>
        <button className="text-[10px] text-[#00F0FF] hover:underline" onClick={() => (resetKeyMap(), setMap(getKeyMap()), toast.success("Shortcuts reset to defaults"))} data-testid="keymap-reset-btn">Reset defaults</button>
      </div>
      {REMAPPABLE.map((r) => (
        <div key={r.action} className="flex items-center justify-between py-0.5 text-xs">
          <span className="text-[#F5F8FF]">{r.label}</span>
          <button
            onClick={() => setListening(r.action)}
            className={`min-w-[64px] rounded border px-1.5 py-0.5 font-mono text-[10px] ${listening === r.action ? "animate-pulse border-[#FF3366] text-[#FF3366]" : "border-[#263249] bg-[#0B0D13] text-[#00F0FF] hover:border-[#00F0FF]"}`}
            data-testid={`keymap-${r.action.replace(".", "-")}`}
          >
            {listening === r.action ? "press key…" : map[r.action].toUpperCase()}
          </button>
        </div>
      ))}
    </div>
  );
}

export function ShortcutsModal() {
  const open = useEditor((s) => s.shortcutsOpen);
  const [tab, setTab] = useState<"list" | "custom">("list");
  const groups = Array.from(new Set(SHORTCUTS.map((s) => s.group)));
  const km = getKeyMap();
  return (
    <Dialog open={open} onOpenChange={(o) => store.set({ shortcutsOpen: o })}>
      <DialogContent className="max-w-[720px] border-[#263249] bg-[#131926] sm:max-w-[720px]" data-testid="shortcuts-modal">
        <DialogHeader>
          <DialogTitle className="font-heading">Keyboard Shortcuts & Resolume Workflow</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <div className="max-h-[440px] space-y-3 overflow-auto pr-1">
            <div className="flex gap-1">
              {(["list", "custom"] as const).map((t) => (
                <button key={t} onClick={() => setTab(t)} className={`rounded px-2 py-0.5 text-[10px] ${tab === t ? "bg-[#00F0FF] text-[#05090F]" : "bg-[#1D2536] text-[#8B9BB8]"}`} data-testid={`shortcuts-tab-${t}`}>{t === "list" ? "All shortcuts" : "Customize"}</button>
              ))}
            </div>
            {tab === "custom" ? <KeyRemapper /> : groups.map((g) => (
              <div key={g}>
                <p className="mb-1 text-[10px] uppercase tracking-wider text-[#8B9BB8]">{g}</p>
                {SHORTCUTS.filter((s) => s.group === g).map((s) => (
                  <div key={s.keys + s.action} className="flex items-center justify-between py-0.5 text-xs">
                    <span className="text-[#F5F8FF]">{s.label}</span>
                    <kbd className="rounded border border-[#263249] bg-[#0B0D13] px-1.5 font-mono text-[10px] text-[#00F0FF]">{km[s.action] && s.keys.length === 1 ? km[s.action].toUpperCase() : s.keys}</kbd>
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="space-y-2 text-[11px] leading-relaxed text-[#8B9BB8]" data-testid="resolume-guide">
            <p className="font-heading text-xs font-bold text-[#F5F8FF]">Resolume Arena / Avenue workflow</p>
            <ol className="list-decimal space-y-1 pl-4">
              <li>Set the composition size to the canvas resolution shown in the top bar.</li>
              <li>Export <b>Resolume Input Map PNG</b> → Advanced Output › Input Selection › <i>Load Input Map</i>; draw slices over each labeled screen.</li>
              <li>Or try the <b>Screen Setup XML</b> (best-effort, unofficial format) — copy into <code>Documents/Resolume Arena/Presets/Advanced Output</code>.</li>
              <li>Border FX, easiest: Export › <b>Resolume Video (MP4)</b> → drag onto a clip slot on the top layer → blend mode <b>Add</b>. Best quality: export the <b>PNG Sequence ZIP</b>, unzip, drag the <b>frames folder</b> into <b>Alley</b> → DXV “High Quality with Alpha” → blend mode <b>Alpha</b>.</li>
              <li>Use the <b>CSV map</b> for LED processor / Mapping Matter / media-server spreadsheets and the <b>Show Sheet PDF</b> for crew.</li>
            </ol>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function PreviewModal() {
  const open = useEditor((s) => s.previewOpen);
  const doc = useEditor((s) => s.doc);
  const playing = useEditor((s) => s.playing);
  const time = useEditor((s) => s.time);
  const [scale, setScale] = useState<"fit" | number>("fit");
  const [checker, setChecker] = useState(false);
  const [contentOnly, setContentOnly] = useState(false);
  const ref = useRef<HTMLCanvasElement | null>(null);
  const boxRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const c = ref.current;
      const box = boxRef.current;
      if (!c || !box) return;
      const k = scale === "fit" ? Math.min(box.clientWidth / doc.canvas.width, box.clientHeight / doc.canvas.height) : scale;
      const W = Math.max(16, Math.round(doc.canvas.width * k));
      const H = Math.max(16, Math.round(doc.canvas.height * k));
      if (c.width !== W || c.height !== H) {
        c.width = W;
        c.height = H;
      }
      renderFrame(c.getContext("2d")!, store.get().doc, W, H, store.get().time, contentOnly ? "content" : "map", checker);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [open, scale, checker, contentOnly, doc.canvas.width, doc.canvas.height]);

  const frame = Math.floor(time * doc.canvas.fps) + 1;
  return (
    <Dialog open={open} onOpenChange={(o) => store.set({ previewOpen: o })}>
      <DialogContent className="h-[88vh] max-w-[94vw] border-[#263249] bg-[#080A0E] sm:max-w-[94vw]" data-testid="preview-modal">
        <DialogHeader>
          <DialogTitle className="font-heading text-sm">Live Preview — {doc.name}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-wrap items-center gap-1.5">
          <Button size="xs" onClick={() => store.set((s) => ({ playing: !s.playing }))} data-testid="preview-play-btn">{playing ? <Pause className="size-3" /> : <Play className="size-3" />}{playing ? "Pause" : "Play"}</Button>
          <Button size="xs" variant="outline" onClick={() => store.set({ playing: false, time: 0 })} data-testid="preview-stop-btn"><Square className="size-3" /> Stop</Button>
          {(["fit", 0.25, 0.5, 0.75, 1] as const).map((z) => (
            <Button key={String(z)} size="xs" variant={scale === z ? "secondary" : "outline"} onClick={() => setScale(z)} data-testid={`preview-zoom-${z === "fit" ? "fit" : Math.round(z * 100)}`}>{z === "fit" ? "Fit" : z === 1 ? "100% actual px" : `${z * 100}%`}</Button>
          ))}
          <Button size="xs" variant={checker ? "secondary" : "outline"} onClick={() => setChecker(!checker)} data-testid="preview-checker-btn">Checkerboard</Button>
          <Button size="xs" variant={contentOnly ? "secondary" : "outline"} onClick={() => setContentOnly(!contentOnly)} data-testid="preview-content-only-btn">FX only</Button>
          <Button size="xs" variant="outline" onClick={() => boxRef.current?.requestFullscreen?.()} data-testid="preview-fullscreen-btn"><Maximize2 className="size-3" /> Fullscreen</Button>
          <span className="ml-auto font-mono text-[11px] text-[#00F0FF]" data-testid="preview-frame">F{String(frame).padStart(4, "0")} · {time.toFixed(2)}s · {doc.canvas.fps}fps</span>
        </div>
        <div ref={boxRef} className="flex min-h-0 flex-1 items-center justify-center overflow-auto bg-[#05070B]">
          <canvas ref={ref} className="max-w-none" data-testid="preview-canvas" />
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Out({ label, value, testId }: { label: string; value: string; testId: string }) {
  return (
    <div className="rounded bg-[#192131] px-2 py-1.5">
      <div className="text-[9px] uppercase tracking-wider text-[#8B9BB8]">{label}</div>
      <div className="font-mono text-sm text-[#00F0FF]" data-testid={testId}>{value}</div>
    </div>
  );
}

export function ToolsModal() {
  const open = useEditor((s) => s.toolsOpen);
  const [ar, setAr] = useState({ w: 1920, h: 1080, preset: "16:9", base: 1920 });
  const [res, setRes] = useState({ w: 3840, h: 2160 });
  const [pitch, setPitch] = useState({ pitch: 3.91, wft: 12, hft: 8 });
  const [cab, setCab] = useState({ wallW: 12, wallH: 8, cabW: 609.6, cabH: 609.6, rx: 156, ry: 156 });

  const presets: Record<string, [number, number]> = { "16:9": [16, 9], "16:10": [16, 10], "4:3": [4, 3], "1:1": [1, 1], "9:16": [9, 16], "21:9": [21, 9] };
  const arH = ar.preset === "Custom" ? ar.h : Math.round((ar.base * presets[ar.preset][1]) / presets[ar.preset][0]);
  const [rw, rh] = reduceAspect(res.w, res.h);
  const pitchW = Math.round((pitch.wft * 304.8) / pitch.pitch);
  const pitchH = Math.round((pitch.hft * 304.8) / pitch.pitch);
  const wall = useMemo(() => computeWall({ wallW: cab.wallW, wallH: cab.wallH, wallUnit: "ft", cabW: cab.cabW, cabH: cab.cabH, cabUnit: "mm", cabResX: cab.rx, cabResY: cab.ry, refreshHz: 0, scan: 0, allowPartial: true }), [cab]);

  const NI = ({ v, on, t, step = 1 }: { v: number; on: (n: number) => void; t: string; step?: number }) => (
    <Input type="number" value={v} step={step} onChange={(e) => on(Number(e.target.value))} className="h-8 font-mono text-xs" data-testid={t} />
  );

  return (
    <Dialog open={open} onOpenChange={(o) => store.set({ toolsOpen: o })}>
      <DialogContent className="max-w-[640px] border-[#263249] bg-[#131926] sm:max-w-[640px]" data-testid="tools-modal">
        <DialogHeader>
          <DialogTitle className="font-heading">VJ Calculators</DialogTitle>
          <DialogDescription className="text-[#8B9BB8]">Aspect ratio · resolution · LED pitch · cabinet wall mapping</DialogDescription>
        </DialogHeader>
        <Tabs defaultValue="aspect">
          <TabsList>
            <TabsTrigger value="aspect" data-testid="calc-tab-aspect">Aspect</TabsTrigger>
            <TabsTrigger value="res" data-testid="calc-tab-res">Resolution</TabsTrigger>
            <TabsTrigger value="pitch" data-testid="calc-tab-pitch">Pitch</TabsTrigger>
            <TabsTrigger value="cab" data-testid="calc-tab-cab">Cabinet</TabsTrigger>
          </TabsList>
          <TabsContent value="aspect" className="space-y-2 pt-2">
            <div className="flex flex-wrap gap-1">
              {[...Object.keys(presets), "Custom"].map((p) => (
                <button key={p} onClick={() => setAr({ ...ar, preset: p })} className={`rounded px-2 py-1 font-mono text-[10px] ${ar.preset === p ? "bg-[#00F0FF] text-[#05090F]" : "bg-[#1D2536] text-[#8B9BB8]"}`} data-testid={`aspect-preset-${p.replace(":", "-").toLowerCase()}`}>{p}</button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <label className="text-[10px] text-[#8B9BB8]">Width px<NI v={ar.base} on={(n) => setAr({ ...ar, base: n, w: n })} t="aspect-width" /></label>
              {ar.preset === "Custom" && <label className="text-[10px] text-[#8B9BB8]">Height px<NI v={ar.h} on={(n) => setAr({ ...ar, h: n })} t="aspect-height" /></label>}
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Out label="Resolution" value={`${ar.base}×${arH}`} testId="aspect-result-res" />
              <Out label="Ratio" value={ar.preset === "Custom" ? reduceAspect(ar.base, ar.h).join(":") : ar.preset} testId="aspect-result-ratio" />
              <Out label="Megapixels" value={fmtNum((ar.base * arH) / 1e6, 2)} testId="aspect-result-mp" />
            </div>
          </TabsContent>
          <TabsContent value="res" className="space-y-2 pt-2">
            <div className="grid grid-cols-2 gap-2">
              <label className="text-[10px] text-[#8B9BB8]">Width<NI v={res.w} on={(n) => setRes({ ...res, w: n })} t="res-width" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Height<NI v={res.h} on={(n) => setRes({ ...res, h: n })} t="res-height" /></label>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Out label="Aspect" value={`${rw}:${rh} (${res.h > 0 ? (res.w / res.h).toFixed(3) : "—"})`} testId="res-result-aspect" />
              <Out label="Pixels" value={fmtInt(res.w * res.h)} testId="res-result-pixels" />
              <Out label="Megapixels" value={fmtNum((res.w * res.h) / 1e6, 2)} testId="res-result-mp" />
            </div>
          </TabsContent>
          <TabsContent value="pitch" className="space-y-2 pt-2">
            <div className="grid grid-cols-3 gap-2">
              <label className="text-[10px] text-[#8B9BB8]">Pitch mm<NI v={pitch.pitch} step={0.01} on={(n) => setPitch({ ...pitch, pitch: n })} t="pitch-mm" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Wall W ft<NI v={pitch.wft} step={0.5} on={(n) => setPitch({ ...pitch, wft: n })} t="pitch-wall-w" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Wall H ft<NI v={pitch.hft} step={0.5} on={(n) => setPitch({ ...pitch, hft: n })} t="pitch-wall-h" /></label>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Out label="Approx resolution" value={pitch.pitch > 0 ? `${fmtInt(pitchW)}×${fmtInt(pitchH)}` : "—"} testId="pitch-result-res" />
              <Out label="px / m" value={pitch.pitch > 0 ? fmtInt(1000 / pitch.pitch) : "—"} testId="pitch-result-ppm" />
              <Out label="px / m²" value={pitch.pitch > 0 ? fmtInt((1000 / pitch.pitch) ** 2) : "—"} testId="pitch-result-ppm2" />
            </div>
          </TabsContent>
          <TabsContent value="cab" className="space-y-2 pt-2">
            <div className="grid grid-cols-3 gap-2">
              <label className="text-[10px] text-[#8B9BB8]">Wall W ft<NI v={cab.wallW} step={0.5} on={(n) => setCab({ ...cab, wallW: n })} t="cab-wall-w" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Wall H ft<NI v={cab.wallH} step={0.5} on={(n) => setCab({ ...cab, wallH: n })} t="cab-wall-h" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Cab W mm<NI v={cab.cabW} on={(n) => setCab({ ...cab, cabW: n })} t="cab-w" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Cab H mm<NI v={cab.cabH} on={(n) => setCab({ ...cab, cabH: n })} t="cab-h" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Res X<NI v={cab.rx} on={(n) => setCab({ ...cab, rx: n })} t="cab-rx" /></label>
              <label className="text-[10px] text-[#8B9BB8]">Res Y<NI v={cab.ry} on={(n) => setCab({ ...cab, ry: n })} t="cab-ry" /></label>
            </div>
            {wall.ok ? (
              <div className="grid grid-cols-3 gap-2">
                <Out label="Cabinets" value={`${wall.result.cabinets_x}×${wall.result.cabinets_y}=${wall.result.total_cabinets}`} testId="cab-result-count" />
                <Out label="Canvas" value={`${wall.result.canvas_w}×${wall.result.canvas_h}`} testId="cab-result-canvas" />
                <Out label="MP / pitch" value={`${wall.result.megapixels} · ${wall.result.pixel_pitch_mm}mm`} testId="cab-result-mp" />
              </div>
            ) : (
              <p className="rounded bg-[#2B0B14] p-2 text-[11px] text-[#FF5C7A]" data-testid="cab-result-error">{wall.error}</p>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export function NewProjectModal() {
  const open = useEditor((s) => s.presetsOpen);
  const [w, setW] = useState(1920);
  const [h, setH] = useState(1080);
  return (
    <Dialog open={open} onOpenChange={(o) => store.set({ presetsOpen: o })}>
      <DialogContent className="max-w-[680px] border-[#263249] bg-[#131926] sm:max-w-[680px]" data-testid="new-project-modal">
        <DialogHeader>
          <DialogTitle className="font-heading">New Project</DialogTitle>
          <DialogDescription className="text-[#8B9BB8]">Start from a show preset or a blank canvas. Your current project stays in autosave until replaced.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
          {SCENE_PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => {
                loadDoc(newFromScenePreset(p.id));
                store.set({ presetsOpen: false });
                toast.success(`New project: ${p.name}`);
              }}
              className="rounded border border-[#263249] bg-[#192131] p-2 text-left hover:border-[#00F0FF]/60"
              data-testid={`new-preset-${p.id}`}
            >
              <div className="text-xs font-semibold text-[#F5F8FF]">{p.name}</div>
              <div className="text-[10px] text-[#8B9BB8]">{p.desc}</div>
              <div className="mt-1 font-mono text-[9px] text-[#00F0FF]">{p.canvas.width}×{p.canvas.height} · {p.canvas.fps}fps</div>
            </button>
          ))}
        </div>
        <div className="flex items-end gap-2 border-t border-[#263249] pt-3">
          <label className="text-[10px] text-[#8B9BB8]">Width<Input type="number" value={w} onChange={(e) => setW(Number(e.target.value))} className="h-8 w-24 font-mono text-xs" data-testid="new-blank-width" /></label>
          <label className="text-[10px] text-[#8B9BB8]">Height<Input type="number" value={h} onChange={(e) => setH(Number(e.target.value))} className="h-8 w-24 font-mono text-xs" data-testid="new-blank-height" /></label>
          <Button
            onClick={() => {
              if (!(w >= 16 && h >= 16 && w <= 32768 && h <= 32768)) {
                toast.error("Canvas must be between 16 and 32768 px per side.");
                return;
              }
              const d = baseDoc("Untitled Show");
              d.canvas = { ...d.canvas, width: Math.round(w), height: Math.round(h) };
              loadDoc(d);
              store.set({ presetsOpen: false, activeInspector: "calc" });
              toast.success("Blank project created");
            }}
            data-testid="new-blank-btn"
          >
            Blank canvas
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
