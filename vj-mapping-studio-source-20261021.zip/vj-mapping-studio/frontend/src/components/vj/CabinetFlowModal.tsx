// Cabinet flow modal: per-screen cabinet table (number, col/row, pixel range,
// global XY, physical position), order algorithm switcher, visual patch preview.

import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { store, useEditor, patchScreen } from "@/lib/store";
import { ORDERS } from "@/lib/project";
import { buildCabinets, screenRes } from "@/lib/led";
import { downloadCsv } from "@/lib/exporters";
import type { LedScreen, ScreenOrder } from "@/lib/types";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

function FlowPreview({ s }: { s: LedScreen }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    const W = c.width;
    const H = c.height;
    const res = screenRes(s);
    const k = Math.min((W - 20) / res.w, (H - 20) / res.h);
    const ox = (W - res.w * k) / 2;
    const oy = (H - res.h * k) / 2;
    ctx.fillStyle = "#080A0E";
    ctx.fillRect(0, 0, W, H);
    const cabs = buildCabinets({ ...s, x: 0, y: 0, rotation: 0 });
    for (const cab of cabs) {
      ctx.fillStyle = "#121722";
      ctx.strokeStyle = "#212A3D";
      ctx.fillRect(ox + cab.x * k, oy + cab.y * k, cab.w * k, cab.h * k);
      ctx.strokeRect(ox + cab.x * k, oy + cab.y * k, cab.w * k, cab.h * k);
      if (cab.w * k > 16) {
        ctx.fillStyle = "#00F0FF";
        ctx.font = `bold ${Math.min(12, cab.w * k * 0.3)}px "JetBrains Mono Variable", monospace`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(String(cab.number), ox + (cab.x + cab.w / 2) * k, oy + (cab.y + cab.h / 2) * k);
      }
    }
    ctx.strokeStyle = "#FF0055";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    cabs.forEach((cab, i) => {
      const x = ox + (cab.x + cab.w / 2) * k;
      const y = oy + (cab.y + cab.h / 2) * k + Math.min(8, cab.h * k * 0.25);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();
    const c0 = cabs[0];
    if (c0) {
      ctx.fillStyle = "#00FFA3";
      ctx.beginPath();
      ctx.arc(ox + (c0.x + c0.w / 2) * k, oy + (c0.y + c0.h / 2) * k + Math.min(8, c0.h * k * 0.25), 4, 0, Math.PI * 2);
      ctx.fill();
    }
  }, [s]);
  return <canvas ref={ref} width={440} height={220} className="w-full rounded border border-[#212A3D]" data-testid="cabinet-flow-preview" />;
}

export default function CabinetFlowModal() {
  const open = useEditor((s) => s.cabinetOpen);
  const doc = useEditor((s) => s.doc);
  const selection = useEditor((s) => s.selection);
  const [screenId, setScreenId] = useState<string | null>(null);

  const s = doc.screens.find((x) => x.id === (screenId ?? selection.find((id) => doc.screens.some((sc) => sc.id === id)))) ?? doc.screens[0];
  const cabs = s ? buildCabinets(s) : [];
  const shown = cabs.slice(0, 500);

  return (
    <Dialog open={open} onOpenChange={(o) => store.set({ cabinetOpen: o })}>
      <DialogContent className="max-w-[860px] border-[#263249] bg-[#131926] sm:max-w-[860px]" data-testid="cabinet-flow-modal">
        <DialogHeader>
          <DialogTitle className="font-heading">Cabinet Flow & Data Patch</DialogTitle>
          <DialogDescription className="text-[#8B9BB8]">Cabinet numbering, pixel ranges and the signal chain order for the LED processor.</DialogDescription>
        </DialogHeader>
        {!s ? (
          <p className="py-6 text-center text-sm text-[#8B9BB8]">Add an LED screen first (Wall Calculator or the S tool).</p>
        ) : (
          <div className="grid grid-cols-[1fr_1.15fr] gap-3">
            <div className="space-y-2">
              <Select value={s.id} onValueChange={(v) => setScreenId(v)}>
                <SelectTrigger size="sm" className="w-full text-xs" data-testid="cabinet-flow-screen-select"><SelectValue>{s.name}</SelectValue></SelectTrigger>
                <SelectContent>{doc.screens.map((x) => <SelectItem key={x.id} value={x.id}>{x.name}</SelectItem>)}</SelectContent>
              </Select>
              <div className="grid grid-cols-2 gap-1">
                {ORDERS.map((o) => (
                  <button
                    key={o.id}
                    onClick={() => {
                      if (o.id === "custom") {
                        patchScreen(s.id, { customOrder: [], order: "custom" });
                        store.set({ customPatch: s.id, cabinetOpen: false, showBadges: true, showCable: true });
                        toast.message("Click every cabinet on the canvas in signal-chain order");
                        return;
                      }
                      patchScreen(s.id, { order: o.id as ScreenOrder });
                    }}
                    className={`rounded border px-2 py-1.5 text-left text-[10px] ${s.order === o.id ? "border-[#00F0FF] bg-[#00F0FF]/10 text-[#00F0FF]" : "border-[#263249] text-[#8B9BB8] hover:text-[#F5F8FF]"}`}
                    data-testid={`cabinet-order-${o.id}`}
                  >
                    {o.name}
                  </button>
                ))}
              </div>
              <FlowPreview s={s} />
              <div className="font-mono text-[10px] text-[#8B9BB8]">
                {s.cabsX}×{s.cabsY} = {cabs.length} cabinets · {s.cabResX}×{s.cabResY} px each · {s.cabW}×{s.cabH} mm
              </div>
              <div className="flex gap-1">
                <Button size="xs" variant="secondary" onClick={() => store.set((st) => ({ showBadges: true, showCable: !st.showCable }))} data-testid="cabinet-toggle-cable">Toggle cable overlay</Button>
                <Button size="xs" variant="secondary" onClick={() => store.set((st) => ({ showRanges: !st.showRanges, showBadges: true }))} data-testid="cabinet-toggle-ranges">Toggle pixel ranges</Button>
                <Button size="xs" variant="outline" onClick={() => downloadCsv(doc, true)} data-testid="cabinet-export-csv">Export CSV</Button>
              </div>
            </div>
            <div className="max-h-[420px] overflow-auto rounded border border-[#263249]">
              <Table data-testid="cabinet-table">
                <TableHeader>
                  <TableRow className="border-[#263249]">
                    {["#", "Col/Row", "Pixel X", "Pixel Y", "Global X,Y", "Phys mm"].map((h) => <TableHead key={h} className="h-7 text-[10px] text-[#8B9BB8]">{h}</TableHead>)}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shown.map((c) => (
                    <TableRow key={c.number} className="border-[#212A3D] font-mono text-[10px]" data-testid={`cabinet-row-${c.number}`}>
                      <TableCell className="py-1 text-[#00F0FF]">C{c.number}</TableCell>
                      <TableCell className="py-1">{c.col},{c.row}</TableCell>
                      <TableCell className="py-1">{c.pxX}–{c.pxX + s.cabResX - 1}</TableCell>
                      <TableCell className="py-1">{c.pxY}–{c.pxY + s.cabResY - 1}</TableCell>
                      <TableCell className="py-1">{c.globX},{c.globY}</TableCell>
                      <TableCell className="py-1">{c.physX},{c.physY}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {cabs.length > shown.length && <p className="p-2 text-[10px] text-[#8B9BB8]">Showing first 500 of {cabs.length} — full list in CSV export.</p>}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
