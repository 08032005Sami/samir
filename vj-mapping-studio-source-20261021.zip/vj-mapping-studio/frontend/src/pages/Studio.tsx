// Studio workstation shell: wires layout, global shortcuts, autosave, file I/O,
// drag & drop import and all dialogs.

import { useEffect, useRef } from "react";
import { toast } from "sonner";
import {
  store,
  useEditor,
  loadDoc,
  setTool,
  fitAll,
  setZoomPreset,
  undo,
  redo,
  copySelection,
  pasteClipboard,
  duplicateSelection,
  selectAll,
  deleteSelection,
  nudgeSelection,
  toggleLock,
  setDoc,
  tapTempo,
} from "@/lib/store";
import { attachShortcuts } from "@/lib/shortcuts";
import { autosaveDoc, downloadProject, loadAutosave, parseProject, mkShape, mkScreen } from "@/lib/project";
import { parseSvg } from "@/lib/exporters";
import TopMenuBar from "@/components/vj/TopMenuBar";
import LeftToolbar from "@/components/vj/LeftToolbar";
import CanvasViewport from "@/components/vj/CanvasViewport";
import InspectorDock from "@/components/vj/InspectorDock";
import BottomTimeline from "@/components/vj/BottomTimeline";
import StatusBar from "@/components/vj/StatusBar";
import ExportDialog from "@/components/vj/ExportDialog";
import CabinetFlowModal from "@/components/vj/CabinetFlowModal";
import TechReportModal from "@/components/vj/TechReportModal";
import { ShortcutsModal, PreviewModal, ToolsModal, NewProjectModal } from "@/components/vj/MiscDialogs";
import { Toaster } from "@/components/ui/sonner";
import { PanelRight, ImagePlus, X } from "lucide-react";

function importSvgText(text: string) {
  const { shapes, warnings } = parseSvg(text);
  if (!shapes.length) throw new Error("No supported shapes found in SVG (rect, circle, ellipse, polygon, polyline, line, path).");
  const made = shapes.map((p) => {
    const s = mkShape(p.kind ?? "freehand", Math.round(p.x ?? 0), Math.round(p.y ?? 0), Math.max(1, Math.round(p.w ?? 1)), Math.max(1, Math.round(p.h ?? 1)), "traveling_light", p.stroke && p.stroke !== "none" ? p.stroke : "#00F0FF", { name: p.name ?? "svg shape" });
    s.points = p.points ?? null;
    s.closed = p.closed ?? true;
    return s;
  });
  const st = store.get();
  setDoc({ ...st.doc, shapes: [...st.doc.shapes, ...made] });
  store.set({ selection: made.map((m) => m.id), activeInspector: "fx" });
  toast.success(`Imported ${made.length} SVG shape(s)${warnings.length ? ` · ${warnings.length} skipped` : ""}`);
}

function importCsvText(text: string) {
  // accepts our own CSV export (screen rows) or a simple "name,x,y,w,h" table
  const rows = text.split(/\r?\n/).map((l) => l.trim()).filter((l) => l && !l.startsWith("#"));
  const screens = [];
  for (const r of rows) {
    const c = r.split(",");
    if (c[0] === "screen" && c.length >= 7) {
      const w = Number(c[5]);
      const h = Number(c[6]);
      screens.push(mkScreen(c[1], Number(c[3]), Number(c[4]), Math.max(1, Math.round(w / 128)), Math.max(1, Math.round(h / 128))));
    } else if (c.length >= 5 && !isNaN(Number(c[1])) && c[0] !== "cabinet") {
      const w = Number(c[3]);
      const h = Number(c[4]);
      if (w > 0 && h > 0) screens.push(mkScreen(c[0], Number(c[1]), Number(c[2]), Math.max(1, Math.round(w / 128)), Math.max(1, Math.round(h / 128))));
    }
  }
  if (!screens.length) throw new Error("No screen rows found. Expected our CSV export or columns: name,x,y,width,height.");
  const st = store.get();
  setDoc({ ...st.doc, screens: [...st.doc.screens, ...screens] });
  toast.success(`Imported ${screens.length} screen(s) from CSV`);
}

async function handleFile(f: File) {
  const name = f.name.toLowerCase();
  try {
    if (name.endsWith(".vjmap") || name.endsWith(".json")) {
      const d = parseProject(await f.text());
      loadDoc(d);
      toast.success(`Opened ${d.name}`);
    } else if (name.endsWith(".svg")) {
      importSvgText(await f.text());
    } else if (name.endsWith(".csv")) {
      importCsvText(await f.text());
    } else if (/\.(png|jpe?g|webp)$/.test(name)) {
      const url = URL.createObjectURL(f);
      const img = new Image();
      img.onload = () => {
        store.set({ refImage: img, refOpacity: 0.5 });
        toast.success("Reference template loaded — adjust opacity in the top-left chip");
      };
      img.onerror = () => toast.error("Could not decode image.");
      img.src = url;
    } else {
      toast.error(`Unsupported file type: ${f.name}`);
    }
  } catch (e) {
    toast.error((e as Error).message || "Import failed — file is invalid or missing project data.");
  }
}

export default function Studio() {
  const openRef = useRef<HTMLInputElement | null>(null);
  const svgRef = useRef<HTMLInputElement | null>(null);
  const tplRef = useRef<HTMLInputElement | null>(null);
  const csvRef = useRef<HTMLInputElement | null>(null);
  const openRequest = useEditor((s) => s.openRequest);
  const importSvgRequest = useEditor((s) => s.importSvgRequest);
  const importTemplateRequest = useEditor((s) => s.importTemplateRequest);
  const importCsvRequest = useEditor((s) => s.importCsvRequest);
  const refImage = useEditor((s) => s.refImage);
  const refOpacity = useEditor((s) => s.refOpacity);

  // restore autosave once
  useEffect(() => {
    const saved = loadAutosave();
    if (saved && (saved.doc.screens.length || saved.doc.shapes.length)) {
      loadDoc(saved.doc);
      toast.message(`Restored autosave from ${new Date(saved.at).toLocaleTimeString()}`);
    }
  }, []);

  // autosave (debounced) + unload guard
  useEffect(() => {
    let timer = 0;
    let lastDoc = store.get().doc;
    const unsub = store.subscribe(() => {
      const d = store.get().doc;
      if (d === lastDoc) return;
      lastDoc = d;
      window.clearTimeout(timer);
      timer = window.setTimeout(() => autosaveDoc(d), 1500);
    });
    const beforeUnload = () => autosaveDoc(store.get().doc);
    window.addEventListener("beforeunload", beforeUnload);
    return () => {
      unsub();
      window.removeEventListener("beforeunload", beforeUnload);
    };
  }, []);

  // file dialogs requested from menus
  useEffect(() => void (openRequest && openRef.current?.click()), [openRequest]);
  useEffect(() => void (importSvgRequest && svgRef.current?.click()), [importSvgRequest]);
  useEffect(() => void (importTemplateRequest && tplRef.current?.click()), [importTemplateRequest]);
  useEffect(() => void (importCsvRequest && csvRef.current?.click()), [importCsvRequest]);

  // global shortcuts
  useEffect(
    () =>
      attachShortcuts({
        tool: (t) => setTool(t),
        fit: () => fitAll(),
        zoom100: () => setZoomPreset("100"),
        zoomInOut: (d) => setZoomPreset(Math.min(40, Math.max(0.02, store.get().view.zoom * (d > 0 ? 1.25 : 0.8)))),
        toggleGrid: () => store.set((s) => ({ showGrid: !s.showGrid, snapGrid: !s.showGrid })),
        play: () => store.set((s) => ({ playing: !s.playing })),
        toggleLock: () => store.get().selection.forEach((id) => toggleLock(id)),
        undo,
        redo,
        copy: copySelection,
        paste: pasteClipboard,
        duplicate: duplicateSelection,
        selectAll,
        deleteSel: deleteSelection,
        nudge: nudgeSelection,
        newProject: () => store.set({ presetsOpen: true }),
        open: () => openRef.current?.click(),
        save: () => (downloadProject(store.get().doc), store.set({ dirty: false }), toast.success("Project saved (.vjmap)")),
        exportDialog: () => store.set({ exportOpen: true }),
        cabinetFlow: () => store.set({ cabinetOpen: true }),
        shortcuts: () => store.set({ shortcutsOpen: true }),
        tap: () => void tapTempo(),
        esc: () => store.set({ selection: [], customPatch: null, editPoints: false, tool: "select" }),
      }),
    [],
  );

  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) void handleFile(f);
    e.target.value = "";
  };

  return (
    <div
      className="dark flex h-[100dvh] flex-col overflow-hidden bg-[#0B0D13] text-[#F0F4FC]"
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        const f = e.dataTransfer.files?.[0];
        if (f) void handleFile(f);
      }}
      data-testid="studio-root"
    >
      <TopMenuBar />
      <div className="flex min-h-0 flex-1">
        <LeftToolbar />
        <div className="relative flex min-w-0 flex-1 flex-col">
          <CanvasViewport />
          {/* reference template chip */}
          <div className="absolute left-8 top-8 z-20 flex items-center gap-2">
            {refImage ? (
              <div className="flex items-center gap-2 rounded border border-[#212A3D] bg-[#121722]/90 px-2 py-1 text-[10px] text-[#8A99B5] backdrop-blur" data-testid="ref-image-chip">
                TEMPLATE
                <input type="range" min={0.05} max={1} step={0.05} value={refOpacity} onChange={(e) => store.set({ refOpacity: Number(e.target.value) })} className="vj-range w-20" data-testid="ref-image-opacity" />
                <span className="w-7 font-mono text-[#00F0FF]">{Math.round(refOpacity * 100)}%</span>
                <button onClick={() => store.set({ refImage: null })} aria-label="Remove template" data-testid="ref-image-remove"><X className="size-3" /></button>
              </div>
            ) : (
              <button onClick={() => tplRef.current?.click()} className="flex items-center gap-1 rounded border border-[#212A3D] bg-[#121722]/80 px-2 py-1 text-[10px] text-[#8A99B5] backdrop-blur hover:text-[#F0F4FC]" data-testid="ref-image-import-btn">
                <ImagePlus className="size-3" /> Template PNG/JPG
              </button>
            )}
            <button onClick={() => csvRef.current?.click()} className="rounded border border-[#212A3D] bg-[#121722]/80 px-2 py-1 text-[10px] text-[#8A99B5] backdrop-blur hover:text-[#F0F4FC]" data-testid="csv-import-btn">
              Import CSV
            </button>
          </div>
          <button className="absolute right-3 top-8 z-20 rounded border border-[#212A3D] bg-[#121722] p-1.5 text-[#8A99B5] lg:hidden" onClick={() => store.set((s) => ({ inspectorOpen: !s.inspectorOpen }))} data-testid="inspector-toggle-btn" aria-label="Toggle inspector">
            <PanelRight className="size-4" />
          </button>
          <div className="h-[56px] shrink-0">
            <BottomTimeline />
          </div>
        </div>
        <InspectorDock />
      </div>
      <StatusBar />

      <input ref={openRef} type="file" accept=".vjmap,.json" hidden onChange={onPick} data-testid="file-open-input" />
      <input ref={svgRef} type="file" accept=".svg,image/svg+xml" hidden onChange={onPick} data-testid="file-svg-input" />
      <input ref={tplRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={onPick} data-testid="file-template-input" />
      <input ref={csvRef} type="file" accept=".csv,text/csv" hidden onChange={onPick} data-testid="file-csv-input" />

      <ExportDialog />
      <CabinetFlowModal />
      <TechReportModal />
      <ShortcutsModal />
      <PreviewModal />
      <ToolsModal />
      <NewProjectModal />
      <Toaster richColors theme="dark" />
    </div>
  );
}
