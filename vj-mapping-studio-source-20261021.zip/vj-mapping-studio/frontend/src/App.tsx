import { Routes, Route } from "react-router-dom";
import Studio from "@/pages/Studio";

// One <Route> per page in src/pages; BrowserRouter already wraps this in main.tsx.
export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Studio />} />
      <Route path="*" element={<Studio />} />
    </Routes>
  );
}
