// Shape geometry: path building, contour sampling, hit testing, transforms.

import type { LedScreen, Shape, Vec2 } from "./types";
import { clamp } from "./format";

export function rotatePt(p: Vec2, c: Vec2, deg: number): Vec2 {
  if (!deg) return p;
  const r = (deg * Math.PI) / 180;
  const cos = Math.cos(r);
  const sin = Math.sin(r);
  const dx = p.x - c.x;
  const dy = p.y - c.y;
  return { x: c.x + dx * cos - dy * sin, y: c.y + dy * cos + dx * sin };
}

function polygonVerts(n: number, cx: number, cy: number, rx: number, ry: number, rotDeg = -90): Vec2[] {
  const pts: Vec2[] = [];
  for (let i = 0; i < n; i++) {
    const a = ((rotDeg + (360 / n) * i) * Math.PI) / 180;
    pts.push({ x: cx + Math.cos(a) * rx, y: cy + Math.sin(a) * ry });
  }
  return pts;
}

/** Raw vertex list (absolute canvas coords, rotation NOT applied) per shape kind. */
export function shapeVerts(s: Shape): Vec2[] {
  const cx = s.x + s.w / 2;
  const cy = s.y + s.h / 2;
  switch (s.kind) {
    case "rect":
    case "rrect":
      return [
        { x: s.x, y: s.y },
        { x: s.x + s.w, y: s.y },
        { x: s.x + s.w, y: s.y + s.h },
        { x: s.x, y: s.y + s.h },
      ];
    case "triangle":
      return polygonVerts(3, cx, cy, s.w / 2, s.h / 2);
    case "diamond":
      return [
        { x: cx, y: s.y },
        { x: s.x + s.w, y: cy },
        { x: cx, y: s.y + s.h },
        { x: s.x, y: cy },
      ];
    case "hexagon":
      return polygonVerts(6, cx, cy, s.w / 2, s.h / 2);
    case "star": {
      const n = Math.max(5, Math.round(s.sides || 5));
      const outer = polygonVerts(n, cx, cy, s.w / 2, s.h / 2);
      const inner = polygonVerts(n, cx, cy, s.w / 4, s.h / 4, -90 + 180 / n);
      const pts: Vec2[] = [];
      for (let i = 0; i < n; i++) {
        pts.push(outer[i], inner[i]);
      }
      return pts;
    }
    case "polygon":
      return (s.points && s.points.length >= 3 ? s.points : polygonVerts(Math.max(3, s.sides || 6), cx, cy, s.w / 2, s.h / 2));
    case "line":
      return [
        { x: s.x, y: s.y },
        { x: s.x + s.w, y: s.y + s.h },
      ];
    case "bezier":
    case "freehand":
      return s.points && s.points.length >= 2 ? s.points : [
        { x: s.x, y: s.y },
        { x: s.x + s.w, y: s.y + s.h },
      ];
    default:
      return [];
  }
}

function smoothPath(path: Path2D, pts: Vec2[], closed: boolean): void {
  // Catmull-Rom-like quadratic smoothing through midpoints
  const p = pts;
  if (p.length < 3) {
    path.moveTo(p[0].x, p[0].y);
    path.lineTo(p[p.length - 1].x, p[p.length - 1].y);
    return;
  }
  path.moveTo(p[0].x, p[0].y);
  const last = closed ? p.length : p.length - 1;
  for (let i = 0; i < last; i++) {
    const cur = p[i];
    const next = p[(i + 1) % p.length];
    const mid = { x: (cur.x + next.x) / 2, y: (cur.y + next.y) / 2 };
    path.quadraticCurveTo(cur.x, cur.y, mid.x, mid.y);
  }
  if (closed) path.closePath();
  else path.lineTo(p[p.length - 1].x, p[p.length - 1].y);
}

/** Path2D in absolute canvas coords with the shape's rotation applied. */
export function shapePath(s: Shape): Path2D {
  const path = new Path2D();
  const c = { x: s.x + s.w / 2, y: s.y + s.h / 2 };
  if (s.kind === "circle" || s.kind === "ellipse") {
    path.ellipse(c.x, c.y, s.w / 2, s.h / 2, (s.rotation * Math.PI) / 180, 0, Math.PI * 2);
    return path;
  }
  if (s.kind === "rrect" && s.corner > 0) {
    const r = clamp(s.corner, 0, Math.min(s.w, s.h) / 2);
    path.roundRect(s.x, s.y, s.w, s.h, r);
    return path;
  }
  const verts = shapeVerts(s).map((p) => rotatePt(p, c, s.rotation));
  if (!verts.length) return path;
  if (s.kind === "freehand" || s.kind === "bezier") {
    smoothPath(path, verts, s.closed);
    return path;
  }
  path.moveTo(verts[0].x, verts[0].y);
  for (let i = 1; i < verts.length; i++) path.lineTo(verts[i].x, verts[i].y);
  if (s.closed && s.kind !== "line") path.closePath();
  return path;
}

export interface Contour {
  pts: Vec2[]; // sampled contour points (rotation applied)
  segs: Vec2[]; // segment start points aligned with pts (segs[i]→pts[i+1])
  perim: number;
  closed: boolean;
}

/** Dense contour sampling for the FX engine. segLen in world px. */
export function contour(s: Shape, segLen = 8): Contour {
  const c = { x: s.x + s.w / 2, y: s.y + s.h / 2 };
  const pts: Vec2[] = [];
  const push = (p: Vec2) => pts.push(rotatePt(p, c, s.rotation));

  if (s.kind === "circle" || s.kind === "ellipse") {
    const rx = s.w / 2;
    const ry = s.h / 2;
    const perim = Math.PI * (3 * (rx + ry) - Math.sqrt((3 * rx + ry) * (rx + 3 * ry)));
    const n = clamp(Math.round(perim / segLen), 24, 420);
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2;
      pts.push({ x: c.x + Math.cos(a) * rx, y: c.y + Math.sin(a) * ry });
    }
    const rotated = pts.map((p) => rotatePt(p, c, s.rotation));
    return finalize(rotated, perim, true);
  }

  if (s.kind === "freehand" || s.kind === "bezier") {
    // dense-smooth the polyline first
    const raw = shapeVerts(s);
    const dense: Vec2[] = [];
    for (let i = 0; i < raw.length - 1; i++) {
      const a = raw[i];
      const b = raw[i + 1];
      const len = Math.hypot(b.x - a.x, b.y - a.y);
      const n = clamp(Math.round(len / (segLen / 2)), 1, 24);
      for (let k = 0; k < n; k++) dense.push({ x: a.x + ((b.x - a.x) * k) / n, y: a.y + ((b.y - a.y) * k) / n });
    }
    dense.push(raw[raw.length - 1]);
    let perim = 0;
    for (let i = 0; i < dense.length - 1; i++) perim += Math.hypot(dense[i + 1].x - dense[i].x, dense[i + 1].y - dense[i].y);
    return finalize(dense, perim, s.closed);
  }

  const verts = shapeVerts(s).map((p) => rotatePt(p, c, s.rotation));
  const closedLoop = s.closed && s.kind !== "line";
  const loop = closedLoop ? [...verts, verts[0]] : verts;
  let perim = 0;
  const out: Vec2[] = [];
  for (let i = 0; i < loop.length - 1; i++) {
    const a = loop[i];
    const b = loop[i + 1];
    const len = Math.hypot(b.x - a.x, b.y - a.y);
    const n = clamp(Math.round(len / segLen), 1, 60);
    for (let k = 0; k < n; k++) out.push({ x: a.x + ((b.x - a.x) * k) / n, y: a.y + ((b.y - a.y) * k) / n });
    perim += len;
  }
  return finalize(out, perim, closedLoop);
}

function finalize(pts: Vec2[], perim: number, closed: boolean): Contour {
  const segs = pts.map((p) => ({ x: p.x, y: p.y }));
  return { pts, segs, perim: Math.max(perim, 1), closed };
}

// ---------------------------------------------------------------- hit testing

export function shapeBBox(s: Shape): { x: number; y: number; w: number; h: number } {
  const c = { x: s.x + s.w / 2, y: s.y + s.h / 2 };
  const verts = shapeVerts(s).map((p) => rotatePt(p, c, s.rotation));
  if (!verts.length) return { x: s.x, y: s.y, w: s.w, h: s.h };
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const v of verts) {
    x0 = Math.min(x0, v.x);
    y0 = Math.min(y0, v.y);
    x1 = Math.max(x1, v.x);
    y1 = Math.max(y1, v.y);
  }
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

let hitCtx: CanvasRenderingContext2D | null = null;
function getHitCtx(): CanvasRenderingContext2D {
  if (!hitCtx) {
    const cv = document.createElement("canvas");
    cv.width = 1;
    cv.height = 1;
    hitCtx = cv.getContext("2d")!;
  }
  return hitCtx;
}

export function hitShape(s: Shape, p: Vec2, tolPx: number): boolean {
  const ctx = getHitCtx();
  const path = shapePath(s);
  const filled = s.fill !== null;
  if (filled && ctx.isPointInPath(path, p.x, p.y)) return true;
  ctx.lineWidth = Math.max(s.strokeWidth, tolPx * 2) + tolPx;
  return ctx.isPointInStroke(path, p.x, p.y);
}

export function screenCorners(s: LedScreen): Vec2[] {
  const w = s.cabsX * s.cabResX;
  const h = s.cabsY * s.cabResY;
  const c = { x: s.x + w / 2, y: s.y + h / 2 };
  return [
    { x: s.x, y: s.y },
    { x: s.x + w, y: s.y },
    { x: s.x + w, y: s.y + h },
    { x: s.x, y: s.y + h },
  ].map((p) => rotatePt(p, c, s.rotation));
}

export function ptInScreen(s: LedScreen, p: Vec2): boolean {
  const w = s.cabsX * s.cabResX;
  const h = s.cabsY * s.cabResY;
  const c = { x: s.x + w / 2, y: s.y + h / 2 };
  const q = rotatePt(p, c, -s.rotation);
  return q.x >= s.x && q.x <= s.x + w && q.y >= s.y && q.y <= s.y + h;
}

export function stageBBox(o: { x: number; y: number; w: number; h: number; rotation: number }): { x: number; y: number; w: number; h: number } {
  const c = { x: o.x + o.w / 2, y: o.y + o.h / 2 };
  const corners = [
    { x: o.x, y: o.y },
    { x: o.x + o.w, y: o.y },
    { x: o.x + o.w, y: o.y + o.h },
    { x: o.x, y: o.y + o.h },
  ].map((p) => rotatePt(p, c, o.rotation));
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const v of corners) {
    x0 = Math.min(x0, v.x);
    y0 = Math.min(y0, v.y);
    x1 = Math.max(x1, v.x);
    y1 = Math.max(y1, v.y);
  }
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}
