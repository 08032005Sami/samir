// Global keyboard shortcut layer — professional editor bindings.

import type { EditorState } from "./store";

export interface ShortcutSpec {
  keys: string; // display, e.g. "Ctrl+Z"
  action: string; // id
  label: string;
  group: string;
}

export const SHORTCUTS: ShortcutSpec[] = [
  { keys: "V", action: "tool.select", label: "Select & Transform", group: "Tools" },
  { keys: "H", action: "tool.hand", label: "Hand / Pan", group: "Tools" },
  { keys: "S", action: "tool.screen", label: "Add LED Screen", group: "Tools" },
  { keys: "R", action: "tool.rect", label: "Rectangle Contour", group: "Tools" },
  { keys: "C", action: "tool.circle", label: "Circle Contour", group: "Tools" },
  { keys: "T", action: "tool.triangle", label: "Triangle Contour", group: "Tools" },
  { keys: "D", action: "tool.diamond", label: "Diamond Contour", group: "Tools" },
  { keys: "X", action: "tool.hexagon", label: "Hexagon Contour", group: "Tools" },
  { keys: "P", action: "tool.pen", label: "Pen / Bezier Path", group: "Tools" },
  { keys: "F", action: "fit", label: "Fit Canvas to View", group: "View" },
  { keys: "Ctrl+0", action: "fit", label: "Fit Canvas to View", group: "View" },
  { keys: "Ctrl+1", action: "zoom100", label: "Zoom 100% (1:1)", group: "View" },
  { keys: "+ / -", action: "zoom.in.out", label: "Zoom In / Out", group: "View" },
  { keys: "G", action: "toggle.grid", label: "Toggle Grid & Snapping", group: "View" },
  { keys: "Space", action: "play", label: "Play / Pause (hold + drag = pan)", group: "Playback" },
  { keys: "L", action: "toggle.lock", label: "Lock / Unlock Selection", group: "Edit" },
  { keys: "Ctrl+Z", action: "undo", label: "Undo", group: "Edit" },
  { keys: "Ctrl+Shift+Z", action: "redo", label: "Redo", group: "Edit" },
  { keys: "Ctrl+Y", action: "redo", label: "Redo", group: "Edit" },
  { keys: "Ctrl+C", action: "copy", label: "Copy", group: "Edit" },
  { keys: "Ctrl+V", action: "paste", label: "Paste", group: "Edit" },
  { keys: "Ctrl+D", action: "duplicate", label: "Duplicate", group: "Edit" },
  { keys: "Ctrl+A", action: "select.all", label: "Select All", group: "Edit" },
  { keys: "Delete", action: "delete", label: "Delete Selection", group: "Edit" },
  { keys: "Arrows", action: "nudge", label: "Nudge (Shift = ×10)", group: "Edit" },
  { keys: "Ctrl+N", action: "new", label: "New Project (presets)", group: "File" },
  { keys: "Ctrl+O", action: "open", label: "Open .vjmap…", group: "File" },
  { keys: "Ctrl+S", action: "save", label: "Save .vjmap", group: "File" },
  { keys: "Ctrl+E", action: "export", label: "Export…", group: "File" },
  { keys: "M", action: "cabinet.flow", label: "Cabinet Flow & Patch", group: "Project" },
  { keys: "B", action: "bpm.tap", label: "Tap Tempo (BPM)", group: "Playback" },
  { keys: "?", action: "shortcuts", label: "Keyboard Shortcuts", group: "Help" },
  { keys: "Esc", action: "esc", label: "Cancel / Deselect", group: "Help" },
];

export interface ShortcutActions {
  tool: (t: EditorState["tool"]) => void;
  fit: () => void;
  zoom100: () => void;
  zoomInOut: (dir: 1 | -1) => void;
  toggleGrid: () => void;
  play: () => void;
  toggleLock: () => void;
  undo: () => void;
  redo: () => void;
  copy: () => void;
  paste: () => void;
  duplicate: () => void;
  selectAll: () => void;
  deleteSel: () => void;
  nudge: (dx: number, dy: number) => void;
  newProject: () => void;
  open: () => void;
  save: () => void;
  exportDialog: () => void;
  cabinetFlow: () => void;
  shortcuts: () => void;
  tap: () => void;
  esc: () => void;
}

// ------------------------------------------------------------- remappable single keys

export const REMAPPABLE: { action: string; label: string; def: string }[] = [
  { action: "tool.select", label: "Select & Transform", def: "v" },
  { action: "tool.hand", label: "Hand / Pan", def: "h" },
  { action: "tool.screen", label: "Add LED Screen", def: "s" },
  { action: "tool.rect", label: "Rectangle", def: "r" },
  { action: "tool.circle", label: "Circle", def: "c" },
  { action: "tool.triangle", label: "Triangle", def: "t" },
  { action: "tool.diamond", label: "Diamond", def: "d" },
  { action: "tool.hexagon", label: "Hexagon", def: "x" },
  { action: "tool.pen", label: "Pen / Bezier", def: "p" },
  { action: "fit", label: "Fit to View", def: "f" },
  { action: "toggle.grid", label: "Toggle Grid", def: "g" },
  { action: "toggle.lock", label: "Lock / Unlock", def: "l" },
  { action: "cabinet.flow", label: "Cabinet Flow", def: "m" },
  { action: "bpm.tap", label: "Tap Tempo", def: "b" },
  { action: "shortcuts", label: "Shortcuts Panel", def: "?" },
];

const KEYMAP_KEY = "vjmap.keymap.v1";

export function getKeyMap(): Record<string, string> {
  const base = Object.fromEntries(REMAPPABLE.map((r) => [r.action, r.def]));
  try {
    return { ...base, ...(JSON.parse(localStorage.getItem(KEYMAP_KEY) ?? "{}") as Record<string, string>) };
  } catch {
    return base;
  }
}

/** Assign a key; returns the action that previously owned it (now swapped), if any. */
export function setKeyBinding(action: string, key: string): string | null {
  const k = key.toLowerCase();
  const map = getKeyMap();
  const clash = Object.keys(map).find((a) => a !== action && map[a] === k) ?? null;
  if (clash) map[clash] = map[action];
  map[action] = k;
  localStorage.setItem(KEYMAP_KEY, JSON.stringify(map));
  return clash;
}

export function resetKeyMap(): void {
  localStorage.removeItem(KEYMAP_KEY);
}

function matches(e: KeyboardEvent, action: string): boolean {
  if (e.ctrlKey || e.metaKey || e.altKey) return false;
  const want = getKeyMap()[action];
  if (!want) return false;
  const k = e.key.toLowerCase();
  return k === want || (want === "?" && e.shiftKey && k === "/");
}

/** Attach the global keydown handler. Returns a detach function. */
export function attachShortcuts(actions: ShortcutActions): () => void {
  const handler = (e: KeyboardEvent) => {
    const target = e.target as HTMLElement | null;
    if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT" || target.isContentEditable)) {
      return; // never hijack typing
    }
    const mod = e.ctrlKey || e.metaKey;

    // --- modifier combos first
    if (mod) {
      switch (e.key.toLowerCase()) {
        case "z":
          e.preventDefault();
          if (e.shiftKey) actions.redo();
          else actions.undo();
          return;
        case "y":
          e.preventDefault();
          actions.redo();
          return;
        case "c":
          e.preventDefault();
          actions.copy();
          return;
        case "v":
          e.preventDefault();
          actions.paste();
          return;
        case "d":
          e.preventDefault();
          actions.duplicate();
          return;
        case "a":
          e.preventDefault();
          actions.selectAll();
          return;
        case "s":
          e.preventDefault();
          actions.save();
          return;
        case "o":
          e.preventDefault();
          actions.open();
          return;
        case "n":
          e.preventDefault();
          actions.newProject();
          return;
        case "e":
          e.preventDefault();
          actions.exportDialog();
          return;
        case "0":
          e.preventDefault();
          actions.fit();
          return;
        case "1":
          e.preventDefault();
          actions.zoom100();
          return;
        case "=":
        case "+":
          e.preventDefault();
          actions.zoomInOut(1);
          return;
        case "-":
          e.preventDefault();
          actions.zoomInOut(-1);
          return;
      }
      return;
    }

    // --- plain keys
    if (matches(e, "tool.select")) return (e.preventDefault(), actions.tool("select"));
    if (matches(e, "tool.hand")) return (e.preventDefault(), actions.tool("hand"));
    if (matches(e, "tool.screen")) return (e.preventDefault(), actions.tool("screen"));
    if (matches(e, "tool.rect")) return (e.preventDefault(), actions.tool("rect"));
    if (matches(e, "tool.circle")) return (e.preventDefault(), actions.tool("circle"));
    if (matches(e, "tool.triangle")) return (e.preventDefault(), actions.tool("triangle"));
    if (matches(e, "tool.diamond")) return (e.preventDefault(), actions.tool("diamond"));
    if (matches(e, "tool.hexagon")) return (e.preventDefault(), actions.tool("hexagon"));
    if (matches(e, "tool.pen")) return (e.preventDefault(), actions.tool("pen"));
    if (matches(e, "fit")) return (e.preventDefault(), actions.fit());
    if (matches(e, "toggle.grid")) return (e.preventDefault(), actions.toggleGrid());
    if (matches(e, "toggle.lock")) return (e.preventDefault(), actions.toggleLock());
    if (matches(e, "cabinet.flow")) return (e.preventDefault(), actions.cabinetFlow());
    if (matches(e, "shortcuts")) return (e.preventDefault(), actions.shortcuts());
    if (matches(e, "bpm.tap")) return (e.preventDefault(), actions.tap());

    // NOTE: Space is intentionally NOT handled here — CanvasViewport implements
    // hold-Space-to-pan vs tap-Space-to-play and needs both keydown and keyup.
    if (e.key === "Delete" || e.key === "Backspace") {
      e.preventDefault();
      actions.deleteSel();
      return;
    }
    if (e.key === "Escape") {
      actions.esc();
      return;
    }
    if (e.key === "+" || e.key === "=") return actions.zoomInOut(1);
    if (e.key === "-") return actions.zoomInOut(-1);

    const arrows: Record<string, [number, number]> = {
      ArrowLeft: [-1, 0],
      ArrowRight: [1, 0],
      ArrowUp: [0, -1],
      ArrowDown: [0, 1],
    };
    if (arrows[e.key]) {
      e.preventDefault();
      const [dx, dy] = arrows[e.key];
      const mult = e.shiftKey ? 10 : 1;
      actions.nudge(dx * mult, dy * mult);
    }
  };
  window.addEventListener("keydown", handler);
  return () => window.removeEventListener("keydown", handler);
}
