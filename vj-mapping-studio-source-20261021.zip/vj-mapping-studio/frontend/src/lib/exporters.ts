// Export suite: PNG (map/content), PNG sequence ZIP with progress + cancel,
// SVG vector, CSV coordinate map, Resolume input-map PNG, SVG import.

import type { LedScreen, ProjectDoc, Vec2 } from "./types";
import { renderFrame } from "./engine";
import type { FrameMode } from "./engine";
import { makeZip } from "./zip";
import { downloadBlob, safeFileName } from "./format";
import { buildCabinets, screenRes, toScreenSummary } from "./led";

async function renderToBlob(doc: ProjectDoc, W: number, H: number, t: number, mode: FrameMode, transparent: boolean): Promise<Blob> {
  const cv = document.createElement("canvas");
  cv.width = W;
  cv.height = H;
  const ctx = cv.getContext("2d")!;
  renderFrame(ctx, doc, W, H, t, mode, false);
  void transparent;
  return new Promise((res, rej) => cv.toBlob((b) => (b ? res(b) : rej(new Error("PNG encode failed"))), "image/png"));
}

export async function exportPng(doc: ProjectDoc, mode: FrameMode, W: number, H: number): Promise<void> {
  const blob = await renderToBlob(doc, W, H, 0, mode, mode === "content");
  const suffix = mode === "content" ? "content" : mode === "inputmap" ? "input_map" : "map";
  downloadBlob(blob, `${safeFileName(doc.name)}_${suffix}_${W}x${H}.png`);
}

export interface SeqOpts {
  frameW: number;
  frameH: number;
  fps: number;
  duration: number;
  transparent: boolean;
  exactLoop: boolean;
}

export interface SeqResult {
  frames: number;
  bytes: number;
  cancelled: boolean;
}

/** Render + ZIP a PNG sequence entirely client-side. onProgress gets 0..1 + estimate. */
export async function exportPngSequence(
  doc: ProjectDoc,
  o: SeqOpts,
  onProgress: (frame: number, frames: number, estBytes: number | null) => void,
  shouldCancel: () => boolean,
): Promise<SeqResult> {
  const frames = Math.max(1, Math.round(o.duration * o.fps));
  const folder = `${safeFileName(doc.name)}_border_${o.fps}fps`;
  const entries: { name: string; data: Uint8Array }[] = [];
  let estBytes: number | null = null;

  // Exact loop: snap every shape's speed so phase(n) === phase(0)
  const renderDoc: ProjectDoc = o.exactLoop ? loopSnappedDoc(doc, o.duration) : doc;

  for (let f = 0; f < frames; f++) {
    if (shouldCancel()) {
      return { frames: f, bytes: estBytes ?? 0, cancelled: true };
    }
    const t = f / o.fps;
    const blob = await renderToBlob(renderDoc, o.frameW, o.frameH, t, o.transparent ? "content" : "map", o.transparent);
    const buf = new Uint8Array(await blob.arrayBuffer());
    if (estBytes === null) estBytes = buf.length * frames;
    entries.push({ name: `${folder}/frame_${String(f + 1).padStart(4, "0")}.png`, data: buf });
    onProgress(f + 1, frames, estBytes);
    // yield to the UI every few frames
    if (f % 3 === 0) await new Promise((r) => setTimeout(r, 0));
  }

  entries.push({ name: "HOW_TO_USE_IN_RESOLUME.txt", data: new TextEncoder().encode(SEQ_README(folder, o, frames)) });
  const zip = makeZip(entries);
  downloadBlob(zip, `${safeFileName(doc.name)}_${o.frameW}x${o.frameH}_${o.fps}fps_${frames}f.zip`);
  return { frames, bytes: zip.size, cancelled: false };
}

// ------------------------------------------------------------------ SVG

function pathDFromShape(s: ProjectDoc["shapes"][number]): string {
  // static outline (effects are animated raster — SVG carries geometry + color)
  const pts = contourPtsForSvg(s);
  if (!pts.length) return "";
  if (s.kind === "circle" || s.kind === "ellipse") {
    const cx = s.x + s.w / 2;
    const cy = s.y + s.h / 2;
    return `M ${cx - s.w / 2} ${cy} A ${s.w / 2} ${s.h / 2} 0 1 0 ${cx + s.w / 2} ${cy} A ${s.w / 2} ${s.h / 2} 0 1 0 ${cx - s.w / 2} ${cy} Z`;
  }
  return pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ") + (s.closed ? " Z" : "");
}

function contourPtsForSvg(s: ProjectDoc["shapes"][number]): Vec2[] {
  // reuse engine contour but avoid circular import: re-derive via shapePath is Path2D (not serializable),
  // so use the analytic vertices from geometry through a tiny local import-free path
  // (contour() is imported below from geometry — shared code, no cycle).
  return contourPts(s);
}

import { contour as contourFull } from "./geometry";
function contourPts(s: ProjectDoc["shapes"][number]): Vec2[] {
  return contourFull(s, 12).pts;
}

export function exportSvg(doc: ProjectDoc, includeScreens: boolean): void {
  const parts: string[] = [];
  parts.push(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${doc.canvas.width}" height="${doc.canvas.height}" viewBox="0 0 ${doc.canvas.width} ${doc.canvas.height}">`,
  );
  parts.push(`<rect width="100%" height="100%" fill="${doc.canvas.background === "transparent" ? "none" : doc.canvas.background}"/>`);
  if (includeScreens) {
    for (const s of doc.screens) {
      const r = screenRes(s);
      parts.push(
        `<g transform="rotate(${s.rotation} ${s.x + r.w / 2} ${s.y + r.h / 2})">` +
          `<rect x="${s.x}" y="${s.y}" width="${r.w}" height="${r.h}" fill="none" stroke="${s.color}" stroke-width="3"/>` +
          `<text x="${s.x + 8}" y="${s.y + 28}" fill="${s.color}" font-family="monospace" font-size="22">${s.name} — ${r.w}×${r.h}px</text>` +
          `</g>`,
      );
    }
  }
  for (const s of doc.shapes) {
    if (!s.visible) continue;
    const d = pathDFromShape(s);
    if (!d) continue;
    parts.push(
      `<path d="${d}" fill="${s.fill ?? "none"}" fill-opacity="${s.fillOpacity}" stroke="${s.fx.enabled ? s.fx.color : s.stroke}" stroke-width="${s.strokeWidth}" stroke-linejoin="round" stroke-linecap="round"/>`,
    );
  }
  parts.push("</svg>");
  downloadBlob(new Blob([parts.join("\n")], { type: "image/svg+xml" }), `${safeFileName(doc.name)}.svg`);
}

// ------------------------------------------------------------------ CSV

export function csvClient(doc: ProjectDoc, includeCabinets: boolean): { filename: string; csv: string } {
  const lines = [
    "# VJ Mapping Studio — coordinate / cabinet patch map",
    `# project,${doc.name}`,
    "# kind,name,cab,x,y,w,h,phys_x_mm,phys_y_mm,phys_w_mm,phys_h_mm,px_x,px_y,px_w,px_h,order",
  ];
  for (const s of doc.screens) {
    const sum = toScreenSummary(s);
    lines.push(`screen,${sum.name},,${sum.x},${sum.y},${sum.width},${sum.height},0,0,${sum.phys_w_mm},${sum.phys_h_mm},0,0,${sum.width},${sum.height},${sum.order}`);
    if (!includeCabinets) continue;
    const res = screenRes(s);
    const cabWpx = res.w / s.cabsX;
    const cabHpx = res.h / s.cabsY;
    for (const cab of buildCabinets(s)) {
      lines.push(
        `cabinet,${s.name},${cab.number},${cab.x.toFixed(0)},${cab.y.toFixed(0)},${cabWpx.toFixed(0)},${cabHpx.toFixed(0)},` +
          `${cab.physX},${cab.physY},${s.cabW},${s.cabH},${cab.pxX},${cab.pxY},${s.cabResX},${s.cabResY},${s.order}`,
      );
    }
  }
  return { filename: `${safeFileName(doc.name)}_map.csv`, csv: lines.join("\n") + "\n" };
}

export function downloadCsv(doc: ProjectDoc, includeCabinets: boolean): void {
  const { filename, csv } = csvClient(doc, includeCabinets);
  downloadBlob(new Blob([csv], { type: "text/csv" }), filename);
}

// ------------------------------------------------------------------ SVG import

interface SvgParseResult {
  shapes: Partial<ProjectDoc["shapes"][number]>[];
  warnings: string[];
}

/** Parse a simple SVG (rect, circle, ellipse, polygon, polyline, line, path M/L/H/V/C/S/Q/Z) into shapes. */
export function parseSvg(text: string): SvgParseResult {
  const warnings: string[] = [];
  const doc = new DOMParser().parseFromString(text, "image/svg+xml");
  if (doc.querySelector("parsererror")) throw new Error("Invalid SVG file.");
  const svgs = doc.querySelectorAll("svg");
  if (!svgs.length) throw new Error("No <svg> root element found.");
  const svg = svgs[0];
  const vb = svg.getAttribute("viewBox");
  let [vx, vy, vw, vh] = [0, 0, 0, 0];
  if (vb) {
    const p = vb.split(/[\s,]+/).map(Number);
    [vx, vy, vw, vh] = p;
  } else {
    vw = Number(svg.getAttribute("width") ?? 1920) || 1920;
    vh = Number(svg.getAttribute("height") ?? 1080) || 1080;
  }
  // scale to fit 1920 wide canvas
  const k = vw > 0 ? 1920 / vw : 1;
  const shapes: Partial<ProjectDoc["shapes"][number]>[] = [];

  const push = (kind: ProjectDoc["shapes"][number]["kind"], x: number, y: number, w: number, h: number, stroke: string, closed: boolean, points?: Vec2[]) => {
    shapes.push({ kind, x: (x - vx) * k, y: (y - vy) * k, w: w * k, h: h * k, stroke, closed, points: points ?? null, name: `${kind} (svg)` });
  };

  svg.querySelectorAll("rect").forEach((el) => {
    push("rect", Number(el.getAttribute("x") ?? 0), Number(el.getAttribute("y") ?? 0), Number(el.getAttribute("width") ?? 0), Number(el.getAttribute("height") ?? 0), el.getAttribute("stroke") ?? "#00F0FF", true);
  });
  svg.querySelectorAll("circle").forEach((el) => {
    const r = Number(el.getAttribute("r") ?? 0);
    push("circle", Number(el.getAttribute("cx") ?? 0) - r, Number(el.getAttribute("cy") ?? 0) - r, r * 2, r * 2, el.getAttribute("stroke") ?? "#00F0FF", true);
  });
  svg.querySelectorAll("ellipse").forEach((el) => {
    const rx = Number(el.getAttribute("rx") ?? 0);
    const ry = Number(el.getAttribute("ry") ?? 0);
    push("ellipse", Number(el.getAttribute("cx") ?? 0) - rx, Number(el.getAttribute("cy") ?? 0) - ry, rx * 2, ry * 2, el.getAttribute("stroke") ?? "#00F0FF", true);
  });
  svg.querySelectorAll("polygon, polyline").forEach((el) => {
    const ptsAttr = el.getAttribute("points") ?? "";
    const nums = ptsAttr.split(/[\s,]+/).filter(Boolean).map(Number);
    const pts: Vec2[] = [];
    for (let i = 0; i + 1 < nums.length; i += 2) pts.push({ x: (nums[i] - vx) * k, y: (nums[i + 1] - vy) * k });
    if (pts.length >= 2) {
      const xs = pts.map((p) => p.x);
      const ys = pts.map((p) => p.y);
      const x0 = Math.min(...xs);
      const y0 = Math.min(...ys);
      const x1 = Math.max(...xs);
      const y1 = Math.max(...ys);
      shapes.push({ kind: el.tagName.toLowerCase() === "polygon" ? "polygon" : "freehand", x: x0, y: y0, w: x1 - x0, h: y1 - y0, stroke: el.getAttribute("stroke") ?? "#00F0FF", closed: el.tagName.toLowerCase() === "polygon", points: pts, name: "polygon (svg)" });
    }
  });
  svg.querySelectorAll("line").forEach((el) => {
    const x1 = Number(el.getAttribute("x1") ?? 0);
    const y1 = Number(el.getAttribute("y1") ?? 0);
    const x2 = Number(el.getAttribute("x2") ?? 0);
    const y2 = Number(el.getAttribute("y2") ?? 0);
    push("line", Math.min(x1, x2) - vx, Math.min(y1, y2) - vy, Math.abs(x2 - x1), Math.abs(y2 - y1), el.getAttribute("stroke") ?? "#00F0FF", false, [
      { x: (x1 - vx) * k, y: (y1 - vy) * k },
      { x: (x2 - vx) * k, y: (y2 - vy) * k },
    ]);
  });
  svg.querySelectorAll("path").forEach((el) => {
    const d = el.getAttribute("d") ?? "";
    const pts = samplePathD(d);
    if (!pts.length) {
      warnings.push("Skipped a <path> with unsupported commands.");
      return;
    }
    const xs = pts.map((p) => p.x);
    const ys = pts.map((p) => p.y);
    const x0 = Math.min(...xs);
    const y0 = Math.min(...ys);
    const x1 = Math.max(...xs);
    const y1 = Math.max(...ys);
    shapes.push({
      kind: "freehand",
      x: x0,
      y: y0,
      w: x1 - x0,
      h: y1 - y0,
      stroke: el.getAttribute("stroke") ?? "#00F0FF",
      closed: /z\s*$/i.test(d),
      points: pts,
      name: "path (svg)",
    });
  });

  const scaled = shapes.map((s) => ({ ...s, x: s.x ?? 0, y: s.y ?? 0, w: s.w ?? 0, h: s.h ?? 0 }));
  return { shapes: scaled, warnings };
}

/** Sample an SVG path d string (M/L/H/V/C/S/Q/Z, absolute + relative) into points. */
function samplePathD(d: string): Vec2[] {
  const tokens = d.match(/[a-zA-Z]|-?\d*\.?\d+(?:e[-+]?\d+)?/gi) ?? [];
  const pts: Vec2[] = [];
  let i = 0;
  let cmd = "";
  let cx = 0;
  let cy = 0;
  let sx = 0;
  let sy = 0;
  const num = () => Number(tokens[i++]);
  const add = (x: number, y: number) => {
    pts.push({ x, y });
    cx = x;
    cy = y;
  };
  while (i < tokens.length) {
    const t = tokens[i];
    if (/[a-zA-Z]/.test(t)) {
      cmd = tokens[i++];
      if (cmd === "Z" || cmd === "z") continue;
    }
    const rel = cmd === cmd.toLowerCase();
    const C = cmd.toUpperCase();
    switch (C) {
      case "M":
      case "L": {
        let x = num();
        let y = num();
        if (rel) {
          x += cx;
          y += cy;
        }
        add(x, y);
        if (C === "M") {
          sx = x;
          sy = y;
          cmd = rel ? "l" : "L";
        }
        break;
      }
      case "H": {
        let x = num();
        if (rel) x += cx;
        add(x, cy);
        break;
      }
      case "V": {
        let y = num();
        if (rel) y += cy;
        add(cx, y);
        break;
      }
      case "C":
      case "S":
      case "Q": {
        const count = C === "Q" ? 2 : C === "S" ? 2 : 3;
        const args: number[] = [];
        for (let k = 0; k < count * 2; k++) args.push(num());
        for (let k = 0; k < args.length; k += 2) if (rel) args[k] += cx, (args[k + 1] += cy);
        const x = args[args.length - 2];
        const y = args[args.length - 1];
        // sub-sample the cubic/quad roughly
        for (let k = 1; k <= 8; k++) {
          const tt = k / 8;
          pts.push({ x: cx + (x - cx) * tt, y: cy + (y - cy) * tt });
        }
        cx = x;
        cy = y;
        break;
      }
      case "Z":
      case "z":
        add(sx, sy);
        i++;
        break;
      default:
        i++;
    }
  }
  return pts;
}

export function importSvgShapes(text: string, fxType: string): number {
  const { shapes, warnings } = parseSvg(text);
  void warnings;
  // dynamic import avoided — direct use of store would create a cycle; caller wires results
  return shapes.length;
}

export type { LedScreen };

// ------------------------------------------------------------------ video (Resolume-ready)

export interface VideoOpts {
  frameW: number;
  frameH: number;
  fps: number;
  duration: number;
  exactLoop: boolean;
  includeScreens: boolean; // false = border FX only on pure black (use Add/Screen blend in Resolume)
}

export function videoMime(): { mime: string; ext: "mp4" | "webm" } | null {
  if (typeof MediaRecorder === "undefined") return null;
  const cands: [string, "mp4" | "webm"][] = [
    ["video/mp4;codecs=avc1.640028", "mp4"],
    ["video/mp4;codecs=avc1.42E01E", "mp4"],
    ["video/mp4", "mp4"],
    ["video/webm;codecs=vp9", "webm"],
    ["video/webm", "webm"],
  ];
  for (const [m, ext] of cands) if (MediaRecorder.isTypeSupported(m)) return { mime: m, ext };
  return null;
}

export function loopSnappedDoc(doc: ProjectDoc, duration: number): ProjectDoc {
  return {
    ...doc,
    shapes: doc.shapes.map((s) => {
      const cycles = Math.max(1, Math.round(s.fx.speed * duration));
      return { ...s, fx: { ...s.fx, speed: cycles / duration } };
    }),
  };
}

/** Real-time render → MediaRecorder. Chrome/Edge produce MP4 (H.264); older browsers WebM. */
export async function exportVideo(
  doc: ProjectDoc,
  o: VideoOpts,
  onProgress: (frame: number, frames: number) => void,
  shouldCancel: () => boolean,
): Promise<{ cancelled: boolean; ext: string; bytes: number }> {
  const fmt = videoMime();
  if (!fmt) throw new Error("This browser cannot record video. Use Chrome or Edge, or export a PNG sequence.");
  const frames = Math.max(1, Math.round(o.duration * o.fps));
  const renderDoc = o.exactLoop ? loopSnappedDoc(doc, o.duration) : doc;
  const out = document.createElement("canvas");
  out.width = o.frameW;
  out.height = o.frameH;
  const octx = out.getContext("2d")!;
  const tmp = document.createElement("canvas");
  tmp.width = o.frameW;
  tmp.height = o.frameH;
  const tctx = tmp.getContext("2d")!;
  const stream = out.captureStream(o.fps);
  const rec = new MediaRecorder(stream, { mimeType: fmt.mime, videoBitsPerSecond: Math.min(60e6, o.frameW * o.frameH * o.fps * 0.25) });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const done = new Promise<void>((res) => (rec.onstop = () => res()));
  const draw = (t: number) => {
    renderFrame(tctx, renderDoc, o.frameW, o.frameH, t, o.includeScreens ? "map" : "content");
    octx.fillStyle = "#000000";
    octx.fillRect(0, 0, o.frameW, o.frameH);
    octx.drawImage(tmp, 0, 0);
  };
  draw(0);
  rec.start(250);
  const t0 = performance.now();
  let cancelled = false;
  for (let f = 0; f < frames; f++) {
    if (shouldCancel()) {
      cancelled = true;
      break;
    }
    draw(f / o.fps);
    onProgress(f + 1, frames);
    const wait = t0 + ((f + 1) * 1000) / o.fps - performance.now();
    await new Promise((r) => setTimeout(r, Math.max(0, wait)));
  }
  rec.stop();
  await done;
  stream.getTracks().forEach((t) => t.stop());
  if (cancelled) return { cancelled: true, ext: fmt.ext, bytes: 0 };
  const blob = new Blob(chunks, { type: fmt.mime.split(";")[0] });
  downloadBlob(blob, `${safeFileName(doc.name)}_border_${o.frameW}x${o.frameH}_${o.fps}fps.${fmt.ext}`);
  return { cancelled: false, ext: fmt.ext, bytes: blob.size };
}

// ------------------------------------------------------------------ LED wall slides

/** One PNG per LED screen, cropped at native pixel resolution, + full canvas + input map. */
export async function exportWallSlides(doc: ProjectDoc, t: number): Promise<number> {
  const full = document.createElement("canvas");
  full.width = doc.canvas.width;
  full.height = doc.canvas.height;
  renderFrame(full.getContext("2d")!, doc, full.width, full.height, t, "map");
  const toPng = (c: HTMLCanvasElement) =>
    new Promise<Uint8Array>((res, rej) => c.toBlob(async (b) => (b ? res(new Uint8Array(await b.arrayBuffer())) : rej(new Error("encode"))), "image/png"));
  const entries: { name: string; data: Uint8Array }[] = [{ name: `00_full_canvas_${full.width}x${full.height}.png`, data: await toPng(full) }];
  const im = document.createElement("canvas");
  im.width = full.width;
  im.height = full.height;
  renderFrame(im.getContext("2d")!, doc, im.width, im.height, 0, "inputmap");
  entries.push({ name: `00_resolume_input_map_${im.width}x${im.height}.png`, data: await toPng(im) });
  let i = 1;
  const lines = ["slide,screen,x,y,width,height,cabinets"];
  for (const s of doc.screens) {
    const r = screenRes(s);
    const c = document.createElement("canvas");
    c.width = r.w;
    c.height = r.h;
    c.getContext("2d")!.drawImage(full, s.x, s.y, r.w, r.h, 0, 0, r.w, r.h);
    const fname = `${String(i).padStart(2, "0")}_${safeFileName(s.name)}_${r.w}x${r.h}.png`;
    entries.push({ name: fname, data: await toPng(c) });
    lines.push(`${fname},${s.name},${Math.round(s.x)},${Math.round(s.y)},${r.w},${r.h},${s.cabsX}x${s.cabsY}`);
    i++;
  }
  entries.push({ name: "slides_index.csv", data: new TextEncoder().encode(lines.join("\n") + "\n") });
  downloadBlob(makeZip(entries), `${safeFileName(doc.name)}_led_wall_slides.zip`);
  return doc.screens.length;
}

export function SEQ_README(folder: string, o: SeqOpts, frames: number): string {
  return `VJ Mapping Studio — animated border PNG sequence
${frames} frames · ${o.frameW}x${o.frameH} · ${o.fps} fps · ${o.duration}s · ${o.transparent ? "transparent (alpha)" : "with background"}${o.exactLoop ? " · exact loop" : ""}

HOW TO USE IN RESOLUME (recommended: convert once to DXV)
1. Unzip this file. You get the folder "${folder}" with frame_0001.png ... frame_${String(frames).padStart(4, "0")}.png.
2. Open Resolume Alley (free, installed with Arena/Avenue).
3. Drag the WHOLE FOLDER "${folder}" into Alley — it is treated as ONE clip.
4. Convert settings: Codec DXV, Quality "High Quality with Alpha" (keeps transparency), frame rate ${o.fps}.
5. Drag the resulting .mov into a Resolume deck slot on a layer ABOVE your content.
6. Layer blend mode: "Alpha" (transparent export) or "Add"/"Screen" (black background export).
7. Set the composition size to ${o.frameW}x${o.frameH} (or let Resolume scale the clip) and map it in Advanced Output.

QUICK ALTERNATIVE (no conversion)
- Arena can also open image sequences directly: drag the folder onto a clip slot. DXV is faster on the GPU.
- Or, in VJ Mapping Studio, use Export > "Resolume Video (MP4)" — one file, drag straight into Arena, use "Add" blend mode.
`;
}
