// Core data model — mirrors backend/models/schemas.py for API types and defines the
// .vjmap document schema (vjmap/1). Nothing infers across the Python boundary:
// keep every Pydantic model and its TS interface in sync in the same edit.

export type ToolId =
  | "select"
  | "hand"
  | "screen"
  | "rect"
  | "rrect"
  | "circle"
  | "triangle"
  | "diamond"
  | "hexagon"
  | "star"
  | "pen"
  | "freehand"
  | "line";

export type ScreenOrder = "lr-tb" | "rl-tb" | "tb-lr" | "bt-lr" | "serpentine" | "custom";
export type ShapeKind =
  | "rect"
  | "rrect"
  | "circle"
  | "ellipse"
  | "triangle"
  | "diamond"
  | "hexagon"
  | "star"
  | "polygon"
  | "line"
  | "bezier"
  | "freehand";
export type StageKind =
  | "main-led"
  | "side-led"
  | "floor-led"
  | "ceiling-led"
  | "dj-booth"
  | "speaker"
  | "truss"
  | "moving-head"
  | "projector"
  | "custom";
export type Units = "px" | "m" | "cm" | "mm" | "ft";

export interface Vec2 {
  x: number;
  y: number;
}

export interface CanvasConfig {
  width: number;
  height: number;
  fps: number;
  background: string; // hex color or "transparent"
}

export interface LedScreen {
  id: string;
  name: string;
  x: number; // canvas px (top-left), 1 canvas px = 1 LED px
  y: number;
  cabsX: number; // cabinet counts (integers)
  cabsY: number;
  cabResX: number; // cabinet pixel resolution
  cabResY: number;
  cabW: number; // cabinet physical width  (mm)
  cabH: number; // cabinet physical height (mm)
  rotation: number; // degrees around center
  order: ScreenOrder;
  customOrder: number[] | null; // patch indices for order === "custom"
  color: string; // visual identification hue
  locked: boolean;
  visible: boolean;
  z: number;
  groupId: string | null;
  scan: number | null;
  refresh: number | null;
}

export interface CabinetInfo {
  number: number; // 1-based patch number
  col: number;
  row: number;
  x: number; // canvas px rect
  y: number;
  w: number;
  h: number;
  pxX: number; // pixel range within screen
  pxY: number;
  globX: number; // global canvas px
  globY: number;
  physX: number; // mm from screen top-left
  physY: number;
  physW: number;
  physH: number;
}

export interface EffectInstance {
  type: string; // catalog id — see lib/effects.ts
  enabled: boolean;
  speed: number; // cycles per second
  length: number; // 0..1 portion of perimeter
  start: number; // 0..1 start position along path
  direction: 1 | -1;
  glow: number; // glow radius px
  intensity: number; // 0..1.5
  color: string;
  color2: string;
  useGradient: boolean;
  phase: number; // 0..1 temporal offset
  offset: number; // 0..1 spatial offset
  loop: boolean;
  params: Record<string, number>;
}

export interface Shape {
  id: string;
  name: string;
  kind: ShapeKind;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation: number;
  points: Vec2[] | null; // absolute canvas coords (polygon / bezier / freehand)
  closed: boolean;
  stroke: string;
  stroke2: string;
  strokeWidth: number; // canvas px
  fill: string | null;
  fillOpacity: number;
  opacity: number;
  glow: number; // static glow when FX disabled
  blur: number;
  dash: string; // e.g. "8 6" or ""
  corner: number; // corner radius (rrect)
  sides: number; // polygon sides
  fx: EffectInstance;
  locked: boolean;
  visible: boolean;
  z: number;
  groupId: string | null;
}

export interface StageObject {
  id: string;
  kind: StageKind;
  label: string;
  x: number;
  y: number;
  w: number;
  h: number;
  rotation: number;
  color: string;
  visible: boolean;
  locked: boolean;
  z: number;
}

export interface ExportSettings {
  frameW: number;
  frameH: number;
  fps: number;
  duration: number;
  transparent: boolean;
  exactLoop: boolean;
}

export interface ProjectDoc {
  schema: string; // "vjmap/1"
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  canvas: CanvasConfig;
  screens: LedScreen[];
  shapes: Shape[];
  stage: StageObject[];
  stageMode: boolean;
  exportSettings: ExportSettings;
  meta: { author: string; event: string; notes: string };
}

// ------------------------------------------------------------- API mirrors
export type WallUnit = "ft" | "m";
export type CabUnit = "mm" | "cm" | "in" | "ft";

export interface CalcRequest {
  wall_w: number;
  wall_h: number;
  wall_unit: WallUnit;
  cab_w: number;
  cab_h: number;
  cab_unit: CabUnit;
  cab_res_x: number;
  cab_res_y: number;
  refresh_hz: number;
  scan: number;
  allow_partial: boolean;
}

export interface CalcResult {
  ok: boolean;
  cabinets_x: number;
  cabinets_y: number;
  total_cabinets: number;
  canvas_w: number;
  canvas_h: number;
  total_pixels: number;
  megapixels: number;
  actual_w_mm: number;
  actual_h_mm: number;
  aspect_w: number;
  aspect_h: number;
  aspect_dec: number;
  pixel_pitch_mm: number;
  px_per_m: number;
  px_per_m2: number;
  cab_aspect_w: number;
  cab_aspect_h: number;
  min_view_m: number;
  opt_view_m: number;
  power_max_w: number;
  power_typical_w: number;
  weight_kg: number;
  sending_ports: number;
  bandwidth_gbps: number | null;
  warnings: string[];
}

export interface ScreenSummary {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  phys_w_mm: number;
  phys_h_mm: number;
  cab_w_mm: number;
  cab_h_mm: number;
  cab_res_x: number;
  cab_res_y: number;
  cabs_x: number;
  cabs_y: number;
  order: string;
}

export interface CsvExportRequest {
  project_name: string;
  screens: ScreenSummary[];
  include_cabinets: boolean;
}

export interface CsvExportResponse {
  filename: string;
  csv: string;
}

export interface CabinetPreset {
  name: string;
  width_mm: number;
  height_mm: number;
  res_x: number;
  res_y: number;
  pitch_mm?: number | null;
}

export interface PitchPreset {
  pitch_mm: number;
  desc: string;
}

export interface PresetsResponse {
  cabinets: CabinetPreset[];
  pitches: PitchPreset[];
}

export interface ProjectMeta {
  id: string;
  name: string;
  updated_at: string;
  canvas_w: number;
  canvas_h: number;
  screen_count: number;
  shape_count: number;
}

export interface ProjectListResponse {
  projects: ProjectMeta[];
}

export interface ProjectLoadResponse {
  id: string;
  doc: ProjectDoc;
}

export interface ProjectSaveResponse {
  id: string;
  name: string;
  updated_at: string;
}
