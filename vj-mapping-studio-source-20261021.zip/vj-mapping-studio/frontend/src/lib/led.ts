// LED math engine — pure functions, no side effects. Mirrors
// backend/routers/calc.py (server-verified copy of the same formulas).

import type {
  CalcResult,
  CabinetInfo,
  LedScreen,
  ProjectDoc,
  ScreenSummary,
  Units,
} from "./types";
import { clamp, fmtNum } from "./format";

export const MM_PER: Record<string, number> = { mm: 1, cm: 10, in: 25.4, ft: 304.8, m: 1000 };

export function toMm(v: number, unit: string): number {
  return v * (MM_PER[unit] ?? 1);
}

export function gcd(a: number, b: number): number {
  a = Math.abs(Math.round(a));
  b = Math.abs(Math.round(b));
  while (b) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a || 1;
}

export function reduceAspect(w: number, h: number): [number, number] {
  const g = gcd(w, h);
  return [Math.round(w) / g, Math.round(h) / g];
}

// hardware estimate constants (clearly labelled as estimates in the UI)
export const POWER_W_PER_M2 = 690;
export const POWER_TYPICAL_FACTOR = 0.35;
export const WEIGHT_KG_PER_M2 = 35;
export const PORT_PIXEL_CAPACITY = 650_000; // NovaStar MCTRL4K / Brompton class

export interface WallInputs {
  wallW: number;
  wallH: number;
  wallUnit: "ft" | "m";
  cabW: number;
  cabH: number;
  cabUnit: "mm" | "cm" | "in" | "ft";
  cabResX: number;
  cabResY: number;
  refreshHz: number;
  scan: number;
  allowPartial: boolean;
}

export type WallCalc = { ok: true; result: CalcResult } | { ok: false; error: string };

export function computeWall(i: WallInputs): WallCalc {
  if (!(i.wallW > 0) || !(i.wallH > 0)) return { ok: false, error: "Wall width and height must be greater than zero." };
  if (!(i.cabW > 0) || !(i.cabH > 0)) return { ok: false, error: "Cabinet dimensions must be greater than zero." };
  if (!(i.cabResX > 0) || !(i.cabResY > 0))
    return { ok: false, error: "Cabinet pixel resolution must be at least 1 × 1 px." };

  const wallWmm = toMm(i.wallW, i.wallUnit);
  const wallHmm = toMm(i.wallH, i.wallUnit);
  const cabWmm = toMm(i.cabW, i.cabUnit);
  const cabHmm = toMm(i.cabH, i.cabUnit);
  if (cabWmm <= 0 || cabHmm <= 0) return { ok: false, error: "Cabinet physical size must be positive." };

  const warnings: string[] = [];

  const fit = (wallMm: number, cabMm: number, axis: string, disp: string): number | string => {
    const exact = wallMm / cabMm;
    const n = Math.round(exact);
    if (Math.abs(exact - n) < 1e-6) return n;
    const lo = Math.floor(exact);
    const loFt = (lo * cabMm) / 304.8;
    if (!i.allowPartial) {
      return (
        `Wall ${axis} ${disp} (${wallMm.toFixed(1)} mm) cannot be exactly divided by a ` +
        `${fmtNum(cabMm, 1)} mm cabinet (${exact.toFixed(3)} cabinets). ` +
        `Use ${lo} cabinets (wall becomes ${loFt.toFixed(2)} ft / ${(lo * cabMm).toFixed(0)} mm) ` +
        `or enable "Allow partial / custom layout".`
      );
    }
    warnings.push(
      `Wall ${axis} is not an exact cabinet multiple — using the nearest fit of ${lo} cabinets ` +
        `(actual ${axis} ${(lo * cabMm).toFixed(1)} mm / ${loFt.toFixed(2)} ft instead of ${disp}).`
    );
    return lo;
  };

  const cx = fit(wallWmm, cabWmm, "width", `${i.wallW} ${i.wallUnit}`);
  if (typeof cx === "string") return { ok: false, error: cx };
  const cy = fit(wallHmm, cabHmm, "height", `${i.wallH} ${i.wallUnit}`);
  if (typeof cy === "string") return { ok: false, error: cy };

  const cabsX = Math.max(1, cx);
  const cabsY = Math.max(1, cy);
  const canvasW = cabsX * i.cabResX;
  const canvasH = cabsY * i.cabResY;
  const totalPx = canvasW * canvasH;
  const actualW = cabsX * cabWmm;
  const actualH = cabsY * cabHmm;
  const areaM2 = (actualW / 1000) * (actualH / 1000);
  const [aw, ah] = reduceAspect(canvasW, canvasH);
  const [caw, cah] = reduceAspect(Math.round(cabWmm * 100), Math.round(cabHmm * 100));
  const pitch = cabWmm / i.cabResX;
  const pxPerM = i.cabResX / (cabWmm / 1000);

  let bandwidth: number | null = null;
  if (i.refreshHz > 0) bandwidth = (totalPx * i.refreshHz * 24 * 1.25) / 8 / 1e9;

  const result: CalcResult = {
    ok: true,
    cabinets_x: cabsX,
    cabinets_y: cabsY,
    total_cabinets: cabsX * cabsY,
    canvas_w: canvasW,
    canvas_h: canvasH,
    total_pixels: totalPx,
    megapixels: Number((totalPx / 1e6).toFixed(3)),
    actual_w_mm: Number(actualW.toFixed(1)),
    actual_h_mm: Number(actualH.toFixed(1)),
    aspect_w: aw,
    aspect_h: ah,
    aspect_dec: Number((canvasW / canvasH).toFixed(3)),
    pixel_pitch_mm: Number(pitch.toFixed(3)),
    px_per_m: Number(pxPerM.toFixed(1)),
    px_per_m2: Number((pxPerM * (i.cabResY / (cabHmm / 1000))).toFixed(1)),
    cab_aspect_w: caw,
    cab_aspect_h: cah,
    min_view_m: Number(pitch.toFixed(2)),
    opt_view_m: Number((pitch * 2.5).toFixed(2)),
    power_max_w: Math.round(areaM2 * POWER_W_PER_M2),
    power_typical_w: Math.round(areaM2 * POWER_W_PER_M2 * POWER_TYPICAL_FACTOR),
    weight_kg: Math.round(areaM2 * WEIGHT_KG_PER_M2),
    sending_ports: Math.max(1, Math.ceil(totalPx / PORT_PIXEL_CAPACITY)),
    bandwidth_gbps: bandwidth === null ? null : Number(bandwidth.toFixed(2)),
    warnings,
  };
  return { ok: true, result };
}

// ------------------------------------------------------------------ screens

export function screenRes(s: LedScreen): { w: number; h: number } {
  return { w: s.cabsX * s.cabResX, h: s.cabsY * s.cabResY };
}

export function screenPhysMm(s: LedScreen): { w: number; h: number } {
  return { w: s.cabsX * s.cabW, h: s.cabsY * s.cabH };
}

export function screenPitchMm(s: LedScreen): number {
  return s.cabResX > 0 ? s.cabW / s.cabResX : 0;
}

export function screenAreaM2(s: LedScreen): number {
  const p = screenPhysMm(s);
  return (p.w / 1000) * (p.h / 1000);
}

export function screenPower(s: LedScreen): { max: number; typical: number } {
  const a = screenAreaM2(s);
  return { max: Math.round(a * POWER_W_PER_M2), typical: Math.round(a * POWER_W_PER_M2 * POWER_TYPICAL_FACTOR) };
}

export function screenWeightKg(s: LedScreen): number {
  return Math.round(screenAreaM2(s) * WEIGHT_KG_PER_M2);
}

export function sendingPorts(totalPx: number): number {
  return Math.max(1, Math.ceil(totalPx / PORT_PIXEL_CAPACITY));
}

/** Patch-order cabinet builder. Mirrors backend/routers/export_router.py `_cabinet_order`. */
export function buildCabinets(s: LedScreen): CabinetInfo[] {
  const res = screenRes(s);
  const cabWpx = s.cabsX > 0 ? res.w / s.cabsX : 0;
  const cabHpx = s.cabsY > 0 ? res.h / s.cabsY : 0;

  const cells: [number, number][] = [];
  for (let r = 0; r < s.cabsY; r++) for (let c = 0; c < s.cabsX; c++) cells.push([c, r]);

  let ordered: [number, number][];
  switch (s.order) {
    case "rl-tb":
      ordered = cells.map(([c, r]) => [s.cabsX - 1 - c, r] as [number, number]);
      break;
    case "tb-lr": {
      ordered = [];
      for (let c = 0; c < s.cabsX; c++) for (let r = 0; r < s.cabsY; r++) ordered.push([c, r]);
      break;
    }
    case "bt-lr": {
      ordered = [];
      for (let c = 0; c < s.cabsX; c++) for (let r = s.cabsY - 1; r >= 0; r--) ordered.push([c, r]);
      break;
    }
    case "serpentine": {
      ordered = [];
      for (let r = 0; r < s.cabsY; r++) {
        const row: [number, number][] = [];
        for (let c = 0; c < s.cabsX; c++) row.push([c, r]);
        if (r % 2 === 0) ordered.push(...row);
        else ordered.push(...row.reverse());
      }
      break;
    }
    case "custom": {
      const co = s.customOrder;
      ordered =
        co && co.length === s.cabsX * s.cabsY
          ? co.map((i) => cells[i]).filter((v) => !!v)
          : cells;
      break;
    }
    default:
      ordered = cells;
  }

  return ordered.map(([c, r], i) => {
    const x = s.x + c * cabWpx;
    const y = s.y + r * cabHpx;
    return {
      number: i + 1,
      col: c,
      row: r,
      x,
      y,
      w: cabWpx,
      h: cabHpx,
      pxX: Math.round(c * cabWpx),
      pxY: Math.round(r * cabHpx),
      globX: Math.round(x),
      globY: Math.round(y),
      physX: c * s.cabW,
      physY: r * s.cabH,
      physW: s.cabW,
      physH: s.cabH,
    };
  });
}

export function toScreenSummary(s: LedScreen): ScreenSummary {
  const res = screenRes(s);
  const phys = screenPhysMm(s);
  return {
    name: s.name,
    x: Math.round(s.x),
    y: Math.round(s.y),
    width: res.w,
    height: res.h,
    phys_w_mm: Number(phys.w.toFixed(1)),
    phys_h_mm: Number(phys.h.toFixed(1)),
    cab_w_mm: s.cabW,
    cab_h_mm: s.cabH,
    cab_res_x: s.cabResX,
    cab_res_y: s.cabResY,
    cabs_x: s.cabsX,
    cabs_y: s.cabsY,
    order: s.order,
  };
}

export interface DocTotals {
  pixels: number;
  mp: number;
  cabinets: number;
  ports: number;
  powerMax: number;
  powerTypical: number;
  weightKg: number;
  aspectW: number;
  aspectH: number;
}

export function docTotals(doc: ProjectDoc): DocTotals {
  let px = 0;
  let cabs = 0;
  let powerMax = 0;
  let weight = 0;
  for (const s of doc.screens) {
    const r = screenRes(s);
    px += r.w * r.h;
    cabs += s.cabsX * s.cabsY;
    powerMax += screenPower(s).max;
    weight += screenWeightKg(s);
  }
  const [aw, ah] = reduceAspect(doc.canvas.width, doc.canvas.height);
  return {
    pixels: px,
    mp: px / 1e6,
    cabinets: cabs,
    ports: sendingPorts(px),
    powerMax,
    powerTypical: Math.round(powerMax * POWER_TYPICAL_FACTOR),
    weightKg: weight,
    aspectW: aw,
    aspectH: ah,
  };
}

/** Reference pitch for unit conversion — pitch of a selected screen, else first screen, else 3.91 mm. */
export function docPitchMm(doc: ProjectDoc, selectedId?: string | null): number {
  const s = (selectedId ? doc.screens.find((x) => x.id === selectedId) : null) ?? doc.screens[0];
  return s ? screenPitchMm(s) : 3.91;
}

/** Convert a world (canvas px) length to the display unit. */
export function pxToUnitStr(px: number, unit: Units, pitchMm: number): string {
  const mm = px * pitchMm;
  switch (unit) {
    case "m":
      return `${fmtNum(mm / 1000, 2)} m`;
    case "cm":
      return `${fmtNum(mm / 10, 1)} cm`;
    case "mm":
      return `${fmtNum(mm, 0)} mm`;
    case "ft": {
      const ft = mm / 304.8;
      const whole = Math.floor(ft);
      const inch = Math.round((ft - whole) * 12);
      return inch === 12 ? `${whole + 1}′ 0″` : `${whole}′ ${inch}″`;
    }
    default:
      return `${Math.round(px)} px`;
  }
}

export function cabCenterPx(s: LedScreen, info: CabinetInfo): { cx: number; cy: number } {
  void s;
  return { cx: info.x + info.w / 2, cy: info.y + info.h / 2 };
}

export { clamp };
