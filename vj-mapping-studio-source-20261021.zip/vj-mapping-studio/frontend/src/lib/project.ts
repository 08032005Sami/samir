// .vjmap project system: schema, defaults, templates, presets, autosave, recents.
// Standalone — works on plain document objects with no editor store dependency.

import type {
  CabinetPreset,
  EffectInstance,
  LedScreen,
  ProjectDoc,
  ScreenOrder,
  Shape,
  ShapeKind,
  StageKind,
  StageObject,
} from "./types";
import { nowIso, safeFileName, uid } from "./format";
import { makeEffect } from "./effects";
import { downloadBlob } from "./format";

export const SCHEMA = "vjmap/1";

// ------------------------------------------------------------- builders

export function mkScreen(
  name: string,
  x: number,
  y: number,
  cabsX: number,
  cabsY: number,
  opts?: Partial<Pick<LedScreen, "cabResX" | "cabResY" | "cabW" | "cabH" | "order" | "color" | "rotation" | "locked" | "visible" | "groupId" | "scan" | "refresh">>,
): LedScreen {
  return {
    id: uid(),
    name,
    x,
    y,
    cabsX,
    cabsY,
    cabResX: opts?.cabResX ?? 128,
    cabResY: opts?.cabResY ?? 128,
    cabW: opts?.cabW ?? 500,
    cabH: opts?.cabH ?? 500,
    rotation: opts?.rotation ?? 0,
    order: opts?.order ?? "serpentine",
    customOrder: null,
    color: opts?.color ?? "#00F0FF",
    locked: false,
    visible: true,
    z: 0,
    groupId: opts?.groupId ?? null,
    scan: opts?.scan ?? null,
    refresh: opts?.refresh ?? null,
  };
}

export function mkShape(
  kind: ShapeKind,
  x: number,
  y: number,
  w: number,
  h: number,
  fxType: string,
  color: string,
  opts?: Partial<Shape>,
): Shape {
  const fx: EffectInstance = makeEffect(fxType);
  fx.color = color;
  return {
    id: uid(),
    name: opts?.name ?? kind.charAt(0).toUpperCase() + kind.slice(1),
    kind,
    x,
    y,
    w,
    h,
    rotation: 0,
    points: null,
    closed: kind !== "line",
    stroke: color,
    stroke2: "#FF007F",
    strokeWidth: 6,
    fill: null,
    fillOpacity: 0.15,
    opacity: 1,
    glow: 12,
    blur: 0,
    dash: "",
    corner: kind === "rrect" ? 24 : 0,
    sides: 6,
    fx,
    locked: false,
    visible: true,
    z: 0,
    groupId: null,
    ...opts,
  };
}

export function mkStage(kind: StageKind, x: number, y: number, w: number, h: number, label?: string): StageObject {
  return {
    id: uid(),
    kind,
    label: label ?? kind.replace("-", " ").toUpperCase(),
    x,
    y,
    w,
    h,
    rotation: 0,
    color: "#8A99B5",
    visible: true,
    locked: false,
    z: 0,
  };
}

export function baseDoc(name = "Untitled Show"): ProjectDoc {
  return {
    schema: SCHEMA,
    id: uid(),
    name,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    canvas: { width: 1920, height: 1080, fps: 30, background: "#05070B" },
    screens: [],
    shapes: [],
    stage: [],
    stageMode: true,
    exportSettings: { frameW: 1920, frameH: 1080, fps: 30, duration: 8, transparent: true, exactLoop: true },
    meta: { author: "", event: "", notes: "" },
  };
}

// ------------------------------------------------------------- templates

export interface StageTemplate {
  id: string;
  name: string;
  desc: string;
  build: () => ProjectDoc;
}

function borderFor(doc: ProjectDoc, color: string, fxType: string): Shape {
  const biggest = doc.screens.reduce((a, b) => (a && a.cabsX * a.cabResX >= b.cabsX * b.cabResX ? a : b), doc.screens[0]);
  if (!biggest) return mkShape("rrect", 40, 40, 600, 340, fxType, color);
  const w = biggest.cabsX * biggest.cabResX;
  const h = biggest.cabsY * biggest.cabResY;
  return mkShape("rrect", biggest.x + 20, biggest.y + 20, w - 40, h - 40, fxType, color, { name: "Main Border" });
}

export const STAGE_TEMPLATES: StageTemplate[] = [
  {
    id: "main_stage_festival",
    name: "Festival Main Stage",
    desc: "16:9 center wall + portrait wings + DJ front banner",
    build: () => {
      const d = baseDoc("Festival Main Stage");
      d.canvas = { width: 3840, height: 1280, fps: 30, background: "#05070B" };
      d.screens = [
        mkScreen("Wing L", 0, 0, 6, 9, { color: "#FF007F" }),
        mkScreen("Main Stage LED", 960, 0, 15, 9, { color: "#00F0FF" }),
        mkScreen("Wing R", 3072, 0, 6, 9, { color: "#FF007F" }),
        mkScreen("DJ Banner", 960, 1080, 15, 2, { color: "#FFB800" }),
      ];
      d.shapes = [
        borderFor(d, "#00F0FF", "traveling_light"),
        mkShape("rrect", 24, 24, 720, 1032, "comet_tail", "#FF007F", { name: "Wing Border L" }),
        mkShape("rrect", 3096, 24, 720, 1032, "comet_tail", "#FF007F", { name: "Wing Border R" }),
        mkShape("hexagon", 1770, 380, 300, 300, "rainbow_cycle", "#7C4DFF", { name: "Center Hex" }),
      ];
      d.stage = [
        mkStage("dj-booth", 1728, 1350, 384, 150),
        mkStage("speaker", 1350, 1330, 130, 240, "SPEAKER L"),
        mkStage("speaker", 2360, 1330, 130, 240, "SPEAKER R"),
        mkStage("truss", 960, 1300, 1920, 26),
        mkStage("moving-head", 1500, 1420, 90, 70),
        mkStage("moving-head", 2250, 1420, 90, 70),
      ];
      return d;
    },
  },
  {
    id: "dj_booth_chevron",
    name: "EDM DJ Booth & Chevron",
    desc: "Geometric facade + angled pillars + overhead truss LED",
    build: () => {
      const d = baseDoc("DJ Booth Chevron");
      d.canvas = { width: 1920, height: 1080, fps: 30, background: "#05070B" };
      d.screens = [
        mkScreen("Booth Facade", 320, 704, 10, 2, { color: "#00F0FF" }),
        mkScreen("Truss LED", 320, 64, 10, 1, { color: "#FF007F" }),
        mkScreen("Pillar L1", 160, 560, 1, 3, { color: "#FFB800", rotation: -8 }),
        mkScreen("Pillar L2", 240, 500, 1, 3, { color: "#FFB800", rotation: -4 }),
        mkScreen("Pillar R1", 1660, 560, 1, 3, { color: "#FFB800", rotation: 8 }),
        mkScreen("Pillar R2", 1580, 500, 1, 3, { color: "#FFB800", rotation: 4 }),
      ];
      d.shapes = [
        mkShape("triangle", 860, 240, 100, 180, "audio_reactive_pulse", "#FF007F", { name: "Chevron C", sides: 3 }),
        mkShape("triangle", 960, 240, 100, 180, "audio_reactive_pulse", "#FF007F", { name: "Chevron C2", sides: 3, rotation: 180 }),
        mkShape("rrect", 344, 728, 1232, 208, "cyber_matrix_run", "#00F0FF", { name: "Booth Border" }),
      ];
      d.stage = [mkStage("dj-booth", 760, 760, 400, 180), mkStage("speaker", 180, 820, 110, 210), mkStage("speaker", 1630, 820, 110, 210)];
      return d;
    },
  },
  {
    id: "triple_screen_widescreen",
    name: "Corporate 3-Screen Panoramic",
    desc: "Left / Center 4K / Right blended surfaces",
    build: () => {
      const d = baseDoc("Corporate Panoramic");
      d.canvas = { width: 5760, height: 1080, fps: 30, background: "#05070B" };
      d.screens = [
        mkScreen("Screen L", 0, 0, 15, 9, { color: "#00F0FF" }),
        mkScreen("Screen C", 1920, 0, 15, 9, { color: "#00FFA3" }),
        mkScreen("Screen R", 3840, 0, 15, 9, { color: "#FF007F" }),
      ];
      d.shapes = [
        mkShape("line", 1920, 0, 0, 1080, "electric_arc", "#FFFFFF", { name: "Blend L", strokeWidth: 3 }),
        mkShape("line", 3840, 0, 0, 1080, "electric_arc", "#FFFFFF", { name: "Blend R", strokeWidth: 3 }),
        borderFor(d, "#00FFA3", "duotone_gradient_sweep"),
      ];
      return d;
    },
  },
  {
    id: "resolume_cube_stage",
    name: "3D LED Cube & Floor Array",
    desc: "Multi-planar mapping for perspective illusion shows",
    build: () => {
      const d = baseDoc("LED Cube & Floor");
      d.canvas = { width: 2560, height: 1440, fps: 30, background: "#05070B" };
      d.screens = [
        mkScreen("Cube Back", 640, 192, 10, 6, { color: "#00F0FF" }),
        mkScreen("Cube Left", 0, 192, 5, 6, { color: "#7C4DFF" }),
        mkScreen("Cube Right", 1920, 192, 5, 6, { color: "#7C4DFF" }),
        mkScreen("LED Floor", 640, 912, 10, 2, { color: "#00FFA3" }),
        mkScreen("LED Ceiling", 640, 0, 10, 1, { color: "#FFB800" }),
      ];
      d.shapes = [
        borderFor(d, "#00F0FF", "hypnotic_spiral"),
        mkShape("rrect", 664, 936, 1232, 208, "wave_travel", "#00FFA3", { name: "Floor Border" }),
      ];
      return d;
    },
  },
  {
    id: "curved_arch_portal",
    name: "Curved Archway Portal",
    desc: "Segmented polygonal portal arch with perimeter chase",
    build: () => {
      const d = baseDoc("Archway Portal");
      d.canvas = { width: 1920, height: 1080, fps: 30, background: "#05070B" };
      const screens: LedScreen[] = [];
      const n = 11;
      const cx = 960;
      const cy = 1500;
      const r = 1150;
      for (let i = 0; i < n; i++) {
        const a = Math.PI + (Math.PI * i) / (n - 1); // 180°..360°
        const px = cx + Math.cos(a) * r;
        const py = cy + Math.sin(a) * r;
        const ang = (a * 180) / Math.PI + 90;
        screens.push(mkScreen(`Arch ${i + 1}`, px - 128, py - 128, 2, 4, { color: "#00F0FF", rotation: Math.round(ang) }));
      }
      d.screens = screens;
      d.shapes = [mkShape("freehand", 300, 200, 1320, 700, "traveling_light", "#FF3366", { name: "Arch Chase", strokeWidth: 8 })];
      d.shapes[0].points = [
        { x: 320, y: 900 },
        { x: 320, y: 500 },
        { x: 560, y: 240 },
        { x: 960, y: 200 },
        { x: 1360, y: 240 },
        { x: 1600, y: 500 },
        { x: 1600, y: 900 },
      ];
      d.shapes[0].closed = false;
      d.stage = [mkStage("dj-booth", 800, 950, 320, 120), mkStage("speaker", 560, 960, 90, 110), mkStage("speaker", 1270, 960, 90, 110)];
      return d;
    },
  },
];

// ------------------------------------------------------------- quick grids

export interface GridTemplate {
  id: string;
  name: string;
  cols: number;
  rows: number;
  cell?: number;
  skip?: string[]; // "col,row" cells to remove (for L / U shapes)
}

export const GRID_TEMPLATES: GridTemplate[] = [
  { id: "g-2x1", name: "2 × 1", cols: 2, rows: 1 },
  { id: "g-3x1", name: "3 × 1", cols: 3, rows: 1 },
  { id: "g-4x1", name: "4 × 1", cols: 4, rows: 1 },
  { id: "g-2x2", name: "2 × 2", cols: 2, rows: 2 },
  { id: "g-3x2", name: "3 × 2", cols: 3, rows: 2 },
  { id: "g-lshape", name: "L-Shape", cols: 3, rows: 2, skip: ["2,0"] },
  { id: "g-ushape", name: "U-Shape", cols: 3, rows: 3, skip: ["1,0", "1,1", "1,2"] },
  { id: "g-backdrop", name: "Stage Backdrop", cols: 1, rows: 1, cell: 640 },
  { id: "g-booth", name: "DJ Booth", cols: 5, rows: 1, cell: 256 },
  { id: "g-floor", name: "LED Floor", cols: 8, rows: 1, cell: 256 },
];

export function applyGridTemplate(doc: ProjectDoc, t: GridTemplate): ProjectDoc {
  const cell = t.cell ?? 256; // 2 cabinets of 128px
  const gap = 0;
  const cols = t.cols;
  const rows = t.rows;
  const width = cols * (cell + gap);
  const height = rows * (cell + gap);
  const scale = doc.canvas.width >= 200 ? 1 : 1;
  void scale;
  const screens: LedScreen[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (t.skip?.includes(`${c},${r}`)) continue;
      screens.push(
        mkScreen(`Screen ${screens.length + 1}`, c * cell + 60, r * cell + 60, cell / 128, cell / 128, {
          color: ["#00F0FF", "#FF007F", "#00FFA3", "#FFB800", "#7C4DFF"][(screens.length % 5)],
        }),
      );
    }
  }
  // fit canvas around the grid
  doc.canvas = { ...doc.canvas, width: width + 120, height: height + 120 };
  doc.screens = screens;
  return doc;
}

// ------------------------------------------------------------- scene presets

export interface ScenePreset {
  id: string;
  name: string;
  desc: string;
  canvas: { width: number; height: number; fps: number };
  template?: string; // stage template id
}

export const SCENE_PRESETS: ScenePreset[] = [
  { id: "dj", name: "DJ Set", desc: "Booth facade + pillars, 60 fps energy", canvas: { width: 1920, height: 1080, fps: 60 }, template: "dj_booth_chevron" },
  { id: "concert", name: "Concert", desc: "Wide wall + side IMAG screens", canvas: { width: 3840, height: 1080, fps: 30 }, template: "main_stage_festival" },
  { id: "wedding", name: "Wedding", desc: "Soft 16:9 backdrop, gentle FX", canvas: { width: 1280, height: 720, fps: 30 }, template: "g-backdrop" },
  { id: "festival", name: "Festival Main Stage", desc: "Full festival rig with wings", canvas: { width: 3840, height: 1280, fps: 30 }, template: "main_stage_festival" },
  { id: "corporate", name: "Corporate", desc: "Panoramic 3-screen blend", canvas: { width: 5760, height: 1080, fps: 30 }, template: "triple_screen_widescreen" },
  { id: "club", name: "Club", desc: "Portrait pillars + booth strip", canvas: { width: 1080, height: 1920, fps: 60 }, template: "g-booth" },
  { id: "stage", name: "Theatre Stage", desc: "Classic backdrop mapping", canvas: { width: 1920, height: 1080, fps: 30 }, template: "g-backdrop" },
  { id: "pm", name: "Projection Mapping", desc: "Freeform shapes on building facade", canvas: { width: 1920, height: 1080, fps: 30 }, template: "curved_arch_portal" },
  { id: "ledwall", name: "LED Wall", desc: "Single wall, calculator-first", canvas: { width: 1280, height: 768, fps: 30 }, template: "g-backdrop" },
  { id: "ledfloor", name: "LED Floor", desc: "Long floor strip", canvas: { width: 2048, height: 384, fps: 30 }, template: "g-floor" },
];

export function newFromScenePreset(presetId: string): ProjectDoc {
  const p = SCENE_PRESETS.find((x) => x.id === presetId);
  if (!p) return defaultProject();
  if (p.template) {
    const t = STAGE_TEMPLATES.find((x) => x.id === p.template);
    if (t) {
      const d = t.build();
      d.canvas = { ...d.canvas, ...p.canvas };
      d.name = p.name;
      return d;
    }
    const g = GRID_TEMPLATES.find((x) => x.id === p.template);
    if (g) {
      const d = baseDoc(p.name);
      d.canvas = { ...d.canvas, ...p.canvas };
      applyGridTemplate(d, g);
      return d;
    }
  }
  const d = baseDoc(p.name);
  d.canvas = { ...d.canvas, ...p.canvas };
  return d;
}

/** First-run project: the festival main stage, already animated. */
export function defaultProject(): ProjectDoc {
  return STAGE_TEMPLATES[0].build();
}

// ------------------------------------------------------------- validate / io

export function validateDoc(raw: unknown): ProjectDoc {
  if (!raw || typeof raw !== "object") throw new Error("Not a VJ Mapping Studio project file.");
  const d = raw as Partial<ProjectDoc>;
  if (!d.schema) throw new Error("Missing schema field — is this a .vjmap file?");
  if (!d.schema.startsWith("vjmap/")) throw new Error(`Unsupported schema "${d.schema}" — expected vjmap/1.`);
  const b = baseDoc();
  return {
    ...b,
    ...d,
    schema: SCHEMA,
    id: d.id || uid(),
    name: d.name || "Untitled Show",
    createdAt: d.createdAt || nowIso(),
    updatedAt: d.updatedAt || nowIso(),
    canvas: { ...b.canvas, ...(d.canvas ?? {}) },
    screens: (d.screens ?? []).map((s) => ({ ...mkScreen(s.name ?? "Screen", s.x ?? 0, s.y ?? 0, s.cabsX ?? 4, s.cabsY ?? 3), ...s })),
    shapes: (d.shapes ?? []).map((s) => ({ ...mkShape(s.kind ?? "rect", s.x ?? 0, s.y ?? 0, s.w ?? 200, s.h ?? 200, s.fx?.type ?? "traveling_light", s.stroke ?? "#00F0FF"), ...s, fx: { ...makeEffect(s.fx?.type ?? "traveling_light"), ...(s.fx ?? {}) } })),
    stage: (d.stage ?? []).map((s) => ({ ...mkStage(s.kind ?? "custom", s.x ?? 0, s.y ?? 0, s.w ?? 100, s.h ?? 100, s.label), ...s })),
    exportSettings: { ...b.exportSettings, ...(d.exportSettings ?? {}) },
    meta: { ...b.meta, ...(d.meta ?? {}) },
  } as ProjectDoc;
}

export function parseProject(text: string): ProjectDoc {
  const raw = JSON.parse(text);
  return validateDoc(raw);
}

export function downloadProject(doc: ProjectDoc): void {
  const out = { ...doc, updatedAt: nowIso(), schema: SCHEMA };
  downloadBlob(new Blob([JSON.stringify(out, null, 2)], { type: "application/json" }), `${safeFileName(doc.name)}.vjmap`);
}

// ------------------------------------------------------------- local storage

const AUTOSAVE_KEY = "vjmap.autosave.v1";
const RECENTS_KEY = "vjmap.recents.v1";
const USER_TPL_KEY = "vjmap.user_templates.v1";
const FX_FAV_KEY = "vjmap.fx_favs.v1";
const RECENT_COLORS_KEY = "vjmap.recent_colors.v1";

export interface AutosaveData {
  doc: ProjectDoc;
  at: string;
}

export function autosaveDoc(doc: ProjectDoc): void {
  try {
    localStorage.setItem(AUTOSAVE_KEY, JSON.stringify({ doc, at: nowIso() }));
  } catch {
    /* storage full — non-fatal */
  }
}

export function loadAutosave(): AutosaveData | null {
  try {
    const raw = localStorage.getItem(AUTOSAVE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AutosaveData;
    return { doc: validateDoc(parsed.doc), at: parsed.at };
  } catch {
    return null;
  }
}

export function clearAutosave(): void {
  localStorage.removeItem(AUTOSAVE_KEY);
}

export interface RecentProject {
  id: string;
  name: string;
  at: string;
}

export function getRecents(): RecentProject[] {
  try {
    return JSON.parse(localStorage.getItem(RECENTS_KEY) ?? "[]") as RecentProject[];
  } catch {
    return [];
  }
}

export function pushRecent(id: string, name: string): void {
  const list = getRecents().filter((r) => r.id !== id);
  list.unshift({ id, name, at: nowIso() });
  localStorage.setItem(RECENTS_KEY, JSON.stringify(list.slice(0, 12)));
}

export interface UserTemplate {
  id: string;
  name: string;
  at: string;
  doc: ProjectDoc;
}

export function getUserTemplates(): UserTemplate[] {
  try {
    return JSON.parse(localStorage.getItem(USER_TPL_KEY) ?? "[]") as UserTemplate[];
  } catch {
    return [];
  }
}

export function saveUserTemplate(name: string, doc: ProjectDoc): void {
  const list = getUserTemplates();
  list.unshift({ id: uid(), name, at: nowIso(), doc });
  localStorage.setItem(USER_TPL_KEY, JSON.stringify(list.slice(0, 24)));
}

export function deleteUserTemplate(id: string): void {
  localStorage.setItem(USER_TPL_KEY, JSON.stringify(getUserTemplates().filter((t) => t.id !== id)));
}

export function getFxFavorites(): string[] {
  try {
    return JSON.parse(localStorage.getItem(FX_FAV_KEY) ?? "[]") as string[];
  } catch {
    return [];
  }
}

export function setFxFavorites(ids: string[]): void {
  localStorage.setItem(FX_FAV_KEY, JSON.stringify(ids));
}

export function getRecentColors(): string[] {
  try {
    return JSON.parse(localStorage.getItem(RECENT_COLORS_KEY) ?? '["#00F0FF","#FF007F","#00FFA3","#FFB800","#7C4DFF","#FFFFFF"]') as string[];
  } catch {
    return [];
  }
}

export function pushRecentColor(c: string): void {
  const list = getRecentColors().filter((x) => x !== c);
  list.unshift(c);
  localStorage.setItem(RECENT_COLORS_KEY, JSON.stringify(list.slice(0, 12)));
}

// offline fallback for /api/presets
export const CABINET_PRESETS_FALLBACK: CabinetPreset[] = [
  { name: "500 × 500 mm — Standard Stage Panel", width_mm: 500, height_mm: 500, res_x: 128, res_y: 128 },
  { name: "500 × 1000 mm — Tall Touring Panel", width_mm: 500, height_mm: 1000, res_x: 128, res_y: 256 },
  { name: "576 × 576 mm — P3 Die-cast (192×192)", width_mm: 576, height_mm: 576, res_x: 192, res_y: 192 },
  { name: "576 × 576 mm — P4.8 Die-cast (120×120)", width_mm: 576, height_mm: 576, res_x: 120, res_y: 120 },
  { name: "576 × 576 mm — P6 Die-cast (96×96)", width_mm: 576, height_mm: 576, res_x: 96, res_y: 96 },
  { name: "2 ft × 2 ft — Imperial Standard (609.6 mm)", width_mm: 609.6, height_mm: 609.6, res_x: 156, res_y: 156 },
  { name: "1 ft × 1 ft — Mini Modular (304.8 mm)", width_mm: 304.8, height_mm: 304.8, res_x: 78, res_y: 78 },
  { name: "600 × 337.5 mm — 16:9 HD Cabinet", width_mm: 600, height_mm: 337.5, res_x: 192, res_y: 108 },
  { name: "640 × 480 mm — Classic Rental", width_mm: 640, height_mm: 480, res_x: 160, res_y: 120 },
  { name: "960 × 960 mm — Large Format", width_mm: 960, height_mm: 960, res_x: 240, res_y: 240 },
];

export const ORDERS: { id: ScreenOrder; name: string }[] = [
  { id: "lr-tb", name: "Left → Right (raster)" },
  { id: "rl-tb", name: "Right → Left (raster)" },
  { id: "tb-lr", name: "Top → Bottom (columns)" },
  { id: "bt-lr", name: "Bottom → Top (columns)" },
  { id: "serpentine", name: "Serpentine (S-curve)" },
  { id: "custom", name: "Custom (click to patch)" },
];
