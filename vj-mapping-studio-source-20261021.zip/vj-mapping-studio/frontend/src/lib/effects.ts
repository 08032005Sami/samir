// Data-driven Border FX catalog. Each effect is a contour sampler: given a position
// along the path (u), time phase and parameters it returns the per-segment color /
// alpha / width / glow. Adding a new effect = adding one entry — plugin-like.

import type { EffectInstance } from "./types";
import { clamp, fract, hash1 } from "./format";

export interface SegSample {
  a: number; // alpha 0..1
  w: number; // width multiplier
  glow: number; // glow multiplier
  mix?: number; // color→color2 blend when useGradient
  rgb?: [number, number, number]; // explicit color (e.g. rainbow)
}

export interface SampleCtx {
  u: number; // 0..1 along path (direction already applied)
  pos: number; // temporal phase 0..1
  i: number; // segment index
  n: number; // segment count
  fx: EffectInstance;
  seed: number;
}

export interface EffectDef {
  id: string;
  name: string;
  category: string;
  defaults: Partial<EffectInstance>;
  sample: (c: SampleCtx) => SegSample;
}

// ---------------------------------------------------------------- color utils
export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const v = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(v.slice(0, 6) || "000000", 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgbToHex(r: number, g: number, b: number): string {
  const c = (v: number) => clamp(Math.round(v), 0, 255).toString(16).padStart(2, "0");
  return `#${c(r)}${c(g)}${c(b)}`;
}

export function lerpHex(a: string, b: string, t: number): string {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  return rgbToHex(r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t);
}

export function hslToRgb(h: number, s: number, l: number): [number, number, number] {
  const c = (1 - Math.abs(2 * l - 1)) * s;
  const hp = (((h % 360) + 360) % 360) / 60;
  const x = c * (1 - Math.abs((hp % 2) - 1));
  let rgb: [number, number, number];
  if (hp < 1) rgb = [c, x, 0];
  else if (hp < 2) rgb = [x, c, 0];
  else if (hp < 3) rgb = [0, c, x];
  else if (hp < 4) rgb = [0, x, c];
  else if (hp < 5) rgb = [x, 0, c];
  else rgb = [c, 0, x];
  const m = l - c / 2;
  return [(rgb[0] + m) * 255, (rgb[1] + m) * 255, (rgb[2] + m) * 255];
}

function mixWhite(rgb: [number, number, number], t: number): [number, number, number] {
  return [rgb[0] + (255 - rgb[0]) * t, rgb[1] + (255 - rgb[1]) * t, rgb[2] + (255 - rgb[2]) * t];
}

// ---------------------------------------------------------------- catalog
const base = {
  enabled: true,
  speed: 0.35,
  length: 0.25,
  start: 0,
  direction: 1 as const,
  glow: 14,
  intensity: 1,
  color: "#00F0FF",
  color2: "#FF007F",
  useGradient: false,
  phase: 0,
  offset: 0,
  loop: true,
  params: {} as Record<string, number>,
};

export const EFFECT_CATALOG: EffectDef[] = [
  {
    id: "traveling_light",
    name: "Traveling Light",
    category: "Chase",
    defaults: { speed: 0.4, length: 0.3, color: "#00F0FF", glow: 16 },
    sample: ({ u, pos, fx }) => {
      const d = fract(u - pos);
      const len = Math.max(0.02, fx.length);
      if (d >= len) return { a: 0, w: 1, glow: 0 };
      const t = 1 - d / len;
      return { a: Math.pow(t, 1.4) * fx.intensity, w: 1 + t * 0.35, glow: t, mix: t };
    },
  },
  {
    id: "chase_segmented",
    name: "Segmented Chase",
    category: "Chase",
    defaults: { speed: 0.8, length: 0.5, color: "#00F0FF", params: { blocks: 10 } },
    sample: ({ u, pos, fx }) => {
      const blocks = Math.max(2, Math.round(fx.params.blocks ?? 10));
      const seg = Math.floor(u * blocks);
      const k = Math.floor(pos * blocks);
      const lit = (((seg - k) % blocks) + blocks) % blocks < Math.max(1, Math.round(blocks * fx.length));
      return { a: lit ? fx.intensity : 0.05, w: 1, glow: lit ? 1 : 0, mix: seg / blocks };
    },
  },
  {
    id: "neon_glow_pulse",
    name: "Neon Breathing Glow",
    category: "Glow",
    defaults: { speed: 0.5, glow: 24, color: "#FF007F" },
    sample: ({ pos }) => {
      const p = 0.68 + 0.32 * Math.sin(pos * Math.PI * 2);
      return { a: p, w: 1 + (1 - p) * 0.4, glow: 1.25 - p * 0.5 };
    },
  },
  {
    id: "comet_tail",
    name: "Comet with Decay Tail",
    category: "Kinetic",
    defaults: { speed: 0.3, length: 0.4, color: "#FFFFFF", color2: "#00F0FF", useGradient: true },
    sample: ({ u, pos, fx }) => {
      const d = fract(u - pos);
      const len = Math.max(0.02, fx.length);
      if (d >= len) return { a: 0, w: 1, glow: 0 };
      const t = 1 - d / len;
      const core = t > 0.85 ? 1 : 0;
      return { a: Math.pow(t, 2.6) * fx.intensity, w: 0.7 + t * 1.1, glow: t, mix: core ? 1 : t, rgb: core ? [255, 255, 255] : undefined };
    },
  },
  {
    id: "optical_scanner",
    name: "Cylon / Optical Scanner",
    category: "Kinetic",
    defaults: { speed: 0.6, length: 0.12, color: "#FF3366", glow: 20 },
    sample: ({ u, pos, fx }) => {
      const p = pos < 0.5 ? pos * 2 : 2 - pos * 2;
      const d = Math.abs(u - p);
      const sharp = Math.max(0, 1 - d / Math.max(0.01, fx.length * 0.5));
      return { a: Math.pow(sharp, 2.2) * fx.intensity, w: 1 + sharp * 0.5, glow: sharp };
    },
  },
  {
    id: "strobe_flash",
    name: "Strobe & Impact Flash",
    category: "Dynamic",
    defaults: { speed: 1, color: "#FFFFFF", params: { rate: 10, duty: 0.4 } },
    sample: ({ pos, fx }) => {
      const rate = Math.max(1, fx.params.rate ?? 10);
      const duty = clamp(fx.params.duty ?? 0.4, 0.02, 0.95);
      const on = fract(pos * rate) < duty;
      return { a: on ? fx.intensity : 0.03, w: 1, glow: on ? 1 : 0 };
    },
  },
  {
    id: "rainbow_cycle",
    name: "Chromatic Rainbow Cycle",
    category: "Color",
    defaults: { speed: 0.25, glow: 18 },
    sample: ({ u, pos }) => {
      const hue = (u * 360 * 1.2 + pos * 360) % 360;
      return { a: 1, w: 1, glow: 1, rgb: hslToRgb(hue, 1, 0.55) };
    },
  },
  {
    id: "duotone_gradient_sweep",
    name: "Duotone Gradient Sweep",
    category: "Color",
    defaults: { speed: 0.3, useGradient: true, color: "#00F0FF", color2: "#7C4DFF" },
    sample: ({ u, pos }) => {
      const g = fract(u - pos);
      return { a: (0.55 + 0.45 * Math.sin(g * Math.PI)) * 1, w: 1, glow: 0.7, mix: g };
    },
  },
  {
    id: "wave_travel",
    name: "Sine Wave Energy",
    category: "Wave",
    defaults: { speed: 0.5, color: "#00FFA3", params: { waves: 4 } },
    sample: ({ u, pos, fx }) => {
      const waves = Math.max(1, fx.params.waves ?? 4);
      const v = Math.sin((u * waves - pos) * Math.PI * 2);
      const a = 0.1 + 0.9 * Math.pow(Math.max(0, v), 3);
      return { a: a * fx.intensity, w: 1 + a * 0.3, glow: a, mix: u };
    },
  },
  {
    id: "sparkle_glitch",
    name: "Digital Sparkle / Glitch",
    category: "Noise",
    defaults: { speed: 1.2, color: "#00F0FF", color2: "#FFFFFF", params: { rate: 14 } },
    sample: ({ u, pos, i, fx, seed }) => {
      const rate = Math.max(1, fx.params.rate ?? 14);
      const n = hash1(i * 7.13 + Math.floor(pos * rate) * 91.7 + seed + u * 33.7);
      const a = n > 0.86 ? 1 : n > 0.72 ? 0.35 : 0.05;
      return { a: a * fx.intensity, w: 1, glow: n > 0.86 ? 1 : 0, mix: n };
    },
  },
  {
    id: "perimeter_fill_drain",
    name: "Perimeter Fill & Drain",
    category: "Fill",
    defaults: { speed: 0.25, color: "#00F0FF" },
    sample: ({ u, pos, fx }) => {
      const f = pos < 0.5 ? pos * 2 : (1 - pos) * 2;
      const d = fract(u - fx.start);
      const on = d < f;
      return { a: on ? fx.intensity : 0.05, w: 1, glow: on ? 1 : 0, mix: d / Math.max(0.001, f) };
    },
  },
  {
    id: "directional_laser",
    name: "Quad Laser Sweep",
    category: "Laser",
    defaults: { speed: 0.7, length: 0.08, color: "#FF3366", glow: 22 },
    sample: ({ u, pos, fx }) => {
      const p1 = pos;
      const p2 = fract(pos + 0.5);
      const cyc = (x: number) => Math.min(fract(x), 1 - fract(x));
      const d = Math.min(cyc(u - p1), cyc(u - p2));
      const sharp = Math.max(0, 1 - d / Math.max(0.01, fx.length * 0.35));
      return { a: Math.pow(sharp, 1.8) * fx.intensity, w: 1 + sharp * 0.6, glow: sharp };
    },
  },
  {
    id: "audio_reactive_pulse",
    name: "Audio Vibe Pulse (BPM)",
    category: "Pulse",
    defaults: { speed: 1, color: "#FFB800", params: { bpm: 128 } },
    sample: ({ pos, fx }) => {
      const bpm = Math.max(40, fx.params.bpm ?? 128);
      const beat = fract(pos * (bpm / 60));
      const a = Math.pow(1 - beat, 3);
      return { a: a * fx.intensity, w: 1 + (1 - beat) * 0.7, glow: a };
    },
  },
  {
    id: "hypnotic_spiral",
    name: "Hypnotic Corner Flow",
    category: "Kinetic",
    defaults: { speed: 0.4, useGradient: true, color: "#7C4DFF", color2: "#00F0FF", params: { arms: 3 } },
    sample: ({ u, pos, fx }) => {
      const arms = Math.max(1, fx.params.arms ?? 3);
      const v = fract(u * arms + pos);
      return { a: Math.pow(1 - v, 2) * fx.intensity, w: 1, glow: 1 - v, mix: v };
    },
  },
  {
    id: "dotted_marquee",
    name: "Dotted Marquee Ribbon",
    category: "Marquee",
    defaults: { speed: 0.5, color: "#FFD166", params: { dots: 28 } },
    sample: ({ u, pos, fx }) => {
      const dots = Math.max(4, fx.params.dots ?? 28);
      const v = fract(u * dots + pos * 2);
      return { a: v < 0.5 ? fx.intensity : 0.1, w: 1, glow: v < 0.5 ? 1 : 0, mix: u };
    },
  },
  {
    id: "fire_ember_flow",
    name: "Fire Ember Trail",
    category: "Organic",
    defaults: { speed: 0.5, color: "#FFB800", color2: "#FF3366", useGradient: true },
    sample: ({ u, pos, i, seed }) => {
      const n = hash1(i * 3.7 + Math.floor(pos * 20) * 13.3 + seed);
      const v = fract(u + pos);
      return {
        a: (0.3 + 0.7 * Math.pow(1 - v, 1.5)) * (0.7 + 0.3 * n),
        w: 1 + n * 0.4,
        glow: 0.6 + n * 0.4,
        mix: clamp(v + n * 0.2, 0, 1),
      };
    },
  },
  {
    id: "cyber_matrix_run",
    name: "Matrix Data Stream",
    category: "Tech",
    defaults: { speed: 1.5, color: "#00FFA3", params: { dashes: 16 } },
    sample: ({ u, pos, fx }) => {
      const dashes = Math.max(4, fx.params.dashes ?? 16);
      const v = fract(u * dashes - pos * dashes);
      const on = v < 0.35;
      return { a: on ? fx.intensity : 0.05, w: 1, glow: v < 0.1 ? 1 : 0.2, mix: v };
    },
  },
  {
    id: "electric_arc",
    name: "Electric Arc Discharge",
    category: "Energy",
    defaults: { speed: 2.2, color: "#FFFFFF", color2: "#00F0FF", useGradient: true },
    sample: ({ u, pos, i, seed }) => {
      const n = hash1(i * 11.3 + Math.floor(pos * 30) * 7.7 + seed);
      const a = n > 0.5 ? 0.85 + 0.15 * n : 0.06;
      return { a, w: 0.8 + n * 0.5, glow: n, mix: n };
    },
  },
];

export function effectById(id: string): EffectDef {
  return EFFECT_CATALOG.find((e) => e.id === id) ?? EFFECT_CATALOG[0];
}

export function makeEffect(type: string): EffectInstance {
  const def = effectById(type);
  return { ...base, ...structuredClone(def.defaults), type, params: { ...(def.defaults.params ?? {}) } };
}

export const FX_CATEGORIES = Array.from(new Set(EFFECT_CATALOG.map((e) => e.category)));
