// Small formatting / misc helpers.

export function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

export function fmtNum(v: number, digits = 1): string {
  if (!Number.isFinite(v)) return "—";
  return Number(v.toFixed(digits)).toLocaleString("en-US", { maximumFractionDigits: digits });
}

export function fmtInt(v: number): string {
  return Math.round(v).toLocaleString("en-US");
}

export function fmtMp(px: number): string {
  return `${(px / 1e6).toFixed(2)} MP`;
}

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

export function nowIso(): string {
  return new Date().toISOString();
}

export function downloadBlob(blob: Blob, name: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function downloadText(text: string, name: string, type = "text/plain"): void {
  downloadBlob(new Blob([text], { type }), name);
}

export function safeFileName(name: string): string {
  const s = name.replace(/[^\w\- ]+/g, "").trim().replace(/\s+/g, "_");
  return s || "untitled";
}

export function fract(x: number): number {
  return x - Math.floor(x);
}

export function hash1(n: number): number {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}
