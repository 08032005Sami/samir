// Canvas render engine — one pure-ish scene renderer consumed by the editor viewport,
// the live preview modal and every exporter. 1 canvas px = 1 LED px.

import type { LedScreen, ProjectDoc, Shape, StageObject, Vec2 } from "./types";
import type { EditorState } from "./store";
import { contour, rotatePt, shapePath } from "./geometry";
import { buildCabinets, pxToUnitStr, screenRes } from "./led";
import { effectById, lerpHex, rgbToHex } from "./effects";
import { clamp, fract, hash1 } from "./format";

export const COL = {
  page: "#080A0E",
  canvasBg: "#05070B",
  gridMinor: "#141A26",
  gridMajor: "#1F283B",
  rulerBg: "#0E121A",
  rulerText: "#7587A6",
  guide: "#FF0055",
  accent: "#00F0FF",
  handleBorder: "#00F0FF",
  playhead: "#FF3366",
  live: "#00FFA3",
  screenBody: "rgba(13,18,29,0.94)",
  border: "#2A3550",
};

export type FrameMode = "map" | "content" | "inputmap" | "preview";

export function seedFrom(id: string): number {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  return Math.abs(h % 1000);
}

// ------------------------------------------------------------------ transforms

export function worldToScreen(view: { x: number; y: number; zoom: number }, p: Vec2): Vec2 {
  return { x: p.x * view.zoom + view.x, y: p.y * view.zoom + view.y };
}

export function screenToWorld(view: { x: number; y: number; zoom: number }, p: Vec2): Vec2 {
  return { x: (p.x - view.x) / view.zoom, y: (p.y - view.y) / view.zoom };
}

// ------------------------------------------------------------------ checkerboard

let checkerTile: HTMLCanvasElement | null = null;
function getChecker(ctx: CanvasRenderingContext2D): CanvasPattern | null {
  if (!checkerTile) {
    checkerTile = document.createElement("canvas");
    checkerTile.width = 16;
    checkerTile.height = 16;
    const c = checkerTile.getContext("2d")!;
    c.fillStyle = "#14171f";
    c.fillRect(0, 0, 16, 16);
    c.fillStyle = "#1d212b";
    c.fillRect(0, 0, 8, 8);
    c.fillRect(8, 8, 8, 8);
  }
  return ctx.createPattern(checkerTile, "repeat");
}

// ------------------------------------------------------------------ screens

export function drawScreen(ctx: CanvasRenderingContext2D, s: LedScreen, zoom: number, st: EditorState): void {
  const res = screenRes(s);
  const selected = st.selection.includes(s.id);
  ctx.save();
  ctx.translate(s.x + res.w / 2, s.y + res.h / 2);
  ctx.rotate((s.rotation * Math.PI) / 180);
  ctx.translate(-res.w / 2, -res.h / 2);

  // body
  ctx.fillStyle = COL.screenBody;
  ctx.fillRect(0, 0, res.w, res.h);

  // cabinet grid
  const cabW = res.w / s.cabsX;
  const cabH = res.h / s.cabsY;
  if (cabW * zoom >= 5) {
    ctx.strokeStyle = "rgba(0,240,255,0.16)";
    ctx.lineWidth = 1 / zoom;
    ctx.beginPath();
    for (let i = 1; i < s.cabsX; i++) {
      ctx.moveTo(i * cabW, 0);
      ctx.lineTo(i * cabW, res.h);
    }
    for (let j = 1; j < s.cabsY; j++) {
      ctx.moveTo(0, j * cabH);
      ctx.lineTo(res.w, j * cabH);
    }
    ctx.stroke();
  }

  // colored edge
  ctx.strokeStyle = s.color;
  ctx.globalAlpha = selected ? 0.95 : 0.5;
  ctx.lineWidth = (selected ? 2.5 : 1.5) / zoom;
  ctx.strokeRect(0, 0, res.w, res.h);
  ctx.globalAlpha = 1;

  // cabinet badges
  // buildCabinets returns absolute canvas coords; this context is already in screen-local space
  const localCabs = () => buildCabinets(s).map((c) => ({ ...c, x: c.x - s.x, y: c.y - s.y }));
  if (st.showBadges && cabW * zoom >= 22) {
    const cabs = localCabs();
    const bfs = Math.min(11, Math.max(7, cabW * zoom * 0.16)) / zoom;
    for (const cab of cabs) {
      ctx.fillStyle = "rgba(0,43,61,0.85)";
      ctx.fillRect(cab.x + 2 / zoom, cab.y + 2 / zoom, cabW - 4 / zoom, bfs + 6 / zoom);
      ctx.fillStyle = "#00F0FF";
      ctx.font = `700 ${bfs}px "JetBrains Mono Variable", monospace`;
      ctx.textAlign = "center";
      ctx.fillText(String(cab.number), cab.x + cabW / 2, cab.y + bfs + 4 / zoom);
      if (st.showRanges && cabH * zoom >= 46) {
        ctx.fillStyle = "rgba(240,244,252,0.62)";
        ctx.font = `400 ${bfs * 0.8}px "JetBrains Mono Variable", monospace`;
        ctx.fillText(
          `X:${cab.pxX} Y:${cab.pxY}`,
          cab.x + cabW / 2,
          cab.y + cabH - 4 / zoom,
        );
      }
    }
  }

  // cable run path
  if (st.showCable && s.cabsX * s.cabsY > 1) {
    const cabs = localCabs();
    ctx.strokeStyle = COL.guide;
    ctx.lineWidth = 1.6 / zoom;
    ctx.setLineDash([6 / zoom, 5 / zoom]);
    ctx.beginPath();
    cabs.forEach((cab, i) => {
      const cx = cab.x + cab.w / 2;
      const cy = cab.y + cab.h / 2;
      if (i === 0) ctx.moveTo(cx, cy);
      else ctx.lineTo(cx, cy);
    });
    ctx.stroke();
    ctx.setLineDash([]);
    // arrow heads + start marker
    for (let i = 0; i < cabs.length - 1; i++) {
      const a = cabs[i];
      const b = cabs[i + 1];
      const ax = a.x + a.w / 2;
      const ay = a.y + a.h / 2;
      const bx = b.x + b.w / 2;
      const by = b.y + b.h / 2;
      const ang = Math.atan2(by - ay, bx - ax);
      const r = 4 / zoom;
      ctx.fillStyle = COL.guide;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.lineTo(bx - r * Math.cos(ang - 0.4), by - r * Math.sin(ang - 0.4));
      ctx.lineTo(bx - r * Math.cos(ang + 0.4), by - r * Math.sin(ang + 0.4));
      ctx.fill();
    }
    const c0 = cabs[0];
    ctx.fillStyle = COL.live;
    ctx.beginPath();
    ctx.arc(c0.x + c0.w / 2, c0.y + c0.h / 2, 5 / zoom, 0, Math.PI * 2);
    ctx.fill();
  }

  // labels
  if (zoom > 0.08) {
    const fs = 12 / zoom;
    ctx.font = `600 ${fs}px "JetBrains Mono Variable", monospace`;
    ctx.fillStyle = "rgba(8,10,14,0.82)";
    ctx.fillRect(2 / zoom, 2 / zoom, Math.min(res.w - 4 / zoom, fs * 22), fs * 2.4 + 8 / zoom);
    ctx.fillStyle = s.color;
    ctx.textAlign = "left";
    ctx.fillText(s.name, 6 / zoom, fs + 4 / zoom);
    ctx.font = `400 ${fs * 0.82}px "JetBrains Mono Variable", monospace`;
    ctx.fillStyle = "rgba(240,244,252,0.55)";
    ctx.fillText(`${res.w}×${res.h} · ${s.cabsX}×${s.cabsY} cab · ${s.cabW}mm`, 6 / zoom, fs * 2 + 6 / zoom);
  }

  ctx.restore();

  // custom patch highlight
  if (st.customPatch === s.id) {
    const corners = [
      { x: s.x, y: s.y },
      { x: s.x + res.w, y: s.y },
      { x: s.x + res.w, y: s.y + res.h },
      { x: s.x, y: s.y + res.h },
    ].map((p) => rotatePt(p, { x: s.x + res.w / 2, y: s.y + res.h / 2 }, s.rotation));
    ctx.strokeStyle = COL.live;
    ctx.lineWidth = 2.5 / zoom;
    ctx.setLineDash([8 / zoom, 6 / zoom]);
    ctx.beginPath();
    corners.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)));
    ctx.closePath();
    ctx.stroke();
    ctx.setLineDash([]);
  }
}

// ------------------------------------------------------------------ shapes

function resolveFxColor(fx: Shape["fx"], seg: { mix?: number; rgb?: [number, number, number]; a: number }, u: number): string {
  if (seg.rgb) return rgbToHex(seg.rgb[0], seg.rgb[1], seg.rgb[2]);
  if (fx.useGradient) return lerpHex(fx.color, fx.color2, clamp(seg.mix ?? u, 0, 1));
  return fx.color;
}

export function drawShape(ctx: CanvasRenderingContext2D, s: Shape, zoom: number, t: number, selected: boolean): void {
  if (s.fill) {
    const path = shapePath(s);
    ctx.save();
    ctx.globalAlpha = s.fillOpacity * s.opacity;
    ctx.fillStyle = s.fill;
    ctx.fill(path);
    ctx.restore();
  }

  const path = shapePath(s);
  const segLen = clamp(8 / Math.max(zoom, 0.05), 6, 60);

  if (!s.fx.enabled) {
    // static stroke
    ctx.save();
    ctx.globalAlpha = s.opacity;
    ctx.strokeStyle = s.stroke;
    ctx.lineWidth = s.strokeWidth;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    if (s.dash) ctx.setLineDash(s.dash.split(/[\s,]+/).map(Number));
    ctx.shadowColor = s.stroke;
    ctx.shadowBlur = s.glow;
    ctx.stroke(path);
    ctx.restore();
    return;
  }

  const def = effectById(s.fx.type);
  const cont = contour(s, segLen);
  const nSeg = cont.closed ? cont.pts.length : cont.pts.length - 1;
  if (nSeg < 1) return;
  const seed = seedFrom(s.id);
  const pos = fract((s.fx.direction === -1 ? -1 : 1) * (t * s.fx.speed) + s.fx.phase);
  const spaceOff = s.fx.start + s.fx.offset;

  ctx.save();
  ctx.globalAlpha = s.opacity;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (s.dash) ctx.setLineDash(s.dash.split(/[\s,]+/).map(Number));

  const maxSegs = 460;
  const step = Math.max(1, Math.ceil(nSeg / maxSegs));
  for (let i = 0; i < nSeg; i += step) {
    const i2 = cont.closed ? (i + step) % cont.pts.length : Math.min(i + step, cont.pts.length - 1);
    const uRaw = (i + 0.5) / nSeg;
    const u = s.fx.direction === -1 ? fract(1 - uRaw + spaceOff) : fract(uRaw + spaceOff);
    const seg = def.sample({ u, pos, i, n: nSeg, fx: s.fx, seed });
    if (seg.a <= 0.015) continue;
    const col = resolveFxColor(s.fx, seg, u);
    const p1 = cont.pts[i];
    const p2 = cont.pts[i2];
    ctx.beginPath();
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.globalAlpha = clamp(seg.a * s.opacity, 0, 1);
    ctx.strokeStyle = col;
    ctx.lineWidth = Math.max(0.5, s.strokeWidth * seg.w);
    if (s.fx.glow > 0 && seg.glow > 0) {
      ctx.shadowColor = col;
      ctx.shadowBlur = s.fx.glow * seg.glow;
    } else {
      ctx.shadowBlur = 0;
    }
    ctx.stroke();
  }
  ctx.restore();

  if (selected) {
    ctx.save();
    ctx.strokeStyle = COL.accent;
    ctx.globalAlpha = 0.35;
    ctx.lineWidth = 1 / zoom;
    ctx.setLineDash([4 / zoom, 4 / zoom]);
    ctx.stroke(path);
    ctx.restore();
  }
}

// ------------------------------------------------------------------ stage objects

export function drawStageObject(ctx: CanvasRenderingContext2D, o: StageObject, zoom: number, selected: boolean): void {
  ctx.save();
  ctx.translate(o.x + o.w / 2, o.y + o.h / 2);
  ctx.rotate((o.rotation * Math.PI) / 180);
  ctx.translate(-o.w / 2, -o.h / 2);
  ctx.globalAlpha = 0.9;

  ctx.fillStyle = "rgba(20,26,38,0.7)";
  ctx.strokeStyle = o.color;
  ctx.lineWidth = 1.4 / zoom;
  ctx.setLineDash([5 / zoom, 4 / zoom]);
  ctx.fillRect(0, 0, o.w, o.h);
  ctx.strokeRect(0, 0, o.w, o.h);
  ctx.setLineDash([]);

  const fs = Math.min(11, Math.max(7, o.w * zoom * 0.08)) / zoom;
  ctx.font = `600 ${fs}px "JetBrains Mono Variable", monospace`;
  ctx.fillStyle = o.color;
  ctx.textAlign = "center";

  switch (o.kind) {
    case "speaker": {
      ctx.beginPath();
      ctx.arc(o.w / 2, o.h * 0.35, o.w * 0.28, 0, Math.PI * 2);
      ctx.arc(o.w / 2, o.h * 0.72, o.w * 0.16, 0, Math.PI * 2);
      ctx.stroke();
      break;
    }
    case "truss": {
      ctx.beginPath();
      const n = Math.max(2, Math.round(o.w / (24 / zoom)));
      for (let i = 0; i < n; i++) {
        ctx.moveTo((i / n) * o.w, 0);
        ctx.lineTo(((i + 1) / n) * o.w, o.h);
        ctx.moveTo(((i + 1) / n) * o.w, 0);
        ctx.lineTo((i / n) * o.w, o.h);
      }
      ctx.stroke();
      break;
    }
    case "moving-head": {
      ctx.beginPath();
      ctx.arc(o.w / 2, o.h * 0.3, o.w * 0.22, 0, Math.PI * 2);
      ctx.stroke();
      // beam
      ctx.setLineDash([3 / zoom, 4 / zoom]);
      ctx.beginPath();
      ctx.moveTo(o.w * 0.5, o.h * 0.45);
      ctx.lineTo(o.w * 0.1, o.h * 1.6);
      ctx.lineTo(o.w * 0.9, o.h * 1.6);
      ctx.closePath();
      ctx.stroke();
      ctx.setLineDash([]);
      break;
    }
    case "projector": {
      ctx.setLineDash([3 / zoom, 4 / zoom]);
      ctx.beginPath();
      ctx.moveTo(o.w * 0.5, o.h * 0.6);
      ctx.lineTo(o.w * 1.6, o.h * 1.5);
      ctx.moveTo(o.w * 0.5, o.h * 0.6);
      ctx.lineTo(o.w * -0.6, o.h * 1.5);
      ctx.stroke();
      ctx.setLineDash([]);
      break;
    }
    case "dj-booth": {
      ctx.strokeRect(o.w * 0.15, o.h * 0.2, o.w * 0.7, o.h * 0.5);
      break;
    }
    default:
      break;
  }
  ctx.fillText(o.label, o.w / 2, -4 / zoom);
  if (selected) {
    ctx.strokeStyle = COL.accent;
    ctx.setLineDash([4 / zoom, 4 / zoom]);
    ctx.strokeRect(-2 / zoom, -2 / zoom, o.w + 4 / zoom, o.h + 4 / zoom);
  }
  ctx.restore();
}

// ------------------------------------------------------------------ selection handles

export interface Handles {
  cx: number;
  cy: number;
  rot: Vec2;
  pts: Record<string, Vec2>;
}

export function computeHandles(st: EditorState): Handles | null {
  const items: { x: number; y: number; w: number; h: number; rotation: number; id: string }[] = [];
  for (const id of st.selection) {
    const sc = st.doc.screens.find((x) => x.id === id);
    if (sc) {
      const r = screenRes(sc);
      items.push({ x: sc.x, y: sc.y, w: r.w, h: r.h, rotation: sc.rotation, id });
      continue;
    }
    const sh = st.doc.shapes.find((x) => x.id === id);
    if (sh) items.push({ x: sh.x, y: sh.y, w: sh.w, h: sh.h, rotation: sh.rotation, id });
    const so = st.doc.stage.find((x) => x.id === id);
    if (so) items.push({ x: so.x, y: so.y, w: so.w, h: so.h, rotation: so.rotation, id });
  }
  if (!items.length) return null;
  let x0 = Infinity;
  let y0 = Infinity;
  let x1 = -Infinity;
  let y1 = -Infinity;
  for (const it of items) {
    const c = { x: it.x + it.w / 2, y: it.y + it.h / 2 };
    for (const p of [
      { x: it.x, y: it.y },
      { x: it.x + it.w, y: it.y },
      { x: it.x + it.w, y: it.y + it.h },
      { x: it.x, y: it.y + it.h },
    ]) {
      const q = rotatePt(p, c, it.rotation);
      x0 = Math.min(x0, q.x);
      y0 = Math.min(y0, q.y);
      x1 = Math.max(x1, q.x);
      y1 = Math.max(y1, q.y);
    }
  }
  const v = st.view;
  const s = (p: Vec2) => worldToScreen(v, p);
  const corners = {
    nw: s({ x: x0, y: y0 }),
    n: s({ x: (x0 + x1) / 2, y: y0 }),
    ne: s({ x: x1, y: y0 }),
    e: s({ x: x1, y: (y0 + y1) / 2 }),
    se: s({ x: x1, y: y1 }),
    s: s({ x: (x0 + x1) / 2, y: y1 }),
    sw: s({ x: x0, y: y1 }),
    w: s({ x: x0, y: (y0 + y1) / 2 }),
  };
  const cxs = s({ x: (x0 + x1) / 2, y: (y0 + y1) / 2 });
  return { cx: cxs.x, cy: cxs.y, rot: { x: corners.n.x, y: corners.n.y - 26 }, pts: corners };
}

export const HANDLE_KEYS = ["nw", "n", "ne", "e", "se", "s", "sw", "w"] as const;

export function hitHandle(h: Handles | null, p: Vec2, tol = 7): string | null {
  if (!h) return null;
  if (Math.hypot(h.rot.x - p.x, h.rot.y - p.y) <= tol + 3) return "rot";
  for (const k of HANDLE_KEYS) {
    if (Math.hypot(h.pts[k].x - p.x, h.pts[k].y - p.y) <= tol) return k;
  }
  return null;
}

// ------------------------------------------------------------------ scene

export interface RenderOpts {
  drawOverlay?: (ctx: CanvasRenderingContext2D) => void; // screen-space extras (previews)
}

export function renderScene(ctx: CanvasRenderingContext2D, vw: number, vh: number, st: EditorState, opts?: RenderOpts): void {
  const { doc, view } = st;
  const zoom = view.zoom;
  ctx.save();
  ctx.fillStyle = COL.page;
  ctx.fillRect(0, 0, vw, vh);

  // canvas area
  const cw = doc.canvas.width * zoom;
  const chh = doc.canvas.height * zoom;
  ctx.save();
  ctx.translate(view.x, view.y);

  if (doc.canvas.background === "transparent" || st.checkerboard) {
    const pat = getChecker(ctx);
    if (pat) {
      ctx.fillStyle = pat;
      ctx.fillRect(0, 0, cw, chh);
    }
  } else {
    ctx.fillStyle = doc.canvas.background;
    ctx.fillRect(0, 0, cw, chh);
  }

  // subtle canvas shadow
  ctx.shadowColor = "rgba(0,0,0,0.55)";
  ctx.shadowBlur = 30;
  ctx.strokeStyle = COL.border;
  ctx.lineWidth = 1;
  ctx.strokeRect(0, 0, cw, chh);
  ctx.shadowBlur = 0;

  // reference template image (PNG/JPG), stretched to canvas
  if (st.refImage) {
    ctx.save();
    ctx.globalAlpha = st.refOpacity;
    ctx.drawImage(st.refImage, 0, 0, cw, chh);
    ctx.restore();
  }

  // grid
  if (st.showGrid) {
    const step = st.gridSize;
    if (step * zoom >= 5) {
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.strokeStyle = COL.gridMinor;
      for (let x = 0; x <= doc.canvas.width; x += step) {
        ctx.moveTo(x * zoom, 0);
        ctx.lineTo(x * zoom, chh);
      }
      for (let y = 0; y <= doc.canvas.height; y += step) {
        ctx.moveTo(0, y * zoom);
        ctx.lineTo(cw, y * zoom);
      }
      ctx.stroke();
      ctx.strokeStyle = COL.gridMajor;
      ctx.beginPath();
      for (let x = 0; x <= doc.canvas.width; x += step * 8) {
        ctx.moveTo(x * zoom, 0);
        ctx.lineTo(x * zoom, chh);
      }
      for (let y = 0; y <= doc.canvas.height; y += step * 8) {
        ctx.moveTo(0, y * zoom);
        ctx.lineTo(cw, y * zoom);
      }
      ctx.stroke();
    }
  }

  // safe areas
  if (st.showSafe) {
    const pct = st.safePct / 100;
    ctx.strokeStyle = COL.guide;
    ctx.globalAlpha = 0.55;
    ctx.setLineDash([6 / zoom, 5 / zoom]);
    ctx.lineWidth = 1.2 / zoom;
    ctx.strokeRect(cw * pct, chh * pct, cw * (1 - 2 * pct), chh * (1 - 2 * pct));
    ctx.setLineDash([]);
    ctx.globalAlpha = 1;
  }

  // center cross
  ctx.strokeStyle = "rgba(0,240,255,0.35)";
  ctx.lineWidth = 1 / zoom;
  ctx.beginPath();
  ctx.moveTo(cw / 2 - 14 / zoom, chh / 2);
  ctx.lineTo(cw / 2 + 14 / zoom, chh / 2);
  ctx.moveTo(cw / 2, chh / 2 - 14 / zoom);
  ctx.lineTo(cw / 2, chh / 2 + 14 / zoom);
  ctx.stroke();

  // world content
  ctx.scale(zoom, zoom);
  for (const s of doc.screens) {
    if (s.visible) drawScreen(ctx, s, zoom, st);
  }
  for (const s of doc.shapes) {
    if (s.visible) drawShape(ctx, s, zoom, st.time, st.selection.includes(s.id));
  }
  if (doc.stageMode) {
    for (const o of doc.stage) {
      if (o.visible) drawStageObject(ctx, o, zoom, st.selection.includes(o.id));
    }
  }
  ctx.restore();

  // snap guides (screen space lines across viewport)
  if (st.snapGuides) {
    ctx.strokeStyle = COL.guide;
    ctx.lineWidth = 1;
    for (const x of st.snapGuides.v) {
      const sx = x * zoom + view.x;
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx, vh);
      ctx.stroke();
    }
    for (const y of st.snapGuides.h) {
      const sy = y * zoom + view.y;
      ctx.beginPath();
      ctx.moveTo(0, sy);
      ctx.lineTo(vw, sy);
      ctx.stroke();
    }
  }

  // marquee
  if (st.marquee) {
    const x = Math.min(st.marquee.x0, st.marquee.x1);
    const y = Math.min(st.marquee.y0, st.marquee.y1);
    const w = Math.abs(st.marquee.x1 - st.marquee.x0);
    const h = Math.abs(st.marquee.y1 - st.marquee.y0);
    ctx.fillStyle = "rgba(0,240,255,0.08)";
    ctx.strokeStyle = COL.accent;
    ctx.fillRect(x, y, w, h);
    ctx.strokeRect(x, y, w, h);
  }

  // selection handles
  const handles = computeHandles(st);
  if (handles && !st.marquee) {
    ctx.strokeStyle = COL.handleBorder;
    ctx.lineWidth = 1;
    const { pts } = handles;
    ctx.beginPath();
    ctx.moveTo(pts.nw.x, pts.nw.y);
    ctx.lineTo(pts.ne.x, pts.ne.y);
    ctx.lineTo(pts.se.x, pts.se.y);
    ctx.lineTo(pts.sw.x, pts.sw.y);
    ctx.closePath();
    ctx.stroke();
    for (const k of HANDLE_KEYS) {
      const p = pts[k];
      ctx.fillStyle = "#0B0D13";
      ctx.fillRect(p.x - 3.5, p.y - 3.5, 7, 7);
      ctx.strokeRect(p.x - 3.5, p.y - 3.5, 7, 7);
    }
    // rotate handle
    ctx.beginPath();
    ctx.moveTo(pts.n.x, pts.n.y);
    ctx.lineTo(handles.rot.x, handles.rot.y);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(handles.rot.x, handles.rot.y, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = COL.handleBorder;
    ctx.fill();
  }

  opts?.drawOverlay?.(ctx);
  ctx.restore();
}

// ------------------------------------------------------------------ export / preview frames

/** Content-only frame (screens optionally included) at arbitrary output size. */
export function renderFrame(
  ctx: CanvasRenderingContext2D,
  doc: ProjectDoc,
  W: number,
  H: number,
  t: number,
  mode: FrameMode,
  checkerboard = false,
): void {
  ctx.save();
  ctx.clearRect(0, 0, W, H);
  const k = W / doc.canvas.width;
  if (mode !== "content") {
    if (mode === "inputmap") {
      ctx.fillStyle = "#0B0D13";
    } else if (doc.canvas.background === "transparent" || checkerboard) {
      const pat = getChecker(ctx);
      if (pat) {
        ctx.fillStyle = pat;
        ctx.fillRect(0, 0, W, H);
      }
    } else {
      ctx.fillStyle = doc.canvas.background;
    }
    ctx.fillRect(0, 0, W, H);
  }
  ctx.scale(k, k);
  const cw = doc.canvas.width;
  const chh = doc.canvas.height;

  if (mode === "inputmap") {
    const hues = ["#00F0FF", "#FF007F", "#00FFA3", "#FFB800", "#7C4DFF", "#FF3366"];
    doc.screens.forEach((s, i) => {
      const res = screenRes(s);
      const c = { x: s.x + res.w / 2, y: s.y + res.h / 2 };
      ctx.save();
      ctx.translate(c.x, c.y);
      ctx.rotate((s.rotation * Math.PI) / 180);
      ctx.translate(-res.w / 2, -res.h / 2);
      ctx.fillStyle = `${hues[i % hues.length]}26`;
      ctx.fillRect(0, 0, res.w, res.h);
      ctx.strokeStyle = hues[i % hues.length];
      ctx.lineWidth = 4;
      ctx.strokeRect(0, 0, res.w, res.h);
      ctx.fillStyle = hues[i % hues.length];
      ctx.font = `700 ${Math.max(18, res.w * 0.05)}px "JetBrains Mono Variable", monospace`;
      ctx.textAlign = "center";
      ctx.fillText(s.name, res.w / 2, res.h / 2 - res.h * 0.02);
      ctx.font = `500 ${Math.max(14, res.w * 0.035)}px "JetBrains Mono Variable", monospace`;
      ctx.fillStyle = "rgba(240,244,252,0.75)";
      ctx.fillText(`${res.w}×${res.h}px`, res.w / 2, res.h / 2 + res.h * 0.08);
      ctx.restore();
    });
  } else {
    if (mode !== "content") {
      for (const s of doc.screens) {
        if (s.visible) drawScreen(ctx, s, k, { ...emptyStateFor(doc), showBadges: true, showRanges: false, showCable: false } as EditorState);
      }
    }
    for (const s of doc.shapes) {
      if (s.visible) drawShape(ctx, s, k, t, false);
    }
  }
  void cw;
  void chh;
  ctx.restore();
}

function emptyStateFor(doc: ProjectDoc): Partial<EditorState> {
  return {
    doc,
    selection: [],
    showBadges: false,
    showRanges: false,
    showCable: false,
    customPatch: null,
  } as unknown as Partial<EditorState>;
}

// ------------------------------------------------------------------ rulers

export function drawRulerH(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  st: EditorState,
): void {
  const { view, doc } = st;
  ctx.fillStyle = COL.rulerBg;
  ctx.fillRect(0, 0, w, h);
  const pitch = 3.91;
  // choose a world-px step with comfortable screen spacing
  let step = 1;
  const target = 72; // px between major ticks
  while (step * view.zoom < target) step *= 2;
  ctx.strokeStyle = COL.rulerText;
  ctx.fillStyle = COL.rulerText;
  ctx.font = '10px "JetBrains Mono Variable", monospace';
  ctx.textAlign = "left";
  ctx.lineWidth = 1;
  const startWorld = Math.floor((-view.x / view.zoom) / step) * step;
  const endWorld = ((w - view.x) / view.zoom);
  for (let x = startWorld; x <= endWorld; x += step) {
    const sx = x * view.zoom + view.x;
    const major = Math.abs(x % (step * 4)) < 1e-6;
    ctx.globalAlpha = major ? 0.9 : 0.4;
    ctx.beginPath();
    ctx.moveTo(sx, h - (major ? 12 : 6));
    ctx.lineTo(sx, h);
    ctx.stroke();
    if (major) ctx.fillText(pxToUnitStr(x, st.units, pitch), sx + 3, 10);
  }
  // canvas extent
  const cx0 = view.x;
  const cx1 = doc.canvas.width * view.zoom + view.x;
  ctx.globalAlpha = 1;
  ctx.strokeStyle = COL.accent;
  ctx.beginPath();
  ctx.moveTo(cx0, h - 3);
  ctx.lineTo(cx1, h - 3);
  ctx.stroke();
  // cursor tick
  if (st.cursor) {
    const sx = st.cursor.x * view.zoom + view.x;
    ctx.strokeStyle = COL.guide;
    ctx.beginPath();
    ctx.moveTo(sx, 0);
    ctx.lineTo(sx, h);
    ctx.stroke();
  }
}

export function drawRulerV(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  st: EditorState,
): void {
  const { view, doc } = st;
  ctx.fillStyle = COL.rulerBg;
  ctx.fillRect(0, 0, w, h);
  const pitch = 3.91;
  let step = 1;
  const target = 72;
  while (step * view.zoom < target) step *= 2;
  ctx.strokeStyle = COL.rulerText;
  ctx.fillStyle = COL.rulerText;
  ctx.font = '10px "JetBrains Mono Variable", monospace';
  ctx.textAlign = "left";
  const startWorld = Math.floor((-view.y / view.zoom) / step) * step;
  const endWorld = (h - view.y) / view.zoom;
  for (let y = startWorld; y <= endWorld; y += step) {
    const sy = y * view.zoom + view.y;
    const major = Math.abs(y % (step * 4)) < 1e-6;
    ctx.globalAlpha = major ? 0.9 : 0.4;
    ctx.beginPath();
    ctx.moveTo(w - (major ? 12 : 6), sy);
    ctx.lineTo(w, sy);
    ctx.stroke();
    if (major) {
      ctx.save();
      ctx.translate(10, sy + 3);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText(pxToUnitStr(y, st.units, pitch), 0, 0);
      ctx.restore();
    }
  }
  const cy0 = view.y;
  const cy1 = doc.canvas.height * view.zoom + view.y;
  ctx.globalAlpha = 1;
  ctx.strokeStyle = COL.accent;
  ctx.beginPath();
  ctx.moveTo(w - 3, cy0);
  ctx.lineTo(w - 3, cy1);
  ctx.stroke();
  if (st.cursor) {
    const sy = st.cursor.y * view.zoom + view.y;
    ctx.strokeStyle = COL.guide;
    ctx.beginPath();
    ctx.moveTo(0, sy);
    ctx.lineTo(w, sy);
    ctx.stroke();
  }
}

export { hash1 };
