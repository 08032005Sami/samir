// Editor store: an external observable state consumed via useSyncExternalStore.
// The canvas render loop reads getState() directly (no React re-render per frame);
// UI panels subscribe surgically through useEditor(selector).

import { useSyncExternalStore } from "react";
import type {
  CanvasConfig,
  EffectInstance,
  LedScreen,
  ProjectDoc,
  ScreenOrder,
  Shape,
  ShapeKind,
  StageKind,
  StageObject,
  ToolId,
  Units,
} from "./types";
import { defaultProject, mkScreen, mkShape, mkStage } from "./project";
import { uid, nowIso } from "./format";
import { screenRes } from "./led";

export interface ViewState {
  x: number; // screen px of world origin
  y: number;
  zoom: number; // screen px per canvas px
}

export interface CursorInfo {
  gx: number;
  gy: number;
  screenName: string | null;
  screenId: string | null;
  cabinet: number | null;
  lx: number;
  ly: number;
}

export interface SnapGuides {
  v: number[]; // world x lines
  h: number[]; // world y lines
}

export interface ExportRunState {
  running: boolean;
  format: string;
  frame: number;
  frames: number;
  estMb: number | null;
  cancelRequested: boolean;
}

export interface EditorState {
  doc: ProjectDoc;
  selection: string[];
  tool: ToolId;
  view: ViewState;
  time: number;
  playing: boolean;
  loop: boolean;
  speed: number;
  showGrid: boolean;
  showRulers: boolean;
  showSafe: boolean;
  safePct: number;
  showBadges: boolean;
  showRanges: boolean;
  showCable: boolean;
  checkerboard: boolean;
  units: Units;
  snapGrid: boolean;
  snapScreens: boolean;
  smartGuides: boolean;
  gridSize: number;
  editPoints: boolean;
  customPatch: string | null;
  bpm: number;
  taps: number[];
  beatsPerCycle: number;
  refImage: HTMLImageElement | null;
  refOpacity: number;
  importTemplateRequest: number;
  importCsvRequest: number;
  cursor: { x: number; y: number } | null;
  cursorInfo: CursorInfo | null;
  snapGuides: SnapGuides | null;
  marquee: { x0: number; y0: number; x1: number; y1: number } | null;
  clipboard: { screens: LedScreen[]; shapes: Shape[]; stage: StageObject[] } | null;
  past: string[];
  future: string[];
  dirty: boolean;
  lastCalcCab: { w: number; h: number; resX: number; resY: number } | null;
  exportRun: ExportRunState | null;
  // UI / dialogs
  activeInspector: "calc" | "inspect" | "fx" | "layers" | "templates";
  exportOpen: boolean;
  reportOpen: boolean;
  shortcutsOpen: boolean;
  cabinetOpen: boolean;
  previewOpen: boolean;
  toolsOpen: boolean;
  presetsOpen: boolean;
  openRequest: number;
  importSvgRequest: number;
  inspectorOpen: boolean; // mobile/tablet drawer
  fpsMeter: number;
}

function initialState(): EditorState {
  return {
    doc: defaultProject(),
    selection: [],
    tool: "select",
    view: { x: 120, y: 90, zoom: 0.18 },
    time: 0,
    playing: true,
    loop: true,
    speed: 1,
    showGrid: true,
    showRulers: true,
    showSafe: false,
    safePct: 5,
    showBadges: true,
    showRanges: false,
    showCable: false,
    checkerboard: false,
    units: "px",
    snapGrid: true,
    snapScreens: true,
    smartGuides: true,
    gridSize: 64,
    editPoints: false,
    customPatch: null,
    bpm: 128,
    taps: [],
    beatsPerCycle: 4,
    refImage: null,
    refOpacity: 0.5,
    importTemplateRequest: 0,
    importCsvRequest: 0,
    cursor: null,
    cursorInfo: null,
    snapGuides: null,
    marquee: null,
    clipboard: null,
    past: [],
    future: [],
    dirty: false,
    lastCalcCab: null,
    exportRun: null,
    activeInspector: "calc",
    exportOpen: false,
    reportOpen: false,
    shortcutsOpen: false,
    cabinetOpen: false,
    previewOpen: false,
    toolsOpen: false,
    presetsOpen: false,
    openRequest: 0,
    importSvgRequest: 0,
    inspectorOpen: false,
    fpsMeter: 0,
  };
}

type Listener = () => void;
const listeners = new Set<Listener>();
let state: EditorState = initialState();

function emit(): void {
  listeners.forEach((l) => l());
}

export const store = {
  get: (): EditorState => state,
  set(patch: Partial<EditorState> | ((s: EditorState) => Partial<EditorState>)): void {
    state = { ...state, ...(typeof patch === "function" ? patch(state) : patch) };
    emit();
  },
  subscribe(l: Listener): () => void {
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  },
};

export function useEditor<T>(sel: (s: EditorState) => T): T {
  return useSyncExternalStore(store.subscribe, () => sel(store.get()));
}

// ------------------------------------------------------------------ history

const HISTORY_CAP = 80;

export function pushHistory(): void {
  store.set((s) => ({ past: [...s.past.slice(-(HISTORY_CAP - 1)), JSON.stringify(s.doc)], future: [] }));
}

export function undo(): void {
  store.set((s) => {
    if (!s.past.length) return {};
    const prev = s.past[s.past.length - 1];
    return {
      doc: JSON.parse(prev) as ProjectDoc,
      past: s.past.slice(0, -1),
      future: [JSON.stringify(s.doc), ...s.future].slice(0, HISTORY_CAP),
      dirty: true,
      editPoints: false,
    };
  });
}

export function redo(): void {
  store.set((s) => {
    if (!s.future.length) return {};
    const next = s.future[0];
    return {
      doc: JSON.parse(next) as ProjectDoc,
      past: [...s.past.slice(-(HISTORY_CAP - 1)), JSON.stringify(s.doc)],
      future: s.future.slice(1),
      dirty: true,
      editPoints: false,
    };
  });
}

export function setDoc(doc: ProjectDoc, history = true): void {
  store.set((s) => ({
    doc,
    dirty: true,
    past: history ? [...s.past.slice(-(HISTORY_CAP - 1)), JSON.stringify(s.doc)] : s.past,
    future: history ? [] : s.future,
  }));
}

/** Replace the whole doc (open / template) and reset view to fit. */
export function loadDoc(doc: ProjectDoc): void {
  store.set((s) => ({
    doc,
    selection: [],
    past: [],
    future: [],
    dirty: false,
    time: 0,
    editPoints: false,
    marquee: null,
    view: s.view,
  }));
  requestAnimationFrame(() => fitAll());
}

// ------------------------------------------------------------------ tools & view

export function setTool(tool: ToolId): void {
  store.set({ tool, editPoints: false });
}

export function setView(view: Partial<ViewState>): void {
  store.set((s) => ({ view: { ...s.view, ...view } }));
}

export function zoomAt(screenX: number, screenY: number, factor: number): void {
  store.set((s) => {
    const zoom = Math.min(40, Math.max(0.02, s.view.zoom * factor));
    const k = zoom / s.view.zoom;
    return { view: { zoom, x: screenX - (screenX - s.view.x) * k, y: screenY - (screenY - s.view.y) * k } };
  });
}

export function setZoomPreset(z: number | "fit" | "100"): void {
  if (z === "fit") {
    fitAll();
    return;
  }
  store.set((s) => {
    const rect = { w: window.innerWidth, h: window.innerHeight };
    void rect;
    const zoom = z === "100" ? 1 : z;
    // keep canvas center anchored
    const doc = s.doc;
    const cx = (doc.canvas.width / 2) * s.view.zoom + s.view.x;
    const cy = (doc.canvas.height / 2) * s.view.zoom + s.view.y;
    return { view: { zoom, x: cx - (doc.canvas.width / 2) * zoom, y: cy - (doc.canvas.height / 2) * zoom } };
  });
}

export function fitAll(): void {
  store.set((s) => {
    const el = document.getElementById("canvas-surface");
    const vw = (el?.clientWidth ?? 1200) - 60;
    const vh = (el?.clientHeight ?? 700) - 60;
    const { width, height } = s.doc.canvas;
    const zoom = Math.min(vw / width, vh / height, 4);
    return {
      view: {
        zoom,
        x: (el?.clientWidth ?? 1200) / 2 - (width / 2) * zoom,
        y: (el?.clientHeight ?? 700) / 2 - (height / 2) * zoom,
      },
    };
  });
}

export function fitSelection(): void {
  store.set((s) => {
    const boxes: { x: number; y: number; w: number; h: number }[] = [];
    for (const id of s.selection) {
      const sc = s.doc.screens.find((x) => x.id === id);
      if (sc) boxes.push({ x: sc.x, y: sc.y, w: sc.cabsX * sc.cabResX, h: sc.cabsY * sc.cabResY });
      const sh = s.doc.shapes.find((x) => x.id === id);
      if (sh) boxes.push({ x: sh.x, y: sh.y, w: sh.w, h: sh.h });
    }
    if (!boxes.length) return {};
    const x0 = Math.min(...boxes.map((b) => b.x));
    const y0 = Math.min(...boxes.map((b) => b.y));
    const x1 = Math.max(...boxes.map((b) => b.x + b.w));
    const y1 = Math.max(...boxes.map((b) => b.y + b.h));
    const el = document.getElementById("canvas-surface");
    const cw = el?.clientWidth ?? 1200;
    const ch = el?.clientHeight ?? 700;
    const zoom = Math.min(cw / Math.max(1, x1 - x0), ch / Math.max(1, y1 - y0), 4) * 0.85;
    return { view: { zoom, x: cw / 2 - ((x0 + x1) / 2) * zoom, y: ch / 2 - ((y0 + y1) / 2) * zoom } };
  });
}

// ------------------------------------------------------------------ selection

export function select(ids: string[], mode: "replace" | "toggle" | "add" = "replace"): void {
  store.set((s) => {
    if (mode === "replace") return { selection: ids };
    const set = new Set(s.selection);
    for (const id of ids) {
      if (mode === "toggle" && set.has(id)) set.delete(id);
      else set.add(id);
    }
    return { selection: Array.from(set) };
  });
}

export function selectAll(): void {
  store.set((s) => ({
    selection: [
      ...s.doc.screens.filter((x) => x.visible).map((x) => x.id),
      ...s.doc.shapes.filter((x) => x.visible).map((x) => x.id),
      ...(s.doc.stageMode ? s.doc.stage.filter((x) => x.visible).map((x) => x.id) : []),
    ],
  }));
}

export function invertSelection(): void {
  store.set((s) => {
    const all = [
      ...s.doc.screens.map((x) => x.id),
      ...s.doc.shapes.map((x) => x.id),
      ...s.doc.stage.map((x) => x.id),
    ];
    return { selection: all.filter((id) => !s.selection.includes(id)) };
  });
}

export interface SelItem {
  kind: "screen" | "shape" | "stage";
  x: number;
  y: number;
  w: number;
  h: number;
}

export function selectionItems(s: EditorState): SelItem[] {
  const out: SelItem[] = [];
  for (const id of s.selection) {
    const sc = s.doc.screens.find((x) => x.id === id);
    if (sc) {
      const r = screenRes(sc);
      out.push({ kind: "screen", x: sc.x, y: sc.y, w: r.w, h: r.h });
      continue;
    }
    const sh = s.doc.shapes.find((x) => x.id === id);
    if (sh) out.push({ kind: "shape", x: sh.x, y: sh.y, w: sh.w, h: sh.h });
    const st = s.doc.stage.find((x) => x.id === id);
    if (st) out.push({ kind: "stage", x: st.x, y: st.y, w: st.w, h: st.h });
  }
  return out;
}

// ------------------------------------------------------------------ mutations

export function patchScreen(id: string, patch: Partial<LedScreen>, history = true): void {
  if (history) pushHistory();
  store.set((s) => ({ doc: { ...s.doc, screens: s.doc.screens.map((x) => (x.id === id ? { ...x, ...patch } : x)) }, dirty: true }));
}

export function patchShape(id: string, patch: Partial<Shape>, history = true): void {
  if (history) pushHistory();
  store.set((s) => ({ doc: { ...s.doc, shapes: s.doc.shapes.map((x) => (x.id === id ? { ...x, ...patch } : x)) }, dirty: true }));
}

export function patchStage(id: string, patch: Partial<StageObject>, history = true): void {
  if (history) pushHistory();
  store.set((s) => ({ doc: { ...s.doc, stage: s.doc.stage.map((x) => (x.id === id ? { ...x, ...patch } : x)) }, dirty: true }));
}

export function patchCanvas(patch: Partial<CanvasConfig>, history = true): void {
  if (history) pushHistory();
  store.set((s) => ({ doc: { ...s.doc, canvas: { ...s.doc.canvas, ...patch } }, dirty: true }));
}

export function patchEffect(shapeId: string, patch: Partial<EffectInstance>, history = true): void {
  if (history) pushHistory();
  store.set((s) => ({
    doc: { ...s.doc, shapes: s.doc.shapes.map((x) => (x.id === shapeId ? { ...x, fx: { ...x.fx, ...patch } } : x)) },
    dirty: true,
  }));
}

export function addScreen(screen: LedScreen, select_ = true): void {
  pushHistory();
  store.set((s) => ({
    doc: { ...s.doc, screens: [...s.doc.screens, { ...screen, z: s.doc.screens.length }] },
    selection: select_ ? [screen.id] : s.selection,
    dirty: true,
  }));
}

export function addShape(shape: Shape, select_ = true): void {
  pushHistory();
  store.set((s) => ({
    doc: { ...s.doc, shapes: [...s.doc.shapes, { ...shape, z: s.doc.shapes.length }] },
    selection: select_ ? [shape.id] : s.selection,
    dirty: true,
  }));
}

export function addStageObject(kind: StageKind, x: number, y: number): void {
  pushHistory();
  const o = mkStage(kind, x, y, kind === "truss" ? 600 : 160, kind === "truss" ? 26 : 120);
  store.set((s) => ({ doc: { ...s.doc, stage: [...s.doc.stage, { ...o, z: s.doc.stage.length }] }, selection: [o.id], dirty: true, tool: "select" }));
}

export function deleteSelection(): void {
  store.set((s) => {
    if (!s.selection.length) return {};
    pushHistory();
    const sel = new Set(s.selection);
    return {
      doc: {
        ...s.doc,
        screens: s.doc.screens.filter((x) => !sel.has(x.id)),
        shapes: s.doc.shapes.filter((x) => !sel.has(x.id)),
        stage: s.doc.stage.filter((x) => !sel.has(x.id)),
      },
      selection: [],
      dirty: true,
      editPoints: false,
    };
  });
}

export function duplicateSelection(): void {
  store.set((s) => {
    if (!s.selection.length) return {};
    pushHistory();
    const newIds: string[] = [];
    const screens = [...s.doc.screens];
    const shapes = [...s.doc.shapes];
    const stage = [...s.doc.stage];
    for (const id of s.selection) {
      const sc = s.doc.screens.find((x) => x.id === id);
      if (sc) {
        const copy = { ...sc, id: uid(), x: sc.x + 64, y: sc.y + 64, name: `${sc.name} copy`, z: screens.length };
        screens.push(copy);
        newIds.push(copy.id);
      }
      const sh = s.doc.shapes.find((x) => x.id === id);
      if (sh) {
        const copy = { ...sh, id: uid(), x: sh.x + 64, y: sh.y + 64, name: `${sh.name} copy`, z: shapes.length, fx: { ...sh.fx } };
        shapes.push(copy);
        newIds.push(copy.id);
      }
      const st = s.doc.stage.find((x) => x.id === id);
      if (st) {
        const copy = { ...st, id: uid(), x: st.x + 64, y: st.y + 64, label: `${st.label} copy`, z: stage.length };
        stage.push(copy);
        newIds.push(copy.id);
      }
    }
    return { doc: { ...s.doc, screens, shapes, stage }, selection: newIds, dirty: true };
  });
}

export function copySelection(): void {
  store.set((s) => {
    if (!s.selection.length) return {};
    return {
      clipboard: {
        screens: s.doc.screens.filter((x) => s.selection.includes(x.id)).map((x) => ({ ...x })),
        shapes: s.doc.shapes.filter((x) => s.selection.includes(x.id)).map((x) => ({ ...x, fx: { ...x.fx } })),
        stage: s.doc.stage.filter((x) => s.selection.includes(x.id)).map((x) => ({ ...x })),
      },
    };
  });
}

export function pasteClipboard(): void {
  store.set((s) => {
    if (!s.clipboard) return {};
    pushHistory();
    const newIds: string[] = [];
    const screens = [...s.doc.screens];
    const shapes = [...s.doc.shapes];
    const stage = [...s.doc.stage];
    for (const sc of s.clipboard.screens) {
      const copy = { ...sc, id: uid(), x: sc.x + 64, y: sc.y + 64, z: screens.length };
      screens.push(copy);
      newIds.push(copy.id);
    }
    for (const sh of s.clipboard.shapes) {
      const copy = { ...sh, id: uid(), x: sh.x + 64, y: sh.y + 64, z: shapes.length, fx: { ...sh.fx } };
      shapes.push(copy);
      newIds.push(copy.id);
    }
    for (const st of s.clipboard.stage) {
      const copy = { ...st, id: uid(), x: st.x + 64, y: st.y + 64, z: stage.length };
      stage.push(copy);
      newIds.push(copy.id);
    }
    return { doc: { ...s.doc, screens, shapes, stage }, selection: newIds, dirty: true };
  });
}

export function nudgeSelection(dx: number, dy: number): void {
  store.set((s) => {
    if (!s.selection.length) return {};
    pushHistory();
    const sel = new Set(s.selection);
    return {
      doc: {
        ...s.doc,
        screens: s.doc.screens.map((x) => (sel.has(x.id) && !x.locked ? { ...x, x: x.x + dx, y: x.y + dy } : x)),
        shapes: s.doc.shapes.map((x) => (sel.has(x.id) && !x.locked ? { ...x, x: x.x + dx, y: x.y + dy } : x)),
        stage: s.doc.stage.map((x) => (sel.has(x.id) && !x.locked ? { ...x, x: x.x + dx, y: x.y + dy } : x)),
      },
      dirty: true,
    };
  });
}

// ------------------------------------------------------------------ align / distribute

export type AlignKind = "left" | "hcenter" | "right" | "top" | "vcenter" | "bottom";
export type DistKind = "h" | "v";

export function alignSelection(kind: AlignKind): void {
  store.set((s) => {
    const items = selectionItems(s);
    if (items.length < 2) return {};
    pushHistory();
    const x0 = Math.min(...items.map((i) => i.x));
    const y0 = Math.min(...items.map((i) => i.y));
    const x1 = Math.max(...items.map((i) => i.x + i.w));
    const y1 = Math.max(...items.map((i) => i.y + i.h));
    const sel = new Set(s.selection);
    const move = (x: number, y: number) => ({ x, y });
    const target = new Map<string, { x: number; y: number }>();
    for (const id of s.selection) {
      const it = items.find((_, idx) => s.selection[idx] === id);
      if (!it) continue;
      let nx = it.x;
      let ny = it.y;
      if (kind === "left") nx = x0;
      if (kind === "right") nx = x1 - it.w;
      if (kind === "hcenter") nx = (x0 + x1) / 2 - it.w / 2;
      if (kind === "top") ny = y0;
      if (kind === "bottom") ny = y1 - it.h;
      if (kind === "vcenter") ny = (y0 + y1) / 2 - it.h / 2;
      target.set(id, move(Math.round(nx), Math.round(ny)));
    }
    return {
      doc: {
        ...s.doc,
        screens: s.doc.screens.map((x) => (sel.has(x.id) && target.has(x.id) ? { ...x, ...target.get(x.id) } : x)),
        shapes: s.doc.shapes.map((x) => (sel.has(x.id) && target.has(x.id) ? { ...x, ...target.get(x.id) } : x)),
        stage: s.doc.stage.map((x) => (sel.has(x.id) && target.has(x.id) ? { ...x, ...target.get(x.id) } : x)),
      },
      dirty: true,
    };
  });
}

export function distributeSelection(kind: DistKind): void {
  store.set((s) => {
    const items = selectionItems(s);
    if (items.length < 3) return {};
    pushHistory();
    const sel = new Set(s.selection);
    const sorted = s.selection
      .map((id) => ({ id, it: items.find((_, idx) => s.selection[idx] === id)! }))
      .sort((a, b) => (kind === "h" ? a.it.x - b.it.x : a.it.y - b.it.y));
    const first = sorted[0].it;
    const last = sorted[sorted.length - 1].it;
    const total = kind === "h" ? last.x + last.w - first.x : last.y + last.h - first.y;
    const sum = sorted.reduce((acc, x) => acc + (kind === "h" ? x.it.w : x.it.h), 0);
    const gap = (total - sum) / (sorted.length - 1);
    const target = new Map<string, { x: number; y: number }>();
    let cur = kind === "h" ? first.x : first.y;
    for (const { id, it } of sorted) {
      target.set(id, kind === "h" ? { x: Math.round(cur), y: it.y } : { x: it.x, y: Math.round(cur) });
      cur += (kind === "h" ? it.w : it.h) + gap;
    }
    return {
      doc: {
        ...s.doc,
        screens: s.doc.screens.map((x) => (sel.has(x.id) && target.has(x.id) ? { ...x, ...target.get(x.id) } : x)),
        shapes: s.doc.shapes.map((x) => (sel.has(x.id) && target.has(x.id) ? { ...x, ...target.get(x.id) } : x)),
        stage: s.doc.stage.map((x) => (sel.has(x.id) && target.has(x.id) ? { ...x, ...target.get(x.id) } : x)),
      },
      dirty: true,
    };
  });
}

// ------------------------------------------------------------------ z-order / groups / lock

export function reorderSelection(dir: "front" | "back" | "up" | "down"): void {
  store.set((s) => {
    if (!s.selection.length) return {};
    pushHistory();
    const sel = new Set(s.selection);
    const reorder = <T extends { id: string }>(arr: T[]): T[] => {
      const picked = arr.filter((x) => sel.has(x.id));
      const rest = arr.filter((x) => !sel.has(x.id));
      if (dir === "front") return [...rest, ...picked];
      if (dir === "back") return [...picked, ...rest];
      const out = [...arr];
      const idxs = arr.map((x, i) => (sel.has(x.id) ? i : -1)).filter((i) => i >= 0);
      if (dir === "up") {
        for (let k = idxs.length - 1; k >= 0; k--) {
          const i = idxs[k];
          if (i < out.length - 1 && !sel.has(out[i + 1].id)) [out[i], out[i + 1]] = [out[i + 1], out[i]];
        }
      } else {
        for (const i of idxs) {
          if (i > 0 && !sel.has(out[i - 1].id)) [out[i], out[i - 1]] = [out[i - 1], out[i]];
        }
      }
      return out;
    };
    return { doc: { ...s.doc, screens: reorder(s.doc.screens), shapes: reorder(s.doc.shapes), stage: reorder(s.doc.stage) }, dirty: true };
  });
}

export function groupSelection(): void {
  store.set((s) => {
    if (s.selection.length < 2) return {};
    pushHistory();
    const gid = uid();
    const sel = new Set(s.selection);
    return {
      doc: {
        ...s.doc,
        screens: s.doc.screens.map((x) => (sel.has(x.id) ? { ...x, groupId: gid } : x)),
        shapes: s.doc.shapes.map((x) => (sel.has(x.id) ? { ...x, groupId: gid } : x)),
      },
      dirty: true,
    };
  });
}

export function ungroupSelection(): void {
  store.set((s) => {
    if (!s.selection.length) return {};
    pushHistory();
    const sel = new Set(s.selection);
    return {
      doc: {
        ...s.doc,
        screens: s.doc.screens.map((x) => (sel.has(x.id) ? { ...x, groupId: null } : x)),
        shapes: s.doc.shapes.map((x) => (sel.has(x.id) ? { ...x, groupId: null } : x)),
      },
      dirty: true,
    };
  });
}

export function toggleLock(id: string): void {
  store.set((s) => ({
    doc: {
      ...s.doc,
      screens: s.doc.screens.map((x) => (x.id === id ? { ...x, locked: !x.locked } : x)),
      shapes: s.doc.shapes.map((x) => (x.id === id ? { ...x, locked: !x.locked } : x)),
      stage: s.doc.stage.map((x) => (x.id === id ? { ...x, locked: !x.locked } : x)),
    },
    dirty: true,
  }));
}

export function toggleVisible(id: string): void {
  store.set((s) => ({
    doc: {
      ...s.doc,
      screens: s.doc.screens.map((x) => (x.id === id ? { ...x, visible: !x.visible } : x)),
      shapes: s.doc.shapes.map((x) => (x.id === id ? { ...x, visible: !x.visible } : x)),
      stage: s.doc.stage.map((x) => (x.id === id ? { ...x, visible: !x.visible } : x)),
    },
    dirty: true,
  }));
}

// ------------------------------------------------------------------ creation helpers

export function createShapeTool(kind: ShapeKind, x: number, y: number, w: number, h: number): Shape {
  const fxType =
    kind === "rrect" || kind === "rect" ? "traveling_light" : kind === "circle" ? "rainbow_cycle" : "comet_tail";
  const color = ["#00F0FF", "#FF007F", "#00FFA3", "#FFB800", "#7C4DFF"][Math.floor(Math.random() * 5)];
  return mkShape(kind, x, y, w, h, fxType, color);
}

export function createScreenTool(x: number, y: number, w: number, h: number, lastCab: EditorState["lastCalcCab"]): LedScreen {
  const resX = lastCab?.resX ?? 128;
  const resY = lastCab?.resY ?? 128;
  const cabsX = Math.max(1, Math.round(w / resX));
  const cabsY = Math.max(1, Math.round(h / resY));
  const colors = ["#00F0FF", "#FF007F", "#00FFA3", "#FFB800", "#7C4DFF"];
  return mkScreen(`Screen ${x.toFixed(0)},${y.toFixed(0)}`, x, y, cabsX, cabsY, {
    cabW: lastCab?.w ?? 500,
    cabH: lastCab?.h ?? 500,
    cabResX: resX,
    cabResY: resY,
    color: colors[Math.floor(Math.random() * colors.length)],
  });
}

/** Build a screen from a verified wall calculation, centered on the canvas. */
export function addScreenFromCalc(
  cabsX: number,
  cabsY: number,
  cabResX: number,
  cabResY: number,
  cabW: number,
  cabH: number,
): void {
  const w = cabsX * cabResX;
  const h = cabsY * cabResY;
  store.set((s) => {
    const x = Math.round(s.doc.canvas.width / 2 - w / 2);
    const y = Math.round(s.doc.canvas.height / 2 - h / 2);
    const screen = mkScreen(`Wall ${cabsX}×${cabsY}`, x, y, cabsX, cabsY, {
      cabResX,
      cabResY,
      cabW,
      cabH,
      color: "#00F0FF",
    });
    return {
      doc: { ...s.doc, screens: [...s.doc.screens, screen] },
      selection: [screen.id],
      lastCalcCab: { w: cabW, h: cabH, resX: cabResX, resY: cabResY },
      activeInspector: "inspect",
      dirty: true,
    };
  });
}

/** Resize the doc canvas to match total composition + center it (Smart Centering). */
export function smartCenter(): void {
  store.set((s) => {
    pushHistory();
    const boxes = [
      ...s.doc.screens.map((x) => ({ x: x.x, y: x.y, w: x.cabsX * x.cabResX, h: x.cabsY * x.cabResY })),
      ...s.doc.shapes.map((x) => ({ x: x.x, y: x.y, w: x.w, h: x.h })),
    ];
    if (!boxes.length) return {};
    const x0 = Math.min(...boxes.map((b) => b.x));
    const y0 = Math.min(...boxes.map((b) => b.y));
    const x1 = Math.max(...boxes.map((b) => b.x + b.w));
    const y1 = Math.max(...boxes.map((b) => b.y + b.h));
    const dx = Math.round(s.doc.canvas.width / 2 - (x0 + x1) / 2);
    const dy = Math.round(s.doc.canvas.height / 2 - (y0 + y1) / 2);
    const sel = new Set(s.doc.screens.map((x) => x.id));
    return {
      doc: {
        ...s.doc,
        screens: s.doc.screens.map((x) => ({ ...x, x: x.x + dx, y: x.y + dy })),
        shapes: s.doc.shapes.map((x) => ({ ...x, x: x.x + dx, y: x.y + dy })),
        stage: s.doc.stage.map((x) => ({ ...x, x: x.x + dx, y: x.y + dy })),
      },
      dirty: true,
      selection: Array.from(sel),
    };
  });
}

// ------------------------------------------------------------------ playback

export function togglePlay(): void {
  store.set((s) => ({ playing: !s.playing }));
}

export function stopPlayback(): void {
  store.set({ playing: false, time: 0 });
}

// ------------------------------------------------------------------ doc meta

export function setDocName(name: string): void {
  store.set((s) => ({ doc: { ...s.doc, name }, dirty: true }));
}

export function markSaved(): void {
  store.set({ dirty: false, doc: { ...store.get().doc, updatedAt: nowIso() } });
}

// ------------------------------------------------------------------ tap tempo / BPM sync

/** Register a tap; BPM = average interval of the last taps (resets after 2 s pause). */
export function tapTempo(now = performance.now()): number | null {
  const prev = state.taps.filter((t) => now - t < 2000);
  const taps = [...prev.slice(-7), now];
  if (taps.length < 2) {
    store.set({ taps });
    return null;
  }
  const iv = (taps[taps.length - 1] - taps[0]) / (taps.length - 1);
  const bpm = Math.round(Math.min(300, Math.max(40, 60000 / iv)) * 10) / 10;
  store.set({ taps, bpm });
  return bpm;
}

/** Lock every Border FX to the BPM: one contour cycle = beatsPerCycle beats; BPM pulse FX get the tempo;
 *  export duration snaps to whole bars so the loop is musically exact. */
export function syncFxToBpm(): void {
  pushHistory();
  store.set((s) => {
    const cps = s.bpm / 60 / Math.max(1, s.beatsPerCycle);
    const barSec = (60 / s.bpm) * 4;
    const bars = Math.max(1, Math.round(s.doc.exportSettings.duration / barSec));
    return {
      doc: {
        ...s.doc,
        shapes: s.doc.shapes.map((x) => ({
          ...x,
          fx: { ...x.fx, speed: Number(cps.toFixed(4)), params: x.fx.type === "audio_reactive_pulse" ? { ...x.fx.params, bpm: s.bpm } : x.fx.params },
        })),
        exportSettings: { ...s.doc.exportSettings, duration: Number((bars * barSec).toFixed(3)) },
      },
      time: 0,
      dirty: true,
    };
  });
}
