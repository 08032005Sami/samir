# VJ Mapping Studio — Windows Desktop Build

The Windows app is the **same code** as the web app (frontend/), wrapped in a
native Tauri 2 window (Microsoft WebView2). Installer ≈ 5–10 MB, runs fully
offline: calculator, editor, Border FX, all exports, autosave. (Only the optional
"Save to Cloud" / recent-cloud list need internet.)

## Option A — automatic (no tools on your PC)
1. Push this project to GitHub (Emergent → "Save to GitHub").
2. GitHub → **Actions** → **Windows desktop build** → **Run workflow**.
3. After ~10 min open the run → **Artifacts** → download `VJ-Mapping-Studio-Windows`.
4. Run `VJ Mapping Studio_1.0.0_x64-setup.exe`.

## Option B — build on your own Windows PC
1. Install Node.js 22, Yarn (`npm i -g yarn`), Rust (https://rustup.rs) and
   "Desktop development with C++" from Visual Studio Build Tools.
2. In a terminal:
   ```
   cd frontend && yarn install && cd ..
   cd desktop && npm install
   npm run icons
   npm run build
   ```
3. Installer: `desktop/src-tauri/target/release/bundle/nsis/*.exe` (and `.msi`).

`npm run dev` in `desktop/` opens a live-reloading desktop window for development.

## Notes
- High-DPI: the canvas engine renders at devicePixelRatio (up to 2×).
- Files (PNG, ZIP, MP4, CSV, .vjmap) save to your Downloads folder.
- Multi-monitor: open Preview → Fullscreen and drag the window to the LED/output monitor.
- Code signing is not configured; Windows SmartScreen may ask "Run anyway" on first launch.
