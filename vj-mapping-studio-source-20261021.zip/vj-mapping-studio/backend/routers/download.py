"""Source-code download: builds a fresh ZIP of the project on each request.
Secrets (.env files), dependencies, build output and tool caches are excluded."""

import io
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import StreamingResponse

router = APIRouter()

ROOT = Path(__file__).resolve().parents[2]  # /app
EXCLUDE_DIRS = {
    "node_modules", ".git", "dist", "build", "target", "__pycache__", ".venv", "venv",
    ".emergent", ".screenshots", "test_reports", ".pytest_cache", ".ruff_cache", ".mypy_cache",
}
EXCLUDE_FILES = {".env", "README.md", "TEMPLATE.md", "design_guidelines.json"}  # README replaced by PROJECT_README
EXCLUDE_SUFFIX = {".pyc", ".log", ".swp"}


def build_source_zip() -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(ROOT.rglob("*")):
            rel = path.relative_to(ROOT)
            if any(part in EXCLUDE_DIRS for part in rel.parts) or not path.is_file():
                continue
            if rel.name in EXCLUDE_FILES and len(rel.parts) == 1 or rel.name == ".env":
                continue
            if path.suffix in EXCLUDE_SUFFIX:
                continue
            arc = "README.md" if rel.as_posix() == "PROJECT_README.md" else rel.as_posix()
            zf.write(path, f"vj-mapping-studio/{arc}")
    return buf.getvalue()


@router.get("/download/source")
async def download_source() -> StreamingResponse:
    data = build_source_zip()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d")
    return StreamingResponse(
        io.BytesIO(data),
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="vj-mapping-studio-source-{stamp}.zip"'},
    )
