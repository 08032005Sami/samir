"""Reference hardware presets (cabinet catalogue + pixel pitches). Static data —
the client bundles an identical fallback so the editor works fully offline."""

from fastapi import APIRouter
from models.schemas import CabinetPreset, PitchPreset, PresetsResponse

router = APIRouter()

CABINETS = [
    CabinetPreset(name="500 × 500 mm — Standard Stage Panel", width_mm=500, height_mm=500, res_x=128, res_y=128),
    CabinetPreset(name="500 × 1000 mm — Tall Touring Panel", width_mm=500, height_mm=1000, res_x=128, res_y=256),
    CabinetPreset(name="576 × 576 mm — P3 Die-cast (192×192)", width_mm=576, height_mm=576, res_x=192, res_y=192),
    CabinetPreset(name="576 × 576 mm — P4.8 Die-cast (120×120)", width_mm=576, height_mm=576, res_x=120, res_y=120),
    CabinetPreset(name="576 × 576 mm — P6 Die-cast (96×96)", width_mm=576, height_mm=576, res_x=96, res_y=96),
    CabinetPreset(name="2 ft × 2 ft — Imperial Standard (609.6 mm)", width_mm=609.6, height_mm=609.6, res_x=156, res_y=156),
    CabinetPreset(name="1 ft × 1 ft — Mini Modular (304.8 mm)", width_mm=304.8, height_mm=304.8, res_x=78, res_y=78),
    CabinetPreset(name="600 × 337.5 mm — 16:9 HD Cabinet", width_mm=600, height_mm=337.5, res_x=192, res_y=108),
    CabinetPreset(name="640 × 480 mm — Classic Rental", width_mm=640, height_mm=480, res_x=160, res_y=120),
    CabinetPreset(name="960 × 960 mm — Large Format", width_mm=960, height_mm=960, res_x=240, res_y=240),
]

PITCHES = [
    PitchPreset(pitch_mm=1.95, desc="Ultra Fine Indoor"),
    PitchPreset(pitch_mm=2.6, desc="High-Res Stage / Broadcast"),
    PitchPreset(pitch_mm=2.97, desc="Standard Concert Touring"),
    PitchPreset(pitch_mm=3.91, desc="Outdoor / Festival High Brightness"),
    PitchPreset(pitch_mm=4.81, desc="Outdoor Touring"),
    PitchPreset(pitch_mm=5.95, desc="Large Stadium / Mesh"),
]


@router.get("/presets", response_model=PresetsResponse)
async def presets() -> PresetsResponse:
    return PresetsResponse(cabinets=CABINETS, pitches=PITCHES)
