"""LED wall / cabinet pixel calculator — server-verified mirror of src/lib/led.ts."""

import math
from fastapi import APIRouter, HTTPException
from models.schemas import CalcRequest, CalcResult

router = APIRouter()

MM_PER_UNIT = {"mm": 1.0, "cm": 10.0, "in": 25.4, "ft": 304.8, "m": 1000.0}

# Hardware estimates — clearly labelled as estimates in the UI
POWER_W_PER_M2 = 690.0        # max rating for common SMD touring panels
POWER_TYPICAL_FACTOR = 0.35   # typical VJ content load
WEIGHT_KG_PER_M2 = 35.0       # die-cast cabinet average incl. frame
PORT_PIXEL_CAPACITY = 650_000  # NovaStar MCTRL4K / Brompton class port


def _reduce(a: int, b: int) -> tuple[int, int]:
    g = math.gcd(a, b)
    return (a // g, b // g)


def compute_wall(req: CalcRequest) -> CalcResult:
    wall_w_mm = req.wall_w * MM_PER_UNIT[req.wall_unit]
    wall_h_mm = req.wall_h * MM_PER_UNIT[req.wall_unit]
    cab_w_mm = req.cab_w * MM_PER_UNIT[req.cab_unit]
    cab_h_mm = req.cab_h * MM_PER_UNIT[req.cab_unit]

    warnings: list[str] = []

    def fit(wall_mm: float, cab_mm: float, axis: str, wall_disp: str) -> int:
        exact = wall_mm / cab_mm
        n = round(exact)
        if math.isclose(exact, round(exact), rel_tol=0, abs_tol=1e-6):
            return n
        lo = math.floor(exact)
        hi = math.ceil(exact)
        lo_ft = lo * cab_mm / 304.8
        if not req.allow_partial:
            raise HTTPException(
                status_code=422,
                detail=(
                    f"Wall {axis} {wall_disp} ({wall_mm:.1f} mm) cannot be exactly divided by a "
                    f"{cab_mm:g} mm cabinet ({exact:.3f} cabinets). "
                    f"Use {lo} cabinets (wall becomes {lo_ft:.2f} ft) "
                    f"or enable 'Allow partial / custom layout'."
                ),
            )
        warnings.append(
            f"Wall {axis} is not an exact cabinet multiple — using the nearest fit of {lo} cabinets "
            f"(actual {axis} {lo * cab_mm:.1f} mm / {lo_ft:.2f} ft instead of {wall_disp})."
        )
        return lo

    wall_w_disp = f"{req.wall_w:g} {req.wall_unit}"
    wall_h_disp = f"{req.wall_h:g} {req.wall_unit}"
    cabs_x = fit(wall_w_mm, cab_w_mm, "width", wall_w_disp)
    cabs_y = fit(wall_h_mm, cab_h_mm, "height", wall_h_disp)

    canvas_w = cabs_x * req.cab_res_x
    canvas_h = cabs_y * req.cab_res_y
    total_px = canvas_w * canvas_h
    actual_w = cabs_x * cab_w_mm
    actual_h = cabs_y * cab_h_mm
    area_m2 = (actual_w / 1000) * (actual_h / 1000)

    aw, ah = _reduce(canvas_w, canvas_h)
    caw, cah = _reduce(int(round(cab_w_mm * 100)), int(round(cab_h_mm * 100)))
    pitch = cab_w_mm / req.cab_res_x
    px_per_m = req.cab_res_x / (cab_w_mm / 1000)
    px_per_m2 = px_per_m * (req.cab_res_y / (cab_h_mm / 1000))

    bandwidth = None
    if req.refresh_hz > 0:
        bandwidth = total_px * req.refresh_hz * 24 / 8 * 1.25 / 1e9

    return CalcResult(
        cabinets_x=cabs_x,
        cabinets_y=cabs_y,
        total_cabinets=cabs_x * cabs_y,
        canvas_w=canvas_w,
        canvas_h=canvas_h,
        total_pixels=total_px,
        megapixels=round(total_px / 1e6, 3),
        actual_w_mm=round(actual_w, 1),
        actual_h_mm=round(actual_h, 1),
        aspect_w=aw,
        aspect_h=ah,
        aspect_dec=round(canvas_w / canvas_h, 3),
        pixel_pitch_mm=round(pitch, 3),
        px_per_m=round(px_per_m, 1),
        px_per_m2=round(px_per_m2, 1),
        cab_aspect_w=caw,
        cab_aspect_h=cah,
        min_view_m=round(pitch, 2),
        opt_view_m=round(pitch * 2.5, 2),
        power_max_w=int(area_m2 * POWER_W_PER_M2),
        power_typical_w=int(area_m2 * POWER_W_PER_M2 * POWER_TYPICAL_FACTOR),
        weight_kg=int(area_m2 * WEIGHT_KG_PER_M2),
        sending_ports=max(1, math.ceil(total_px / PORT_PIXEL_CAPACITY)),
        bandwidth_gbps=round(bandwidth, 2) if bandwidth else None,
        warnings=warnings,
    )


@router.post("/calc/led-wall", response_model=CalcResult)
async def calc_led_wall(req: CalcRequest) -> CalcResult:
    return compute_wall(req)
