"""Project save/load (cloud recents). The .vjmap document itself is client-owned JSON —
the server stores it opaquely and indexes only the metadata it needs."""

import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
from lib.db import db
from models.schemas import (
    ProjectListResponse,
    ProjectLoadResponse,
    ProjectMeta,
    ProjectSaveRequest,
    ProjectSaveResponse,
)

router = APIRouter()


def _meta(doc_row: dict) -> ProjectMeta:
    d = doc_row.get("doc", {}) or {}
    canvas = d.get("canvas", {}) or {}
    return ProjectMeta(
        id=doc_row["id"],
        name=doc_row.get("name", "Untitled"),
        updated_at=doc_row.get("updated_at", ""),
        canvas_w=int(canvas.get("width", 0) or 0),
        canvas_h=int(canvas.get("height", 0) or 0),
        screen_count=len(d.get("screens", []) or []),
        shape_count=len(d.get("shapes", []) or []),
    )


@router.get("/projects", response_model=ProjectListResponse)
async def list_projects() -> ProjectListResponse:
    rows = await db.projects.find({}, sort=[("updated_at", -1)]).to_list(50)
    return ProjectListResponse(projects=[_meta(r) for r in rows])


@router.post("/projects", response_model=ProjectSaveResponse)
async def save_project(req: ProjectSaveRequest) -> ProjectSaveResponse:
    now = datetime.now(timezone.utc).isoformat()
    pid = req.id or str(uuid.uuid4())
    doc = dict(req.doc)
    doc["id"] = pid
    doc["name"] = req.name
    doc["updatedAt"] = now
    await db.projects.update_one(
        {"id": pid},
        {"$set": {"id": pid, "name": req.name, "updated_at": now, "doc": doc}},
        upsert=True,
    )
    return ProjectSaveResponse(id=pid, name=req.name, updated_at=now)


@router.get("/projects/{pid}", response_model=ProjectLoadResponse)
async def load_project(pid: str) -> ProjectLoadResponse:
    row = await db.projects.find_one({"id": pid})
    if not row:
        raise HTTPException(status_code=404, detail="Project not found")
    return ProjectLoadResponse(id=pid, doc=row.get("doc", {}))


@router.delete("/projects/{pid}")
async def delete_project(pid: str) -> dict:
    res = await db.projects.delete_one({"id": pid})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"ok": True}
