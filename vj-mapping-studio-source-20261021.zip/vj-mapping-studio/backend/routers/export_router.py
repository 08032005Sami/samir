"""Server-assembled exports: CSV coordinate / cabinet patch map."""

from fastapi import APIRouter
from models.schemas import CsvExportRequest, CsvExportResponse

router = APIRouter()


def _cabinet_order(order: str, cabs_x: int, cabs_y: int) -> list[tuple[int, int]]:
    """Return (col, row) patch order. Mirrors buildCabinets() in src/lib/led.ts."""
    cells = [(c, r) for r in range(cabs_y) for c in range(cabs_x)]
    if order == "lr-tb":          # left→right, each row top→bottom (raster)
        return cells
    if order == "rl-tb":          # right→left raster
        return [(cabs_x - 1 - c, r) for (c, r) in cells]
    if order == "tb-lr":          # column-first: top→bottom, then columns left→right
        return [(c, r) for c in range(cabs_x) for r in range(cabs_y)]
    if order == "bt-lr":          # bottom→top column-first
        return [(c, cabs_y - 1 - r) for c in range(cabs_x) for r in range(cabs_y)]
    if order == "serpentine":     # L→R, R→L alternating rows
        out = []
        for r in range(cabs_y):
            row = [(c, r) for c in range(cabs_x)]
            out.extend(row if r % 2 == 0 else list(reversed(row)))
        return out
    return cells


@router.post("/export/coordinate-csv", response_model=CsvExportResponse)
async def coordinate_csv(req: CsvExportRequest) -> CsvExportResponse:
    lines = [
        "# VJ Mapping Studio — coordinate / cabinet patch map",
        f"# project,{req.project_name}",
        "# kind,name,cab,x,y,w,h,phys_x_mm,phys_y_mm,phys_w_mm,phys_h_mm,px_x,px_y,px_w,px_h,order",
    ]
    for s in req.screens:
        lines.append(
            f"screen,{s.name},,{s.x},{s.y},{s.width},{s.height},0,0,"
            f"{s.phys_w_mm:g},{s.phys_h_mm:g},0,0,{s.width},{s.height},{s.order}"
        )
        if not req.include_cabinets:
            continue
        order = _cabinet_order(s.order, s.cabs_x, s.cabs_y)
        cab_w_px = s.width / s.cabs_x
        cab_h_px = s.height / s.cabs_y
        for n, (c, r) in enumerate(order, start=1):
            x = s.x + c * cab_w_px
            y = s.y + r * cab_h_px
            lines.append(
                f"cabinet,{s.name},{n},{x:.0f},{y:.0f},{cab_w_px:.0f},{cab_h_px:.0f},"
                f"{c * s.cab_w_mm:g},{r * s.cab_h_mm:g},{s.cab_w_mm:g},{s.cab_h_mm:g},"
                f"{c * s.cab_res_x},{r * s.cab_res_y},{s.cab_res_x},{s.cab_res_y},"
                f"{s.order}"
            )
    safe = "".join(ch for ch in req.project_name if ch.isalnum() or ch in "-_ ") or "project"
    return CsvExportResponse(
        filename=f"{safe.strip().replace(' ', '_')}_map.csv",
        csv="\n".join(lines) + "\n",
    )
