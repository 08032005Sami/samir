"""VJ Mapping Studio API tests — LED calculator math, cabinet mapping order,
validation errors, project save/load round-trip, CSV export."""

import pytest


def calc(client, **kw):
    body = {
        "wall_w": 12, "wall_h": 8, "wall_unit": "ft",
        "cab_w": 2, "cab_h": 2, "cab_unit": "ft",
        "cab_res_x": 156, "cab_res_y": 156,
        "refresh_hz": 0, "scan": 0, "allow_partial": False,
    }
    body.update(kw)
    return client.post("/calc/led-wall", json=body)


def test_user_example_12x8ft_2ft_cabinets_is_6x4_24(client):
    r = calc(client)
    assert r.status_code == 200
    d = r.json()
    assert (d["cabinets_x"], d["cabinets_y"], d["total_cabinets"]) == (6, 4, 24)
    assert (d["canvas_w"], d["canvas_h"]) == (936, 624)
    assert d["aspect_w"] == 3 and d["aspect_h"] == 2


def test_500mm_128px_metric_wall(client):
    # 12 m x 5 m with 500 mm / 128 px cabinets -> 24 x 10 cabs, 3072 x 1280 px
    r = calc(client, wall_w=12, wall_h=5, wall_unit="m", cab_w=500, cab_h=500, cab_unit="mm", cab_res_x=128, cab_res_y=128)
    d = r.json()
    assert r.status_code == 200
    assert (d["cabinets_x"], d["cabinets_y"]) == (24, 10)
    assert (d["canvas_w"], d["canvas_h"]) == (3072, 1280)
    assert d["total_pixels"] == 3072 * 1280
    assert d["pixel_pitch_mm"] == pytest.approx(3.906, abs=1e-3)
    assert d["px_per_m"] == pytest.approx(256.0)


def test_p3_576mm_die_cast(client):
    r = calc(client, wall_w=5.76, wall_h=3.456, wall_unit="m", cab_w=576, cab_h=576, cab_unit="mm", cab_res_x=192, cab_res_y=192)
    d = r.json()
    assert (d["cabinets_x"], d["cabinets_y"], d["canvas_w"], d["canvas_h"]) == (10, 6, 1920, 1152)
    assert d["pixel_pitch_mm"] == pytest.approx(3.0)


def test_fractional_cabinet_count_rejected_with_human_message(client):
    r = calc(client, wall_w=10, wall_h=8, cab_w=609.6 * 1.5, cab_h=609.6, cab_unit="mm")
    assert r.status_code == 422
    assert "cannot be exactly divided" in r.json()["detail"]


def test_allow_partial_uses_nearest_fit_with_warning(client):
    r = calc(client, wall_w=13, allow_partial=True)
    d = r.json()
    assert r.status_code == 200
    assert d["cabinets_x"] == 6
    assert d["warnings"]


@pytest.mark.parametrize("field", ["wall_w", "cab_w", "cab_res_x"])
def test_zero_or_negative_rejected(client, field):
    assert calc(client, **{field: 0}).status_code == 422
    assert calc(client, **{field: -5}).status_code == 422


def _screen(order):
    return {"name": "Main", "x": 0, "y": 0, "width": 384, "height": 256, "phys_w_mm": 1500, "phys_h_mm": 1000,
            "cab_w_mm": 500, "cab_h_mm": 500, "cab_res_x": 128, "cab_res_y": 128, "cabs_x": 3, "cabs_y": 2, "order": order}


def _cab_xy(csv_text):
    rows = [l.split(",") for l in csv_text.splitlines() if l.startswith("cabinet,")]
    return [(int(r[3]), int(r[4])) for r in rows]


@pytest.mark.parametrize("order,expected", [
    ("lr-tb", [(0, 0), (128, 0), (256, 0), (0, 128), (128, 128), (256, 128)]),
    ("serpentine", [(0, 0), (128, 0), (256, 0), (256, 128), (128, 128), (0, 128)]),
    ("tb-lr", [(0, 0), (0, 128), (128, 0), (128, 128), (256, 0), (256, 128)]),
    ("rl-tb", [(256, 0), (128, 0), (0, 0), (256, 128), (128, 128), (0, 128)]),
    ("bt-lr", [(0, 128), (0, 0), (128, 128), (128, 0), (256, 128), (256, 0)]),
])
def test_mapping_orders(client, order, expected):
    r = client.post("/export/coordinate-csv", json={"project_name": "Test Show", "screens": [_screen(order)], "include_cabinets": True})
    assert r.status_code == 200
    assert r.json()["filename"] == "Test_Show_map.csv"
    assert _cab_xy(r.json()["csv"]) == expected


def test_project_save_load_delete_roundtrip(client):
    doc = {"schema": "vjmap/1", "canvas": {"width": 1920, "height": 1080}, "screens": [{"id": "a"}], "shapes": []}
    r = client.post("/projects", json={"name": "Round Trip", "doc": doc})
    assert r.status_code == 200
    pid = r.json()["id"]
    listed = client.get("/projects").json()["projects"]
    meta = next(p for p in listed if p["id"] == pid)
    assert meta["canvas_w"] == 1920 and meta["screen_count"] == 1
    loaded = client.get(f"/projects/{pid}").json()
    assert loaded["doc"]["name"] == "Round Trip"
    assert client.delete(f"/projects/{pid}").status_code == 200
    assert client.get(f"/projects/{pid}").status_code == 404


def test_presets(client):
    d = client.get("/presets").json()
    assert any(c["width_mm"] == 576 and c["res_x"] == 192 for c in d["cabinets"])
    assert len(d["pitches"]) >= 5
