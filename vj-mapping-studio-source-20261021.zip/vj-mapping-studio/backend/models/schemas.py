"""Pydantic v2 API models. Every model here has a hand-written TS mirror in
frontend/src/lib/types.ts — keep the pair in sync in the same edit."""

from typing import Literal, Optional
from pydantic import BaseModel, Field

WallUnit = Literal["ft", "m"]
CabUnit = Literal["mm", "cm", "in", "ft"]


# ---------------------------------------------------------------- LED calculator
class CalcRequest(BaseModel):
    wall_w: float = Field(gt=0, description="Wall width in wall_unit")
    wall_h: float = Field(gt=0, description="Wall height in wall_unit")
    wall_unit: WallUnit = "ft"
    cab_w: float = Field(gt=0, description="Cabinet width in cab_unit")
    cab_h: float = Field(gt=0, description="Cabinet height in cab_unit")
    cab_unit: CabUnit = "mm"
    cab_res_x: int = Field(gt=0, description="Cabinet pixel resolution X")
    cab_res_y: int = Field(gt=0, description="Cabinet pixel resolution Y")
    refresh_hz: float = Field(default=0, ge=0)
    scan: int = Field(default=0, ge=0)
    allow_partial: bool = Field(default=False, description="Accept nearest whole-cabinet fit when the wall is not divisible")


class CalcResult(BaseModel):
    ok: bool = True
    cabinets_x: int
    cabinets_y: int
    total_cabinets: int
    canvas_w: int
    canvas_h: int
    total_pixels: int
    megapixels: float
    actual_w_mm: float
    actual_h_mm: float
    aspect_w: int
    aspect_h: int
    aspect_dec: float
    pixel_pitch_mm: float
    px_per_m: float
    px_per_m2: float
    cab_aspect_w: int
    cab_aspect_h: int
    min_view_m: float
    opt_view_m: float
    power_max_w: int
    power_typical_w: int
    weight_kg: int
    sending_ports: int
    bandwidth_gbps: Optional[float] = None
    warnings: list[str] = []


# ---------------------------------------------------------------- projects
class ProjectMeta(BaseModel):
    id: str
    name: str
    updated_at: str
    canvas_w: int = 0
    canvas_h: int = 0
    screen_count: int = 0
    shape_count: int = 0


class ProjectSaveRequest(BaseModel):
    id: Optional[str] = None
    name: str = Field(min_length=1, max_length=120)
    doc: dict = Field(description="Full .vjmap document (schema vjmap/1) — owned by the client")


class ProjectSaveResponse(BaseModel):
    id: str
    name: str
    updated_at: str


class ProjectListResponse(BaseModel):
    projects: list[ProjectMeta]


class ProjectLoadResponse(BaseModel):
    id: str
    doc: dict


# ---------------------------------------------------------------- exports
class ScreenSummary(BaseModel):
    name: str
    x: int
    y: int
    width: int
    height: int
    phys_w_mm: float
    phys_h_mm: float
    cab_w_mm: float
    cab_h_mm: float
    cab_res_x: int
    cab_res_y: int
    cabs_x: int
    cabs_y: int
    order: str = "lr-tb"


class CsvExportRequest(BaseModel):
    project_name: str = "project"
    screens: list[ScreenSummary]
    include_cabinets: bool = True


class CsvExportResponse(BaseModel):
    filename: str
    csv: str


# ---------------------------------------------------------------- presets
class CabinetPreset(BaseModel):
    name: str
    width_mm: float
    height_mm: float
    res_x: int
    res_y: int
    pitch_mm: Optional[float] = None


class PitchPreset(BaseModel):
    pitch_mm: float
    desc: str


class PresetsResponse(BaseModel):
    cabinets: list[CabinetPreset]
    pitches: list[PitchPreset]
