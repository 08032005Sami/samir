# VJ Mapping Studio

A professional **Pixel Mapping + LED Wall Calculator + Border FX + Stage Planning** tool for VJs,
LED technicians, projection mappers and Resolume users. Runs in Chrome / Edge and as a Windows
desktop app (Tauri 2) from the **same code**.

---

## 1. Features

| Area | What it does |
|---|---|
| **LED Wall Calculator** | Wall W/H in **feet** (or meters), cabinet in mm / cm / in / ft, cabinet pixel resolution → cabinets X × Y, total cabinets, canvas pixels, megapixels, aspect, pixel pitch, px/m, px/m², viewing distance, power / weight / sending ports / bandwidth (estimates). Example: 12 ft × 8 ft wall, 2 ft cabinets → **6 × 4 = 24 cabinets**. Clear errors for fractional cabinets, zero/negative values. |
| **Pixel Map Editor** | Large canvas, grid, rulers (px / m / cm / mm / ft), snap to grid + screens, smart guides, select / multi-select / marquee, move / resize / rotate, align & distribute, group, lock, hide, rename, z-order, copy / paste / duplicate, undo / redo, zoom / pan / fit. |
| **Cabinet Mapping** | Cabinet numbers, pixel ranges, global + physical coordinates, order: L→R, R→L, T→B, B→T, serpentine, custom (click-to-patch), cable-run overlay. |
| **Border FX** | 12 shape tools (rect, rounded, circle, triangle, diamond, hexagon, star, polygon, line, pen/bezier, freehand, SVG import) and 18 contour animations (traveling light, chase, neon, comet, scanner, strobe, rainbow, gradient, wave, sparkle, perimeter fill, laser, BPM pulse…). Parameters: speed, length, start, phase, offset, direction, glow, intensity, thickness, color / gradient, loop. Favorites, search, presets, copy / paste FX, randomize, global sync, Border FX Generator, Pattern Generator, symmetry. |
| **Timeline / Preview** | Play / pause / stop / loop, scrubber, frame counter, FPS 24/25/30/50/60, duration, speed, **tap tempo + BPM sync**, fullscreen preview at Fit / 25 / 50 / 75 / 100 %, checkerboard. |
| **Stage Design** | Planning layer: main / side / floor / ceiling LED, DJ booth, speaker, truss, moving head, projector, custom. |
| **Templates & Presets** | Festival main stage, DJ booth chevron, corporate 3-screen, LED cube & floor, curved arch; 2×1, 3×1, 4×1, 2×2, 3×2, L, U, backdrop, booth, floor; 10 show presets; user templates; auto layout; smart centering. |
| **Exports** | **Resolume Video (MP4/WebM)**, PNG sequence ZIP (frames folder + guide, exact loop, transparent, progress / cancel), PNG, transparent PNG, Resolume input-map PNG, Resolume screen-setup XML (best-effort), **LED wall slides ZIP**, CSV coordinate map, SVG, `.vjmap` project, PDF report / show sheet, full ZIP package. |
| **Project system** | `.vjmap` JSON files, open / save, autosave (browser), recent projects, cloud save, import SVG / PNG-JPG template / CSV / project, drag & drop. |
| **Shortcuts** | V H S R C T D X P F G L M B ?, Ctrl+Z / Y / Shift+Z / C / V / D / A / S / O / N / E, arrows (Shift ×10), Space tap = play, Space hold = pan. Single keys are **customizable**. |

## 2. Using the animated border in Resolume

**A · Video (easiest)** — Export → *Resolume Video* → drag the .mp4 onto a clip slot on the top layer →
layer blend mode **Add** (black becomes invisible).

**B · Transparent PNG frames (best quality)** — Export → *PNG Sequence ZIP* → unzip → drag the whole
frames folder into **Resolume Alley** → codec **DXV, High Quality with Alpha** → convert → drag the .mov
into Arena → blend mode **Alpha**.

Keep the export size equal to your composition size so the border lines up with your Advanced Output slices.

## 3. Project structure

```
backend/                FastAPI API (Python)
  server.py             app + /api router
  routers/calc.py       LED wall calculator (server-verified)
  routers/projects.py   cloud project save / load / delete (MongoDB)
  routers/export_router.py  CSV coordinate map
  routers/presets.py    cabinet + pitch presets
  routers/download.py   source-code ZIP download
  models/schemas.py     request / response models
  tests/                pytest API tests
  .env.example          environment variables to fill in
frontend/               React 19 + TypeScript + Vite + Tailwind v4 + shadcn/ui
  src/lib/led.ts        LED math engine
  src/lib/effects.ts    Border FX catalog (data-driven, plugin-like)
  src/lib/geometry.ts   shapes, contours, hit-testing
  src/lib/engine.ts     Canvas 2D renderer (editor, preview, exports)
  src/lib/store.ts      editor state, undo / redo, actions, tap tempo
  src/lib/project.ts    .vjmap schema, templates, presets, autosave
  src/lib/exporters.ts  PNG / sequence / video / slides / SVG / CSV / SVG import
  src/lib/zip.ts        dependency-free ZIP writer
  src/lib/shortcuts.ts  keyboard shortcuts + custom keymap
  src/components/vj/    UI panels and dialogs
  src/pages/Studio.tsx  main workstation layout
desktop/                Windows desktop app (Tauri 2) — see desktop/BUILD_WINDOWS.md
.github/workflows/windows-desktop.yml   builds the Windows .exe / .msi on GitHub
memory/SPEC.md          detailed functional spec
```

## 4. Run it locally

Requirements: **Node.js 22 + Yarn**, **Python 3.11+**, **MongoDB** (only for cloud save; everything else works without it).

```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install fastapi "uvicorn[standard]" motor pymongo python-dotenv pydantic
cp .env.example .env                                     # edit values if needed
uvicorn server:app --reload --port 8001

# frontend (second terminal)
cd frontend
yarn install
yarn dev            # opens http://localhost:3000  (/api is proxied to :8001)
```

(`backend/requirements.txt` holds the full pinned list used on the hosted version; the line above is the
minimal set this app needs.)

Production web build: `cd frontend && yarn build` → static files in `frontend/dist/`.

Tests: `cd backend && python -m pytest tests/test_vjmap_api.py` · type check: `cd frontend && yarn typecheck`.

## 5. Windows desktop app

See **desktop/BUILD_WINDOWS.md**. Short version: push to GitHub → Actions → *Windows desktop build* →
Run workflow → download the installer from Artifacts. Or on a Windows PC with Node, Yarn and Rust:
`cd frontend && yarn install`, then `cd ../desktop && npm install && npm run icons && npm run build`.

## 6. Key formulas

```
wall_mm   = feet × 304.8
cabinets  = wall_mm / cabinet_mm      (must be whole, else error or nearest-fit option)
canvas_px = cabinets × cabinet_resolution
pitch_mm  = cabinet_mm / cabinet_resolution
px/m      = cabinet_resolution / (cabinet_mm / 1000)
frames    = duration × fps
```
Estimates (clearly labelled in the app): 690 W/m² max, 35 % typical, 35 kg/m², 650,000 px per sending port,
bandwidth = pixels × refresh × 24 bit × 1.25 / 8.

## 7. Notes

- The Resolume XML follows an unofficial format — test it on a small rig first. The input-map PNG is the reliable route.
- Power, weight, port and bandwidth values are estimates; check your cabinet and processor datasheets.
- Not affiliated with Resolume or VJ Nation.
