# VJ Mapping Studio — Living Spec

Professional browser-based (Tauri-ready) tool for VJs / LED techs: pixel mapping + LED wall calculator (feet-first) + animated Border FX + stage planning + Resolume-oriented exports. No login — single-user, local-first.

## Architecture
- Frontend (React 19 + TS strict + Tailwind v4 + shadcn base-ui): all editing runs client-side; Canvas 2D rAF engine (`src/lib/engine.ts`), external observable store with snapshot undo/redo (`src/lib/store.ts`, `useEditor(selector)`).
- Shared pure engine: `lib/led.ts` (LED math), `lib/effects.ts` (18 data-driven contour FX), `lib/geometry.ts`, `lib/project.ts` (.vjmap schema, templates, presets, autosave), `lib/exporters.ts` (PNG / PNG-seq ZIP / SVG / CSV / SVG import), `lib/zip.ts` (dependency-free STORE zip).
- Backend (FastAPI, all under /api): `POST /calc/led-wall` (server-verified mirror of computeWall; 422 with human message for fractional cabinets / zero values), `GET/POST /projects`, `GET/DELETE /projects/{id}` (cloud recents, Mongo `projects`), `POST /export/coordinate-csv`, `GET /presets`. Frontend degrades gracefully offline (fallback presets, client CSV).

## Data model (.vjmap, schema "vjmap/1")
ProjectDoc { id, name, canvas{width,height,fps,background}, screens: LedScreen[], shapes: Shape[], stage: StageObject[], stageMode, exportSettings{frameW,frameH,fps,duration,transparent,exactLoop}, meta{author,event,notes} }
- LedScreen: x,y (canvas px; 1 canvas px = 1 LED px), cabsX/cabsY, cabResX/Y, cabW/cabH (mm), rotation, order (lr-tb|rl-tb|tb-lr|bt-lr|serpentine|custom), customOrder, color, locked, visible, groupId. Resolution = cabs × cabRes.
- Shape: kind (rect, rrect, circle, ellipse, triangle, diamond, hexagon, star, polygon, line, bezier, freehand), x,y,w,h,rotation, points, stroke, strokeWidth, fill, opacity, glow, blur, dash, corner, fx: EffectInstance{type, speed, length, start, direction, glow, intensity, color, color2, useGradient, phase, offset, loop, params}.

## Key formulas
wall_mm = ft×304.8; cabinets = wall/cab (must be integer unless allow_partial → floor + warning); canvas = cabinets × cabRes; pitch = cabW/resX; px/m = resX/(cabW/1000). Estimates: 690 W/m² max, 35% typical, 35 kg/m², 650k px per sending port, bandwidth = px×Hz×24×1.25/8.
User example: 12 ft × 8 ft wall, 2 ft (609.6 mm) cabinets → 6 × 4 = 24 cabinets.

## Key flows
1. Wall Calc tab (default): ft/m wall, mm/cm/in/ft cabinet, presets (incl. 576 mm P3/P4.8/P6) → live metrics → "Add to Canvas" (auto-grows canvas).
2. Canvas: V select (click/shift/ctrl/marquee), drag move w/ grid+screen snap & magenta guides, Shift constrain, handles resize (shapes/stage; screens size by cabinet count), top handle rotate (Shift 15°), H / Space-hold / middle-drag pan, wheel zoom, F fit, double-click screen → Cabinet Flow, double-click path → point edit.
3. Draw tools R/C/T/D/X/P etc. → drag creates shape with FX. S tool → drag creates screen snapped to whole cabinets.
4. Border FX tab: search/category/favorites, live thumbnails, apply to selection (or adds canvas border), params, copy/paste/reset/randomize, global sync, presets (localStorage), Border FX Generator ("4 LED screens around a central stage"), pattern generator.
5. Timeline: play/pause/stop/loop, scrub, FPS 24/25/30/50/60, duration, speed. Space taps toggle play.
6. Export dialog: PNG sequence ZIP (frames = duration×fps, frame_0001.png…, transparent, exact loop, progress + cancel, size estimate, size validation), PNG, transparent PNG, Resolume input map PNG, Resolume screensetup XML (BEST-EFFORT unofficial), CSV (server, offline fallback), SVG, .vjmap, ZIP package, PDF report.
6b. Resolume Video export (Export dialog, top section, "EASIEST"): MediaRecorder real-time render → MP4 (H.264) in Chrome/Edge, WebM fallback; border on black (Add blend) or with screens. Built-in "How to use in Resolume" guide (video route + PNG→Alley→DXV route). PNG sequence ZIP now puts frames in one folder + HOW_TO_USE_IN_RESOLUME.txt.
6c. LED Wall Slides ZIP: one native-res PNG per screen + full canvas + input map + slides_index.csv.
6d. Tap tempo: timeline TAP button / B key → BPM (avg of last taps, 2 s reset); "SYNC FX" sets every shape speed = BPM/60/beatsPerCycle and snaps export duration to whole bars.
6e. Custom shortcuts: Shortcuts modal › Customize — remap single-key actions (tools, fit, grid, lock, cabinet flow, tap); clash = swap; stored in localStorage vjmap.keymap.v1.
7. Report modal → print window (Save as PDF), CSV, PNG overview. Show-sheet audiences.
8. File: New (10 scene presets + blank), Open .vjmap, recents (local + cloud), Save (download), Save to Cloud, import SVG / template PNG-JPG (opacity chip) / CSV, drag-drop any of these. Autosave to localStorage every 1.5 s + on unload, restored on load.

## Seed / defaults
First load (no autosave) = "Festival Main Stage" template: canvas 3840×1280, screens Wing L (6×9 cab), Main Stage LED (15×9), Wing R (6×9), DJ Banner (15×2) — all 500 mm / 128 px cabinets; 4 animated shapes; 6 stage objects. Wall Calc defaults 12×8 ft, 609.6 mm, 156×156 px → 6×4=24.

## Auth
None (no accounts). Cloud projects are shared within the deployment.

## Not built / deviations
- Windows desktop: Tauri 2 project in /app/desktop (BUILD_WINDOWS.md) + GitHub Actions workflow .github/workflows/windows-desktop.yml producing .exe/.msi. Not compiled inside this Linux pod.
- Resolume XML is best-effort (format undocumented by Resolume).
- Rendering is Canvas 2D (browser GPU-composited), not WebGL.
